
% read scenario xls file
% Header col is no'1, containing only text values of parameter name!
% fname = 'scenarios.xls' by sefault;
function [parameters, channels] = read_parameters(fname,sheet)
%% 1. initialization
if nargin<1,
    fname = 'scenarios_col.xls';
end;
%keyboard
[f_status,xls_sheets,f_format] = xlsfinfo(fname);
if nargin<2,
    sheet = char(xls_sheets(1));
end;

L_vars=[];
L_scn=[];
xls_header=[];
parameters=struct([]);

%% 2. read xls file.
% <raw> holds all data at cell format
% <txt> holds all text values from xls.
%		1st row is the header row (fieldnames)
% <num> holdes numeric values:
%		1st row of 'num' is 2nd row of xls since 1st xls row is all text!disp(['- - - Read from ' fname '  - - -']);
disp(['Reading ' fname ' from sheet ' sheet])
[num, txt, raw]=xlsread(fname,sheet);

%% 3. reconstract into scenarios structure
% each element of 'scn' is one scenario == set of simulation parameters.

xls_header=txt(:,1);
L_vars=length(xls_header);
% remove " from char cells:
char_idx=find(cellfun(@ischar,raw(:,1))==1); % find char type cells in raw
raw(char_idx,1) = strrep(raw(char_idx),'"','');
raw(char_idx,1) = strrep(raw(char_idx),' ','_');
raw(char_idx,1) = strrep(raw(char_idx),'[','_');
raw(char_idx,1) = strrep(raw(char_idx),']','_');
xls_header(char_idx)=strrep(xls_header(char_idx),' ','_');
xls_header(char_idx)=strrep(xls_header(char_idx),'[','_');
xls_header(char_idx)=strrep(xls_header(char_idx),']','_');

j=find(cellfun(@(x)strcmp(x,'Channels'),raw(:,1)));
char_idx1=char_idx(char_idx<j);
char_idx2=char_idx(char_idx>j);
% build struct from cell array
parameters=cell2struct(raw(char_idx1,2),xls_header(char_idx1),1);
% L_scn=size(raw,2)-1;
% disp(['Loaded ' num2str(L_scn) ' scenarions from ' fname ', sheet - ' sheet])
%disp(scn);
k=find(cellfun(@(x)isnan(x),raw(char_idx2(1,:),2:end)),1,'first');
if isempty(k),
    k=size(raw,2);
end
channels=cell2struct(raw(char_idx2,2:k),xls_header(char_idx2),1);
% for i=1:size(raw,2)-1
%     if 

end
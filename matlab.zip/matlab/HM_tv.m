function z=HM_tv(x,a,lpf,ks1,fs_sim)
% nonlineaer model according to Hammerstein
% time varing according to filtered signal amplitude
[B, A]=butter(1,lpf*1e6/fs_sim*2);

s = filter(B,A,abs(x));

K=length(a);
y=zeros(length(x),K);
for i=1:K
    y(:,i)=x.^i.*(1+s*ks1(i));
end
 v=a*y.';
z=v;
z=z(1:length(x)).';
end 
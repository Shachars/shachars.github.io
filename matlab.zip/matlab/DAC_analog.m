function x4=DAC_analog(Cfg,x1,N1)
fs_sim=Cfg.fs_sim*1e9;
Fs_DAC = Cfg.DAC.Fs*1e9;
% fs_DAC=P.Sampling_Rate*1e9;
N = N1*(fs_sim/Fs_DAC);
% ZOH x2=repmat(x1,1,fs_sim/fs_DAC)';
% x2=x2(:);
x2=zeros(N,1);
x2(1:fs_sim/Fs_DAC:end)=x1*fs_sim/Fs_DAC;

%x2 = interp(x1,fs_sim/fs_DAC); % temporarily interpolate for using jitter.
[Bdac_lp, Adac_lp]=cheby1(Cfg.DAC.DAC_filter_order,Cfg.DAC.DAC_filter_ripple,Cfg.DAC.DAC_filter_cutoff*1e9/fs_sim*2);

%plot the filter
if 0,
    figure(2);
    [h,f] = freqz(Bdac_lp,Adac_lp,1e4,fs_sim);
    plot(f/1e9,20*log10(abs(h)));
    axis([0 fs_sim/2e9 -100 0]);
    grid on
    xlabel('Frequency (GHz)');
    ylabel('dB');
    title('DAC Filter Response'); 
end


x4=filter(Bdac_lp,Adac_lp,x2);


end

function x1=signal_gen(Cfg,C,N1,ULDL,fs)



% ideal channel generation
No_channels = length(C.Ch_enable);
beta=0.2;
x_all_in_freq=zeros(N1,1);
total_power=0;
for ch = 1:No_channels,
    if C.Ch_enable(ch) && strcmp(ULDL,C.UL_DL{ch})
        fftbin=fs/N1;
        L_ch=C.BW(ch)*1e6/fftbin/2;
        if L_ch==0 % CW
           x_all_in_freq(round(C.Freq(ch)*1e6/fftbin))= 10^(C.Power(ch)/20);
        else
        if L_ch<10
            error('BW too low or simulation too short');
        end
        %     if C(ch).Freq*1e6+C(ch).BW*1e6/2*(1+beta)>=fs/2
        %         error('Signal pass Nyquist frequency');
        %     end
        %
        %
        w = raised_cosine((-round(L_ch*(1+beta)):round(L_ch*(1+beta))-1)/L_ch,beta);
        x=xrandn(length(w),1);
        x=x.*w;
        freq_range=round(C.Freq(ch)*1e6/fftbin)-round(L_ch*(1+beta)):round(C.Freq(ch)*1e6/fftbin)+round(L_ch*(1+beta)-1);
        z=min(freq_range);
        if z<=0
            freq_range1=freq_range(freq_range>0);
            x_all_in_freq(freq_range1)=x_all_in_freq(freq_range1)+x(2-z:end)*10^(C.Power(ch)/20)/(sqrt(L_ch));
            freq_range2=freq_range(freq_range<=0)+N1;
            x_all_in_freq(freq_range2)=x_all_in_freq(freq_range2)+x(1:1-z)*10^(C.Power(ch)/20)/(sqrt(L_ch));
        else
            
            x_all_in_freq(freq_range)=x_all_in_freq(freq_range)+x*10^(C.Power(ch)/20)/(sqrt(L_ch));
            
        end
        end
        total_power = total_power+10^(C.Power(ch)/10);
        %
    end
end

if strcmp(ULDL,'DL'),
    gain_pre_DAC=Cfg.DAC.DAC_FS_power-Cfg.DAC.Backoff-10*log10(total_power);
    x_all_in_freq=x_all_in_freq*10^(gain_pre_DAC/20);
    total_power=total_power*10^(gain_pre_DAC/10);
end

if Cfg.LO==0
    x1=real(ifft(x_all_in_freq,N1)*N1);
else
    x1=ifft(x_all_in_freq,N1)*N1;
end

end



function [Freq_out,FFT_out]=plot_spect(sig,fs,fc,plot_flag)

if(~exist('plot_flag','var'))
    plot_flag = 1;
end

if nargin<3
    fc = 0;
end
if isnan(sig)
    return
end
N_welch=2^round(log2(length(sig)/50));
[pxx,f]= pwelch(sig,kaiser(N_welch,20),N_welch/2,N_welch,fs);
pxx = 10*log10(pxx);

if(plot_flag)
    if isreal(sig)
        plot(f*1e-6,pxx);
    else
        plot((f+fc*1e6-fs/2)*1e-6,fftshift(pxx));
    end
    grid on;
    RBW =  fs/N_welch*2.33; % not accurate
    title(sprintf('Signals fs=%0.2f GHz, RBW = %0.2f MHz',fs/1e9,RBW/1e6));
    xlabel('Frequency [MHz]');
    ylabel('Amplitude [dB]');
end
FFT_out=fftshift(pxx);
Freq_out=(f+fc*1e6-fs/2)*1e-6;
end
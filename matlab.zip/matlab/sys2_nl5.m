% in this case feedback from ADC + LO
% now after filter in UL band
precomputed =0;
if precomputed==0,
    clear
    precomputed = 0;
end
close all
load_sig =0 ;
dec_factor = 32;
delay = 350;
dec_len = 1024; % decimation filter length
by_channel=1;
center_freq=740; %770; %450; %450-0;    


L1 = 24;
L2 = 900;

if load_sig
    [P, C] = read_parameters('sim_data_sys_HB2.xlsx');
else
    [P, C] = read_parameters('sim_data_sys_HB1.xlsx');
end
fs_sim=P.fs_sim*1e9;
fs_DAC=P.Sampling_Rate*1e9;
fs_ADC=fs_DAC;
if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
    error('fs_sim must be a multiple of fs_ADC');
end

if precomputed==0

if load_sig
 % R=csvread('test_with_FB_setup_Noise.csv');
%  R=csvread('test_with_FB_setup_DL_2005MHz_DLonly_LTETM3.csv');
  R=csvread('test_with_FB_setup_DL_2005MHz_UL_2010MHz_LTETM3.csv');
  
%  R=csvread('7_3_16\DL_at 1960MHz_no UL_-15dBFS_MT_614_4KHz_spacing_64Carr.csv');
 % R=csvread('7_3_16\no dl no ul.csv');
%   R=csvread('7_3_16\DL_at 1977MHz_no DL_-15dBFS_MT_614_4KHz_spacing_64Carr.csv');
%  R=[];
%   for i=1:7
%       s = sprintf('full test %d.csv',i);
%   R=[R; csvread(s)];  
%   end
  rx_adc2 = R(:,1)/2048;
    rx_adc = [zeros(delay,1); R(:,2)/2048];
    rx_adc = rx_adc(1:length(rx_adc2));
    N1 = length(rx_adc);
   % N1 = (2500+2*L1-1)*dec_factor; % 4000 is period. 4000/16=250 
    rx_adc = rx_adc(1:N1);
    rx_adc2 = rx_adc2(1:N1);
else
    noise_en=1;
    N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC
    
    
    x_tx=signal_gen(P,C,N1,'DL',fs_DAC);
    % checking signal against clipping
    DAC_full_scale = 10^(P.DAC_FS_power/20);
    %fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
    fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
    clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
    fprintf('clipping probability %f \n',clip_prob);
    
    
    
    x_rx=signal_gen(P,C,P.N,'UL',fs_sim);
    if P.LO
        x_rx = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x_rx);
    end
    
    
    % adding quantization noise
    DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);
    PA_noise_rms = 10^((-174+P.PA_NF)/20)*sqrt(fs_sim/2);
    
    n_DAC = randn(N1,1)*DAC_noise_rms*noise_en;
    n_PA = randn(P.N,1)*PA_noise_rms*noise_en;
    
    x_tx1=x_tx+n_DAC;
    
    % analog domain
    DAC_out = DAC_analog(P,x_tx1,N1);
    
    % mix up
    if P.LO
        DAC_out_up = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*DAC_out);
        tx_sig = DAC_out_up * 10^(P.PA_gain/20) +n_PA;
    else
        tx_sig = DAC_out * 10^(P.PA_gain/20) + n_PA;
    end
    
    % PA
%     [B, A]=butter(2,[1600 2900]*1e6/fs_sim*2);
%     tx_sig = filter(B,A,tx_sig);
     tx_sig = HM(tx_sig,[1 0.001 0.0001],[1]);
    %tx_sig = HM_tv(tx_sig,[1 0.001 0.0001],1,[0 0.1 0],fs_sim);
    
    %plot_spect(tx_sig,fs_sim);
    
    
    h_leak = [1 0 0 0 0  0 0 0 0 0 0]*0.3;
    h13G = readprn('h_leak13g.prn');
    %h = [zeros(250,1); h13G] .* hamming(250+length(h13G));
    h_leak = resample( h13G(1:97),P.fs_sim,13)/10;
     
    
    
    Tx_leakage = filter(h_leak,1,tx_sig)* 10^(-P.Antenna_separation/20);
    
    
    
    Thermal_noise_rms = 10^((-174+P.LNA_NF)/20)*sqrt(fs_sim/2);
    n_thermal =  randn(P.N,1)*Thermal_noise_rms*noise_en;
    rx_sig = Tx_leakage + n_thermal + x_rx;
    
    figure(1)
    plot_spect(Tx_leakage,fs_sim);
    hold all
    plot_spect(tx_sig,fs_sim);
    
    plot_spect(n_thermal+x_rx,fs_sim);
    %plot_spect(rx_sig,fs_sim);
    rcolor
    
    % LNA
    
    x = rx_sig * 10^(P.LNA_gain/20);
    
    if P.LO
        x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
    end
    
    y = ADC_analog(P,x);
    
    ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
    
    n_ADC = randn(N1,1)*ADC_noise_rms*noise_en;
    
    rx_adc=y+n_ADC;
    rx_adc = [zeros(delay,1); rx_adc];
    rx_adc = rx_adc(1:N1);
    figure(1)
    legend('Tx_leakage','rx','after ADC norm to input');
    
    %legend('before ADC','after jitter','after ADC+TH')
    % checking signal against clipping
    ADC_full_scale = 10^(P.ADC_FS_power/20);
    %fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
    fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
    clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
    fprintf('clipping probability %f \n',clip_prob)
    
    if 0, % estimating tx from rx
        % r1 = DAC_analog(P,x_tx,N1);
        % r2 = ADC_analog(P,r1);
        %  a=mean(rx_adc.*r2)/mean(r2.^2);
        L=30;
        K=1; % max harmonics
        A=zeros(N1,L*K);
        for  j=1:K
            
            for i=0:L-1
                A(:,i+1+L*(j-1))=[zeros(i,1); x_tx(1:end-i).^j];
            end
        end
        h=A\rx_adc;
        figure(3)
        plot(abs(h))
        figure(2)
        r1 = A*h;
        rx_adc1 = rx_adc - r1;
        
        z1 = rx_adc1 * 10^(-P.LNA_gain/20); % normalize back to input
        %figure
        plot_spect(z1,fs_ADC);
    end
    
    % estimating rx using additional ADC
    x = tx_sig * 10^(-P.PA_Coupler/20);
    if P.LO
        x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
    end
    
    y2 = ADC_analog(P,x);
    
    ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
    
    n_ADC2 = randn(N1,1)*ADC_noise_rms*noise_en;
    
    rx_adc2=y2+n_ADC2;
end
end
ADC_full_scale = 10^(P.ADC_FS_power/20);
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)

fprintf('Total signal in ADC2 %.2f dbFS\n',10*log10(var(rx_adc2)))
figure(5)
plot_spect(rx_adc* 10^(-P.LNA_gain/20),fs_ADC);
hold all
plot_spect(rx_adc2* 10^(-P.LNA_gain/20),fs_ADC);
rcolor
legend('rx sampled','ref sampled');

if by_channel
    % find first signal
%     No_channels = length(C);
%     for ch = 1:No_channels,
%         if C(ch).Ch_enable && strcmp('UL',C(ch).UL_DL);
%             
%             freq=C(ch).Freq;
%             break
%         end
%     end
    
    x = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc;
    
    rx_adc_dec = decimate(x,dec_factor,dec_len,'fir');
    x = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc2;
    
    rx_adc2_dec = decimate(x,dec_factor,dec_len,'fir');
    %plot_spect(x,fs_ADC/100);
    z1 = rx_adc_dec * 10^(-P.LNA_gain/20); % normalize back to input
    figure(2)
    plot_spect(z1,fs_ADC/dec_factor,center_freq);
    hold all
    rcolor
    
    L=L1;
    K=1; % max harmonics
    A=zeros(N1/dec_factor-L+1-L,L*K);
    for  k=1:K
        
        for i=0:L-1
            A(:,i+1+L*(k-1))=[rx_adc2_dec(L-i:end-i-L).^k];
        end
    end
    figure(3)
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    sigma =  1e-3;
    h5=(A'*A+sigma*eye(size(A,2)))^-1*A'*rx_adc_dec(L:end-L);
    
    

    
    
    
    
    
e_lms_FD=NaN;
clear name
name{1}='after ADC norm to input';
name{2}='reference';
name{3}='LS';
p=4;
if 0 
    disp('lms FD')
                                        name{p}='lms FD'; p=p+1;

    mu  = 0.1;
    LL = 512;
    len1 = floor(length(rx_adc2_dec)/LL)*LL;
    ha = dsp.FrequencyDomainAdaptiveFilter('LeakageFactor',0.99999,'Method','constrained FDAF','Length',L,'StepSize',mu,'BlockLength',LL,'AveragingFactor',0.1,'Offset',0.01);
    [yh,e_lms_FD] = step(ha,rx_adc2_dec(1:len1),rx_adc_dec(1:len1));
    
  end
e_lms=NaN;    
if 0
    disp('lms')
                                    name{p}='lms'; p=p+1;
mu=0.1;
    [e_lms,h6]=my_lms(rx_adc2_dec(1:end-L),rx_adc_dec(1:end-L),L,mu,h5(end:-1:1)*0,1); 
end
%     hold on
e_affine=NaN;
if 0
        disp('affine')
                               name{p}='affine Ord=8'; p=p+1;

    mu = 0.05;                    % Step size
       po = 8;                      % Projection order
       offset = 0.005;               % Offset for covariance matrix
       h = dsp.AffineProjectionFilter('Length', L, ...
           'StepSize', mu, 'ProjectionOrder', po, ...
           'InitialOffsetCovariance',offset);
[yh,e_affine] = step(h,rx_adc2_dec,rx_adc_dec);
end
e_rls = NaN;
if 1
        disp('RLS')
                                name{p}='RLS'; p=p+1;

    lambda = 0.99975;
    SlidingWindowBlockLength=1024;%'Householder sliding-window RLS'  
h = dsp.RLSFilter(L,'Method','Conventional RLS', 'ForgettingFactor', lambda); % 'SlidingWindowBlockLength', SlidingWindowBlockLength
[yh,e_rls] = step(h,rx_adc2_dec(L:end),rx_adc_dec(L:end));
end
e_lat=NaN;
if 0
            disp('Lattice')
                                             name{p}='Lattice'; p=p+1;

miu = 0.05; % only for gradient
lam = 0.9995; % only for LS or QR
del = 1; % 'Least-squares Lattice' |'QR-decomposition Least-squares Lattice' |'Gradient Adaptive Lattice'
h = dsp.AdaptiveLatticeFilter('Method','Gradient Adaptive Lattice'  ,'Length', L, ...
    'ForgettingFactor', lam, 'InitialPredictionErrorPower', del, 'StepSize' , miu, 'AveragingFactor', 0.9);
[yh,e_lat] = step(h,rx_adc2_dec,rx_adc_dec);
end
e_ftf=NaN;
if 0
            disp('ftf')
              name{p}='ftf'; p=p+1;
lam = 0.9995; % only for LS or QR
h = dsp.FastTransversalFilter('Length',L,'ForgettingFactor',lam);
[yh,e_ftf] = step(h,rx_adc2_dec,rx_adc_dec);
end
e_myrls = NaN;
addpath ../rls
if 0
        disp('myRLS')
                                name{p}='myRLS'; p=p+1;

    lambda = 0.99975;
    delta = 1000;
     
[e_myrls, h7] = my_rls(rx_adc2_dec(1:end-L+1),rx_adc_dec(L:end),L,delta,lambda);
%[e1, h1] = rls_dcd(x,d,M,delta,lambda,Nu,Mb);

end
e_dcdrls = NaN;
addpath ../rls
if 1
        disp('dcdrls')
                                name{p}='dcd rls'; p=p+1;

    lambda = 1-2.5e-4;
    delta = 1000;
    Nu = 64;
    Mb = 24;
    H = 2;
    
[e_dcdrls, h8] = rls_dcd(rx_adc2_dec(1:end-L+1),rx_adc_dec(L:end),L,delta,lambda,Nu,Mb,H);
%[e1, h1] = rls_dcd(x,d,M,delta,lambda,Nu,Mb);

end




figure
    plot(real(h5/max(h5)))
    rcolor
    
    
    r3 = A*h5;
    rx_adc1_dec = rx_adc_dec(L:end-L) - r3;
    figure(102)
    plot2(e_rls,rx_adc1_dec)
%     figure 
%     plota(rx_adc1_dec)
    z1 = rx_adc1_dec * 10^(-P.LNA_gain/20); % normalize back to input
    %figure
    figure(2)
    plot_spect(rx_adc2_dec * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(z1(end/2:end-L),fs_ADC/dec_factor,center_freq);
     
    
    plot_spect(e_lms_FD(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_lms(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_affine(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_rls(end/2:end-5*L) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_lat(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_ftf(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_myrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
    plot_spect(e_dcdrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
     
    %legend('after ADC norm to input','reference','after digital cancellation','after digital cancellation (LMS)');
    legend(name)
else
    L=L2;
    K=1; % max harmonics
    A=zeros(N1-L+1,L*K);
    for  m=1:K
        
        for i=0:L-1
            A(:,i+1+L*(m-1))=[rx_adc2(L-i:end-i-L).^m];
        end
    end
    figure(5)
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    
    h5=(A'*A+1e-5*eye(size(A,2)))^-1*A'*rx_adc(L:end-L);
    hold on
    plot(abs(h5))
    rcolor
    
    
    r3 = A*h5;
    rx_adc1 = rx_adc(L:end-L) - r3;
    
    z1 = rx_adc1 * 10^(-P.LNA_gain/20); % normalize back to input
    %figure
    figure(1)
    plot_spect(z1,fs_ADC);
    rcolor
    legend('after ADC norm to input','reference','after digital cancellation');
    
    
end


%     figure(4)
%     plot_spect_mc(z1,fs_ADC/dec_factor,center_freq);
%     title('high res')


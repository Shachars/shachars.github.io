function rec = RecOFDM(in,Param,delay,Pilots,Pilot_Pos)

FreqDomainMask = [  zeros(Param.NpadDown,1) ;...                     % "Negative" frequency guard band
                        ones(Param.NOccupiedSC/2,1); ...        % "Negative" frequency information
                        zeros(1,1) ; ...                                 % DC 
                        ones(Param.NOccupiedSC/2,1); ...    % "Positive" frequency information
                        zeros(Param.NpadUp,1)]; 

Time_Shift = Param.CPnorm+1+delay;
Symbol_length = Param.CPnorm+Param.FFTsize;
% No_symbols = floor((length(in)-Time_Shift)/Symbol_length);
No_symbols = floor((length(in))/Symbol_length);
Pilots=Pilots(:,1:No_symbols);
for i=1:No_symbols
  win = in(Time_Shift+(i-1)*(Param.CPnorm+Param.FFTsize):Time_Shift+(i-1)*(Param.CPnorm+Param.FFTsize)+Param.FFTsize-1);
  FD(:,i)=fft(win)/sqrt(Param.FFTsize);
end
% translating inf positions to positions in FFT domain
for i=1:Param.NOccupiedSC
    if i<=Param.NOccupiedSC/2
        FD_convert(i)=i+Param.NpadDown+Param.FFTsize/2;
    else
        FD_convert(i)=i+Param.NpadDown+1+Param.FFTsize/2;
    end
    if FD_convert(i)>Param.FFTsize/2
      FD_convert_PM(i)=FD_convert(i)-Param.FFTsize;
    end
    if FD_convert(i)>Param.FFTsize
      FD_convert(i)=FD_convert(i)-Param.FFTsize;
    end

end

Pilot_Pos_FD=FD_convert_PM(Pilot_Pos);

H = FD(mod(Pilot_Pos_FD-1,Param.FFTsize)+1,:)./Pilots;
% figure
% plot(Pilot_Pos_FD,abs(H))
Hfull1=zeros(Param.NOccupiedSC,No_symbols);
Hfull=zeros(Param.NOccupiedSC,No_symbols);

for i=1:No_symbols
    dd(i) = mean(angle(H(2:end,i).*conj(H(1:end-1,i)))./diff(Pilot_Pos_FD)');
    H1(:,i) = H(:,i).*exp(-1j*dd(i)*Pilot_Pos_FD');

    if Param.interpolation,
        Hfull1(:,i) = interp1(Pilot_Pos_FD,H1(:,i),FD_convert_PM(1:Param.NOccupiedSC),'linear','extrap');
    else
        Hfull1(:,i) = mean(H1(:,i));
    end
    %Hfull(:,i) = interp1(Pilot_Pos_FD,H(:,i),FD_convert(1:Param.NOccupiedSC),'PCHIP');
    Hfull(:,i) =  Hfull1(:,i).*exp(1j*dd(i)*FD_convert_PM(1:Param.NOccupiedSC)');
end
% hold all
% plot(abs(Hfull))
% rcolor
% figure

rec=FD(FD_convert(1:Param.NOccupiedSC),:)./Hfull;

%plot(real(rec))


% H=zeros(1200,2);
% H(Pilot_Pos,:)=rec(Pilot_Pos,:)./Pilots;
% plot(real(fft(H(:,1))))
a=1;



                      
                      
function out = GenOFDMSig(FreqDomainData,Param)


Nsym = Param.N_sub_frames*Param.N_frames_in_subframe;
out = [];


FreqDomainSigGuard = [  zeros(Param.NpadDown,Nsym) ;...                     % "Negative" frequency guard band
                        FreqDomainData(1:Param.NOccupiedSC/2,:); ...        % "Negative" frequency information
                        zeros(1,Nsym) ; ...                                 % DC 
                        FreqDomainData(Param.NOccupiedSC/2+1:end,:); ...    % "Positive" frequency information
                        zeros(Param.NpadUp,Nsym)];                          % "Positive" frequency guard band
FreqDomainSigGuard_shift = fftshift(FreqDomainSigGuard,1);
TD = sqrt(Param.FFTsize)*ifft(FreqDomainSigGuard_shift);



if(Param.CP)
    % Add cyclic prefix
    for frame = 1:Param.N_sub_frames
        for sym = 1:Param.N_frames_in_subframe
%            if(sym == 1) || (sym == 7)
%                out = [out;TD(end-Param.CPext+1:end,(frame-1)*Param.N_frames_in_subframe+sym) ;TD(:,(frame-1)*Param.N_frames_in_subframe+sym)];
%            else
                out = [out;TD(end-Param.CPnorm+1:end,(frame-1)*Param.N_frames_in_subframe+sym) ;TD(:,(frame-1)*Param.N_frames_in_subframe+sym)];
%            end
        end
    end
else
    out = TD(:);
end

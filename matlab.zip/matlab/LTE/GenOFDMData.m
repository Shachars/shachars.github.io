function [FreqDomainData,avg_pow] = GenOFDMData(Param)


mod_qpsk = [1+i; 1-i;-1+i;-1-i];

mod_16q =[ 1+i; 1+3i; 3+i; 3+3i;  1-i; 1-3i; 3-i; 3-3i; ...
    -1+i;-1+3i;-3+i;-3+3i; -1-i;-1-3i;-3-i;-3-3i];

mod_64q = [ 3+3i; 3+i; 1+3i; 1+i; 3+5i; 3+7i; 1+5i; 1+7i; ...
    5+3i; 5+i; 7+3i; 7+i; 5+5i; 5+7i; 7+5i; 7+7i; ...
    3-3i; 3-i; 1-3i; 1-i; 3-5i; 3-7i; 1-5i; 1-7i; ...
    5-3i; 5-i; 7-3i; 7-i; 5-5i; 5-7i; 7-5i; 7-7i; ...
    -3+3i;-3+i;-1+3i;-1+i;-3+5i;-3+7i;-1+5i;-1+7i; ...
    -5+3i;-5+i;-7+3i;-7+i;-5+5i;-5+7i;-7+5i;-7+7i; ...
    -3-3i;-3-i;-1-3i;-1-i;-3-5i;-3-7i;-1-5i;-1-7i; ...
    -5-3i;-5-i;-7-3i;-7-i;-5-5i;-5-7i;-7-5i;-7-7i];


switch Param.Mod
    case 'QPSK'
        map = mod_qpsk;
        avg_pow = norm(mod_qpsk)^2/length(mod_qpsk);
    case '16Q'
        map = mod_16q;
        avg_pow = norm(mod_16q)^2/length(mod_16q);
    case '64Q'
        map = mod_64q;
        avg_pow = norm(mod_64q)^2/length(mod_64q);
    otherwise
        disp('Error!, No such modulation');
end
Lmap = length(map);
Nsym = Param.N_sub_frames*Param.N_frames_in_subframe;


FreqDomainSigIdexes = floor(Lmap*rand(Param.NOccupiedSC,Nsym))+1;
FreqDomainData = map(FreqDomainSigIdexes);


function [ccdf_res, out2] = GenOFDMSig_TD_filt(FreqDomainData,Param)

sampling_rate_mh = Param.FFTsize*15*1000/1e6;

N = 63; % number of taps in impulse response
Fd = [0 Param.BW_Mh*0.45 Param.BW_Mh*0.515 sampling_rate_mh/2] / (sampling_rate_mh/2);
h = firls(N-1, Fd, [1 1 10^(-80/20) 0], [1 100]);

ccdf_res = zeros(length(Param.ccdf_vec),1);

Nsym = Param.N_sub_frames*14;
out = [];


FreqDomainSigGuard = [  zeros(Param.NpadDown,Nsym) ;...                     % "Negative" frequency guard band
                        FreqDomainData(1:Param.NOccupiedSC/2,:); ...        % "Negative" frequency information
                        zeros(1,Nsym) ; ...                                 % DC 
                        FreqDomainData(Param.NOccupiedSC/2+1:end,:); ...    % "Negative" frequency information
                        zeros(Param.NpadUp,Nsym)]; 
FreqDomainSigGuard_shift = fftshift(FreqDomainSigGuard);
TD = sqrt(Param.FFTsize)*ifft(FreqDomainSigGuard_shift);


%  Calculate PAPR histogram
for frame = 1:Param.N_sub_frames
    for sym = 1:14
        power_vec = abs(TD(:,(frame-1)*14+sym)).^2;
        PAPR_ofdm = 10*log10(max(power_vec)/mean(power_vec));
        ccdf_res = ccdf_res + double(Param.ccdf_vec < PAPR_ofdm);
    end
end

if(Param.CP)
    % Add cyclic prefix
    for frame = 1:Param.N_sub_frames
        for sym = 1:14
            if(sym == 1) || (sym == 7)
                out = [out;TD(end-Param.CPext+1:end,(frame-1)*14+sym) ;TD(:,(frame-1)*14+sym)];
            else
                out = [out;TD(end-Param.CPnorm+1:end,(frame-1)*14+sym) ;TD(:,(frame-1)*14+sym)];
            end
        end
    end
else
    out = TD(:);
end
out2 = filter(h,1,out);

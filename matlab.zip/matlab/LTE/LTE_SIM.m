clear;
close all

GenParam.Mod = '16Q';               % Modulation: 'QPSK' or '16Q' or '64Q'
GenParam.BW_Mh = 20;                % System bandwidth in Mhz: 20, 15, 10, 5, 3, 1.4
GenParam.CP = 1;                    % Generate cyclic prefix: 
                                         % 0- without Cyclic Prefix
                                            % 1- with Cyclic Prefix
GenParam.interpolation = 0; 
GenParam.N_sub_frames = 1;         % Number of sub frames per run
GenParam.N_frames_in_subframe=14;   

GenParam =  CalcDerivedParams(GenParam); % Calculate derived parameters


Pilot_Pos = [GenParam.NOccupiedSC/4 : 10:  GenParam.NOccupiedSC*3/4]; 
    
[FreqDomainData, avg_pow] = GenOFDMData(GenParam); % Generate frequency domain data
FreqDomainData(Pilot_Pos,:) = max(max((FreqDomainData))); % use highest constellation point
%FreqDomainData=ones(size(FreqDomainData));
%FreqDomainData = [(0:1200-1)' (1:1201-1)'];    
Pilots = FreqDomainData(Pilot_Pos,:);


    % 3GPP signal
ofdm_sig = GenOFDMSig(FreqDomainData,GenParam);
ofdm_sig = ofdm_sig/sqrt(avg_pow);

% FreqDomainData_est = RecOFDM([ofdm_sig; 0],GenParam,0,Pilots,Pilot_Pos);
% %FreqDomainData_est = FreqDomainData_est*sqrt(avg_pow);
% plot(FreqDomainData_est,'.')
% figure
% 
N = 31; % number of taps in impulse response
Fd = [0 GenParam.BW_Mh*0.55 GenParam.BW_Mh*0.65 GenParam.sampling_rate_mh/2] / (GenParam.sampling_rate_mh/2);
h = firls(N-1, Fd, [1 1 10^(-60/20) 0], [1 100]);
%h = [zeros(1,31) 1];
ofdm_sig_filt=filter(h,1,[ofdm_sig; zeros(100,1)]);

delay=0; %floor(length(h)/2);
FreqDomainData_est = RecOFDM(ofdm_sig_filt,GenParam,delay,Pilots,Pilot_Pos);

plot(FreqDomainData_est,'.')
EVM = norm(FreqDomainData_est - FreqDomainData)/norm(FreqDomainData_est);
fprintf('EVM = %f dB\n',20*log10(EVM))



psd_fft_size = 1024;
bw_vec = linspace(-GenParam.sampling_rate_mh/2,GenParam.sampling_rate_mh/2-GenParam.sampling_rate_mh/psd_fft_size,psd_fft_size);

% Calculate spectral power for 3GPP signal  
psd_fft_size = 1024;
Pxx = pwelch(ofdm_sig,psd_fft_size);
Pxx_shifted = fftshift(Pxx);



% Plot spectral power 
figure;
plot(bw_vec,10*log10(Pxx_shifted),'b');
grid on;
xlabel('Freq. [Mhz]');
ylabel('power [dB]');
title('PSD');


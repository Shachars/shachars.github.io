function rcolor(style)
%RCOLOR Color differently all the graphs on the current axis.
%   RCOLOR paints every line in the current plot in different color.
%
%   RCOLOR(N) paints lines in N different colors. After that different
%   line styles are introduced to emphasize multiple plots on one axes.
%
%   See also PLOT.

%% Version Control
% Grisha  25-Nov-07  Added support for "stairs" (hggroup line type)
% Grisha  01-Jan-01  Original version


gr = flipud(get(gca,'children'));
clr = [get(0,'defaultaxescolororder');rand(20,3)];
linestyle = {'-','--','-.',':'};

%if(length(gr)>size(clr,1))
%    gr = gr(1:size(clr,1));
%end

if ~exist('style','var')
    k=1;
    for i=1:length(gr)
        if IsLine(gr(i))
            set(gr(i),'color',clr(k,:));
            k = mod(k,size(clr,1))+1;
        end
    end
else
    k=1; k_style = 1;
    for i=1:length(gr)
        if IsLine(gr(i))
            set(gr(i),'color',clr(k,:),'linestyle',linestyle{k_style});
            k = mod(k,style)+1;
            if k==1
                k_style = mod(k_style,length(linestyle))+1;
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% IsLine - check if the pointer is to one of the supported line types                           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function is_line = IsLine(ptr)
type = get(ptr,'type');
is_line = strcmp(type,'line') ...
	||    strcmp(type,'hggroup');

return

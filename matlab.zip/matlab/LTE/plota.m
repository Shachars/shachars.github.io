function plota(x)
close
figure
plot(abs(x))
end
function [GenParam] = CalcDerivedParams(GenParam,Fs_ADC)

switch (GenParam.BW_Mh)
    case 20
        GenParam.FFTsize = 2048;
        GenParam.NOccupiedSC = 1200;                % Number of of information sub-carriers of guards
    case 15
        GenParam.FFTsize = 1536;
        GenParam.NOccupiedSC = 900;                 % Number of of information sub-carriers of guards
    case 10
        GenParam.FFTsize = 1024;
        GenParam.NOccupiedSC = 600;                 % Number of of information sub-carriers of guards
    case 5
        GenParam.FFTsize = 512;
        GenParam.NOccupiedSC = 300;                 % Number of of information sub-carriers of guards
	case 3
        GenParam.FFTsize = 256;
        GenParam.NOccupiedSC = 180;                 % Number of of information sub-carriers of guards
	case 1.4
        GenParam.FFTsize = 128;
        GenParam.NOccupiedSC = 72;                  % Number of of information sub-carriers of guards
    otherwise 
        disp('Error!, No such FFTsize');
end

GenParam.channel_BW = GenParam.BW_Mh*10e6;
% (currently not implemented)GenParam.CPext = 160*GenParam.FFTsize/2048;         % Cyclic prefix length for symbol  0,             7
GenParam.CPnorm = 144*GenParam.FFTsize/2048;        % Cyclic prefix length for symbol 1,2,3,4,5,6    8,9,10,11,12,13,14
GenParam.NpadUp = (GenParam.FFTsize/1024)*212-1;    % Number of of "positive" sub-carriers of guards    
GenParam.NpadDown = (GenParam.FFTsize/1024)*212;    % Number of of "negative" sub-carriers of guards
if(exist('Fs_ADC','var')) % If we have a specific ADC sampling frequency then we need to adjust the sub carrier spacing
    GenParam.sampling_rate_mh = Fs_ADC;
    GenParam.sc_spacing_mhz = Fs_ADC/GenParam.FFTsize;
else
    GenParam.sampling_rate_mh = GenParam.FFTsize*15*1000/1e6;
    GenParam.sc_spacing_mhz = 15*1000/1e6;
end



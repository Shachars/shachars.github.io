% Run
% clear all;

ccdf_vec = [6:0.25:13]';                        % Vector of PAPR values (in dB) for which CCDF will be calculated
ccdf_res = zeros(length(ccdf_vec),1);           % Initialize PAPR CCDF for 3GPP signal
ccdf_res_tdf = zeros(length(ccdf_vec),1);       % Initialize PAPR CCDF for 3GPP+ time domain filtering signal


psd_fft_size = 1024;

GenParam.N_sub_frames = 10;         % Number of sub frames per run
GenParam.Mod = '16Q';               % Modulation: 'QPSK' or '16Q' or '64Q'
GenParam.BW_Mh = 20;                % System bandwidth in Mhz: 20, 15, 10, 5, 3, 1.4
GenParam.CP = 1;                    % Generate cyclic prefix: 
                                            % 0- without Cyclic Prefix
                                            % 1- with Cyclic Prefix
GenParam.ccdf_vec = ccdf_vec;       % Vecor of PAPR (in dB) for which the histogram will be measured 


GenParam =  CalcDerivedParams(GenParam); % Calculate derived parameters



N_run = 50;  % Number of runs (for CCDF statistics) each run in the length of GenParam.N_sub_frames sub-frames
for run_no = 1:N_run
    
    FreqDomainData = GenOFDMData(GenParam); % Generate frequency domain data
    
    
    % 3GPP signal
    [curr_ccdf_res, ofdm_sig] = GenOFDMSig(FreqDomainData,GenParam);
    
    % 3GPP signal + time domain filtering
    [curr_ccdf_res_tdf, ofdm_sig_tdf] = GenOFDMSig_TD_filt(FreqDomainData,GenParam);
    
    % Update CCDF statistics
    ccdf_res = ccdf_res + curr_ccdf_res;
    ccdf_res_tdf = ccdf_res_tdf + curr_ccdf_res_tdf;
end


% Normalize CCDF 
ccdf_res = ccdf_res/(N_run*GenParam.N_sub_frames*14);
ccdf_res_tdf = ccdf_res_tdf/(N_run*GenParam.N_sub_frames*14);

sampling_rate_mh = GenParam.FFTsize*15*1000/1e6;
bw_vec = linspace(-sampling_rate_mh/2,sampling_rate_mh/2-sampling_rate_mh/psd_fft_size,psd_fft_size);

% Calculate spectral power for 3GPP signal  
Pxx = pwelch(ofdm_sig,psd_fft_size);
Pxx_shifted = fftshift(Pxx);

% Calculate spectral power for 3GPP + time domain filtering signal 
PxxTDF = pwelch(ofdm_sig_tdf,psd_fft_size);
PxxTDF_shifted = fftshift(PxxTDF);


% Plot spectral power 
figure;
plot(bw_vec,10*log10(Pxx_shifted),'b');
grid on;
hold on;
plot(bw_vec,10*log10(PxxTDF_shifted),'g');
legend(['3GPP, var = ' num2str(var(ofdm_sig))],['TDF, var = ' num2str(var(ofdm_sig_tdf))]);
xlabel('Freq. [Mhz]');
ylabel('power [dB]');
title('PSD');

% Plot PAPR CCDF
figure;semilogy(ccdf_vec,ccdf_res,'b*-');
grid on;
hold on;
semilogy(ccdf_vec,ccdf_res_tdf,'gd-');
legend('3GPP','TDF');
xlabel('PAPR_0 [dB]');
ylabel('P(PAPR > PAPR_0)');
title('CCDF');




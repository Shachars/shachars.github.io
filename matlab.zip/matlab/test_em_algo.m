% Test script
close all;clear all;clc
ModelConfig;
N = 1e5;
WF_len = Cfg.WF_len;
% h = [1,0.5,0.25,zeros(1,Cfg.h_leak-3)];
% g = [0.1+0.1*1i,0.45+0.2*1i,zeros(1,WF_len-2)];
h = [0.1,0.5,0.25,zeros(1,Cfg.h_leak-3)];
g = [0.1,0,0,0,zeros(1,WF_len-4)];
Ntests = 1;
debug = 1;
debug_sweep = 0;
snr_in = zeros(1,Ntests);
snr_out = zeros(1,Ntests);
error_mse = zeros(1,Ntests);
h_est_out = zeros(length(h),Ntests);
g_est_out = zeros(length(g),Ntests);
g_e_out = zeros(1,Ntests);
g_s_out = zeros(1,Ntests);
power_x = linspace(-50,10,Ntests); % this is interesting since this is
% the area where they may be interchanged
% power_x = linspace(5,100,Ntests);
% power_x = linspace(100,180,Ntests);
lambda_rls = 1-2e-9;%Cfg.lambda;
h_leak = Cfg.h_leak;
lambda_reset = 0.99;
delta_h_leak = 1e-6; % todo - we need different diagonal loading for g and h - function of length of filter and SINR
delta_g = 1e2; % todo - we need different diagonal loading for g and h
delta_ni = 1e-6;
flag_diagonal_loading = 0;
for i=1:Ntests
    sigma_x = 10^(power_x(i)/20);
    sigma_n = 10^(5/20);
    sigma_s = 10^(10/20);
    %     x = sigma_x*randn(N,1) + sigma_x*1i*randn(N,1);
    x = sigma_x*randn(N,1);
    x_after_ch = filter([h],1,x);
    %     n = sigma_n*randn(N,1) + sigma_n*1i*randn(N,1);
    %     u = sigma_s*randn(N,1) + sigma_s*1i*randn(N,1);
    n = sigma_n*randn(N,1);
    u = sigma_s*randn(N,1);
    s = filter(1,[1,g],u);
    y = x_after_ch + s + n;
    reset = zeros(1,N);
    
    %     [h_est,g_est,g_s,g_e,out] = EM_self_interference_cancel_algo(x,y,lambda_rls,lambda_reset,delta_g,delta_h_leak,delta_ni,reset,WF_len,h_leak,flag_diagonal_loading);
%     [h_est,g_est,g_s,g_e,out] = EM_self_interference_cancel_algo_complex(x,y,lambda_rls,lambda_reset,delta_g,delta_h_leak,delta_ni,reset,WF_len,h_leak,flag_diagonal_loading);
    [h_est,g_est,out] = EM_self_interference_cancel_algo_complex(x,y,lambda_rls,lambda_reset,delta_g,delta_h_leak,reset,WF_len,h_leak);
    snr_in(i) = 20*log10(norm(s(end/2:end))/norm(s(end/2:end)-y(end/2:end)));
    snr_out(i) = 20*log10(norm(s(end/2:end))/norm(s(end/2:end)-out(end/2:end)));
    error_mse(i) = 20*log10(norm(s(end/2:end)-out(end/2:end))/length(s(end/2:end)));
    h_est_out(:,i) = h_est;
    g_est_out(:,i) = g_est;
%     g_e_out(i) = 10*log10(g_e);
%     g_s_out(i) = 10*log10(g_s);
    if(debug)
        
%         fprintf('\n');
%         disp(['SNR out = ',num2str(20*log10(norm(s)/norm(s-out)))]);
%         disp(['SNR in = ',num2str(20*log10(norm(s)/norm(y-s)))]);
%         disp(['Estimated signal power = ',num2str(20*log10(abs(sqrt(g_s))))]);
%         disp(['Estimated noise power = ',num2str(20*log10(abs(sqrt(g_e))))]);
        
    end
end

if(debug_sweep)
    figure;plot(snr_in,snr_out);grid on;xlabel('SNR in [dB]');ylabel('SNR out [dB]');
    figure;plot(snr_in,snr_out-snr_in);grid on;xlabel('SNR in [dB]');ylabel('SNR improvement [dB]');
    figure;plot(snr_in,error_mse);grid on;xlabel('SNR in [dB]');ylabel('Estimation error power [dB]');
    figure;plot(snr_in,((sum(bsxfun(@minus,h_est_out,h.').^2,1))));grid on;xlabel('SNR in [dB]');ylabel('convergence of h estimation');
    figure;plot(snr_in,sqrt(sum(bsxfun(@minus,g_est_out,g.').^2,1)));grid on;xlabel('SNR in [dB]');ylabel('convergence of g estimation');
    figure;plot(snr_in,g_s_out);grid on;xlabel('SNR in [dB]');ylabel('g_s innovation[dB]');
    figure;plot(snr_in,g_e_out);grid on;xlabel('SNR in [dB]');ylabel('g_e noise [dB]');
    figure;plot(snr_in,(g_est_out(1,:)./g_est_out(2,:)));xlabel('SNR in [dB]');ylabel('Ratio of first two taps');grid on;
    hold on;plot(snr_in,repmat(g(1)/g(2),1,length(g_est_out(1,:)./g_est_out(2,:))),'r');legend('Estimation','Model');
end

d= y;
delta = Cfg.EM.delta_h_leak; % todo - we need different diagonal loading for g and h
lambda = 1-2e-9;%Cfg.lambda;
M_h = Cfg.h_leak;
N = length(x);
out_rls = zeros(1,N);
u = zeros(M_h,N-M_h);
P_rls = eye(M_h)*delta^-1;
h = zeros(M_h,1);
for i=1:N-M_h
    u(:,i)=x(i:1:i+M_h-1);
end

for n=M_h:N-M_h
    if mod(n,10000)==0, fprintf('%d  ',n);end
    y = d(n);
    e = y - h'*u(:,n- M_h + 1);
    p = P_rls*u(:,n- M_h + 1);
    c = lambda + u(:,n- M_h + 1)'*p;
    k = p/c;
    P_rls = (lambda^-1)*P_rls-(lambda^-1)*k*u(:,n- M_h + 1)'*P_rls;
    h = h + k*conj(e);
    out_rls(n) = e;
end

figure;[Freq_out,FFT_out]=plot_spect(d,2.4e9,480e6,1);
hold on;[Freq_out,FFT_out]=plot_spect(out,2.4e9,480e6,1);
hold on;[Freq_out,FFT_out]=plot_spect(out_rls,2.4e9,480e6,1);
hold on;[Freq_out,FFT_out]=plot_spect(x_after_ch,2.4e9,480e6,1);
hold on;[Freq_out,FFT_out]=plot_spect(s,2.4e9,480e6,1);
legend('RX','algo out','rls out','DL','UL')

figure;plot(d(50000:50200));hold on;plot(s(50000:50200),'r');hold on;hold on;plot(out_rls(50000:50200),'g');grid on;xlabel('Samples');ylabel('Amplitude');legend('algo input','AR process s','rls out');
figure;plot(d(50000:50200));hold on;plot(s(50000:50200),'r');hold on;plot(out(50000:50200),'g');grid on;xlabel('Samples');ylabel('Amplitude');legend('algo input','AR process s','algo output');


clc;
disp('==============   BEGIN SELF INTERFERENCE MITIGATION RESULTS   ==============');
disp('============================================================================');
disp(['Leakage filter estimation (EM): ',num2str(h_est_out(end:-1:1).')]);
disp(['Leakage filter estimation (RLS):',num2str(h(end:-1:1).')]);
disp(['UL AR filter estimation: ',num2str(g_est_out.')]);
disp(['Power of the innovation process: ',num2str(g_s_out)]);
disp(['Power of thermal noise: ',num2str(g_e_out)]);
disp('============================================================================');
disp('==============   END   SELF INTERFERENCE MITIGATION RESULTS   ==============');
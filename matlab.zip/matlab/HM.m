function z=HM(x,a,b)
% nonlineaer model according to Hammerstein
K=length(a);
y=zeros(length(x),K);
for i=1:K
    y(:,i)=x.^i;
end
 v=a*y.';
z=conv(v,b);
z=z(1:length(x)).';
end 
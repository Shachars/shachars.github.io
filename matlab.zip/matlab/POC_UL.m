clear
close all
addpath('../LTE');

%[P, C] = read_parameters('sim_data MB1710-2180_1.xlsx');
[P, C] = read_parameters('sim_data LB 400-1100_1.xlsx');
%[P, C] = read_parameters('sim_data HB 2305-2690_1.xlsx');

fs_sim=P.fs_sim*1e9;
fs_ADC=P.Sampling_Rate*1e9;
if ((fs_sim/fs_ADC)-floor(fs_sim/fs_ADC))~=0
    error('fs_sim must be a multiple of fs_ADC');
end
N_welch=8192;

% ideal channel generation
No_channels = length(C);
beta=0.2;
x_all_in_freq=zeros(P.N,1);
total_power=0;
fftbin=fs_sim/P.N;
for ch = 1:No_channels,
    if C(ch).Ch_enable && C(ch).LTE==0,
        
        L_ch=C(ch).BW__MHz_*1e6/fftbin/2; % number of bins the channel takes in the large fft
        if L_ch<10 && L_ch>0
            error('BW too low or simulation too short');
        end
        if C(ch).RF_Freq__MHz_*1e6+C(ch).BW__MHz_*1e6/2*(1+beta)>=fs_sim/2
            error('Signal pass Nyquist frequency of fs_sim');
        end
        %
        if L_ch>0
            w = raised_cosine((-round(L_ch*(1+beta)):round(L_ch*(1+beta))-1)/L_ch,beta);
            x=xrandn(length(w),1);
            x=x.*w;
            freq_range=round(C(ch).RF_Freq__MHz_*1e6/fftbin)-round(L_ch*(1+beta)):round(C(ch).RF_Freq__MHz_*1e6/fftbin)+round(L_ch*(1+beta)-1);
        else
            freq_range=round(C(ch).RF_Freq__MHz_*1e6/fftbin);
            L_ch=1;
            x=sqrt(2);
            fprintf('Minimum BW assigned to CW %.2f KHz\n',fftbin/1e3');
        end
            
        x_all_in_freq(freq_range)=x_all_in_freq(freq_range)+x*10^(C(ch).Amp__dBm_/20)/(sqrt(L_ch));
        
    end
    if C(ch).Ch_enable
        total_power = total_power+10^(C(ch).Amp__dBm_/10);
    end
end

x=ifft(x_all_in_freq,P.N)*P.N;

for ch = 1:No_channels,
    if C(ch).Ch_enable && C(ch).LTE==1,
        fs_LTE = 1.5360e6*C(ch).BW__MHz_;
        N_ofdm_subframes = floor(P.N/(fs_sim/30.72e6)/(14*2192))+1;
        
        [ofdm_sig,Pilots,Pilot_Pos,GenParam,FreqDomainData] = TxLTE(C(ch).BW__MHz_,N_ofdm_subframes);
        store_ofdm_params(ch).Pilots=Pilots;
        store_ofdm_params(ch).Pilot_Pos=Pilot_Pos;
        store_ofdm_params(ch).GenParam=GenParam;
        store_ofdm_params(ch).FreqDomainData=FreqDomainData;
        %h = [zeros(1,31) 1];
        %    [ofdm_sig1,b] = interp(ofdm_sig,4,6,0.7);
%         ofdm_sig = ofdm_sig*0;
%         ofdm_sig(1)=1;
        ofdm_sig1 = zeros(4*length(ofdm_sig),1);
        ofdm_sig1(1:4:end)=ofdm_sig;
        %   N_welch = 2000;
        %   pwelch(ofdm_sig1,kaiser(N_welch,20),N_welch/2,N_welch,fs_ADC);
        % figure
        % freqz(b);
        N = 127; % number of taps in impulse response
        Fd = [0 C(ch).BW__MHz_*0.54e6 C(ch).BW__MHz_*0.63e6 fs_LTE*4/2] / (fs_LTE*4/2);
%        Fd = [0 C(ch).BW__MHz_*0.44e6 C(ch).BW__MHz_*0.53e6 fs_LTE*4/2] / (fs_LTE*4/2);
        h = firls(N-1, Fd, [1 1 10^(-60/20) 0], [1 100]);
        ofdm_sig_filt=filter(h,1,[ofdm_sig1; zeros(100,1)]); % interpolation filter
%        yo = interp(ofdm_sig_filt,round(fs_sim/fs_LTE/4));
        p=round(fs_sim/fs_LTE/4);
        Fdi = [0 C(ch).BW__MHz_*1 fs_LTE*4/2 fs_sim/2] / (fs_sim/2);
        hi = fir1(p*16-1, 2*fs_LTE/ (fs_sim/2),chebwin(p*16,80)); %freqz(hi);
        yo= upfirdn(ofdm_sig_filt,hi,p);
        yo = yo.*exp(2j*pi*C(ch).RF_Freq__MHz_*1e6/fs_sim*(0:length(yo)-1)');
        
        %pwelch(y,kaiser(N_welch,20),N_welch/2,N_welch,fs_ADC);
        x = x + sqrt(2)*yo(1:P.N)*10^(C(ch).Amp__dBm_/20)/sqrt(var(yo));
    end
end

pwelch(x,kaiser(N_welch*128,20),N_welch*128/2,N_welch*128,fs_sim);
title('Signals in the antenna (without noise)');
figure

%
%var(x)

% % add AWGN noise
% n = randn(P.N,1)*10^((-174+P.System_NF)/20)*sqrt(fs_sim/2);
% 
%x=x+n;
x1=x(1:fs_sim/fs_ADC:end); %*sqrt(fs_sim/fs_ADC);
if (P.LO>0)
   x1=real(x1.*exp(-2j*pi*(1:length(x1)).'*P.LO*1e6/fs_ADC)); 
else
   x1=real(x1);
end
hold all
pwelch(x1,kaiser(N_welch,20),N_welch/2,N_welch,fs_ADC);
RBW =  fs_ADC/N_welch*2.33; % not accurate
% add jitter
if P.Jitter_simulation_enable,
    N0=4*10^(P.Jitter_at_Corner/10)*pi^2*(P.Jitter_Corner*1e3)^2;
    sigmateta=sqrt(N0/fs_sim);
    n1=randn(P.N,1)*sigmateta/(2*pi*fs_sim);
    J_wiener=filter(1,[1 -1],n1); % integrator
    J_flat=randn(P.N,1)*P.Flat_jitter*1e-12;
    J=(J_wiener+J_flat)/(1/fs_sim);
    J=J-min(J); % make it positive only and little constant time shift doesn't matter.
    
    % implementing jitter using linear interpolation approximation
    y=x(1:end-1).*(1-J(1:end-1))+x(2:end).*J(1:end-1);
else
    y=x;
end
% decimation for real ADC
y=y(1:fs_sim/fs_ADC:end); %*sqrt(fs_sim/fs_ADC);
% downconveting with external LO
% the fact that we downconvert after decimation doesnt matter and it 
% reduces complexity.
if (P.LO>0)
   y=real(y.*exp(-2j*pi*(1:length(y)).'*P.LO*1e6/fs_ADC)); 
else
  y=real(y);
end

hold all
pwelch(y,kaiser(N_welch,20),N_welch/2,N_welch,fs_ADC);
rcolor
N1 = P.N/(fs_sim/fs_ADC);

% adding quantization noise
ADC_noise_rms = 10^((-174+P.System_NF-P.Thermal_above_quantization)/20)*sqrt(fs_ADC/2);
Thermal_noise_rms = 10^((-174+P.System_NF)/20)*sqrt(fs_ADC/2);

n_ADC = randn(N1,1)*sqrt(ADC_noise_rms^2+Thermal_noise_rms^2);

z=y+n_ADC;
pwelch(z,kaiser(N_welch,20),N_welch/2,N_welch,fs_ADC);
rcolor
title(sprintf('Signals after sampling, RBW = %0.2f MHz',RBW/1e6));

legend('before ADC','after jitter','after ADC+TH')
% checking signal against clipping
ADC_full_scale = ADC_noise_rms*10^(P.ADC_SNR/20);
fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal %.2f dbm\n',10*log10(total_power))
clip_prob=sum(abs(z)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)

plot_flag=0;
% OFDM receiver
qq=0;pp=1;
N = 1024;%127; % number of taps in impulse response
%Fd = [0 C(ch).BW__MHz_*0.44e6 C(ch).BW__MHz_*0.53e6 fs_LTE*4/2] / (fs_LTE*4/2);
%for pp=0.425:0.05:0.8

qq=qq+1;
for ch = 1:No_channels,
    if C(ch).Ch_enable && C(ch).LTE==1,
      Fd = [0 C(ch).BW__MHz_*.525*1e6 C(ch).BW__MHz_*0.57*1e6 fs_LTE*4/2] / (fs_LTE*4/2);
      h = firls(N-1, Fd, [1 1 10^(-60/20) 0], [1 100]);
      Fd = [0 C(ch).BW__MHz_*1e6 C(ch).BW__MHz_*2*1e6 fs_ADC/2] / (fs_ADC/2);
      h1 = firls(N*1-1, Fd, [1 1 10^(-60/20) 0], [1 100]);

        
        
        fs_LTE = 1.5360e6*C(ch).BW__MHz_;
        r1  = z.*exp(-2j*pi*(C(ch).RF_Freq__MHz_-P.LO)*1e6/fs_ADC*(0:length(z)-1).');
        r1=filter(h1,1,r1);
        if plot_flag, pwelch(r1,kaiser(N_welch,20),N_welch/2,N_welch,fs_ADC); end
        
        r2 = decimate(r1,round(fs_ADC/fs_LTE/4));
        if plot_flag, pwelch(r2,kaiser(N_welch,20),N_welch/2,N_welch,fs_LTE*4); end
        r3 = filter(h,1,[r2; zeros(100,1)]); % decimation filter and channel filter
        hold all; 
        if plot_flag, pwelch(r3,kaiser(N_welch,20),N_welch/2,N_welch,fs_LTE*4); end
        rcolor;
        
        r4 = r3(1:4:end);
        N_welch=N_welch/8;
        if plot_flag, figure; pwelch(r4,kaiser(N_welch,20),N_welch/2,N_welch,fs_LTE); end
        
        delay=N/8; %floor(length(h)/2);
        FreqDomainData_est = RecOFDM(r4,store_ofdm_params(ch).GenParam,delay,store_ofdm_params(ch).Pilots,store_ofdm_params(ch).Pilot_Pos);
        
        figure
        plot(FreqDomainData_est,'.')
        FreqDomainData=store_ofdm_params(ch).FreqDomainData(:,1:size(FreqDomainData_est,2)); % est is shorter
        EVM = norm(FreqDomainData_est - FreqDomainData)/norm(FreqDomainData_est);
        fprintf('EVM = %.2f dB (SNR = %.2f dB)\n',20*log10(EVM),-20*log10(EVM))
        ev(qq,ch)=20*log10(EVM);
        evp(qq,ch)=pp;
        
        
    end
     
end
%end

%figure
%plot(ev)





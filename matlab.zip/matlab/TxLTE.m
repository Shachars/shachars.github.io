function [ofdm_sig,Pilots,Pilot_Pos,GenParam,FreqDomainData] = TxLTE(BW,N_subframes);

GenParam.Mod = '16Q';               % Modulation: 'QPSK' or '16Q' or '64Q'
GenParam.BW_Mh = BW;                % System bandwidth in Mhz: 20, 15, 10, 5, 3, 1.4
GenParam.CP = 1;                    % Generate cyclic prefix: 
                                         % 0- without Cyclic Prefix
                                            % 1- with Cyclic Prefix
GenParam.interpolation = 0; 
GenParam.N_sub_frames = N_subframes;         % Number of sub frames per run
GenParam.N_frames_in_subframe=14;   

GenParam =  CalcDerivedParams(GenParam); % Calculate derived parameters


Pilot_Pos = [GenParam.NOccupiedSC/4 : 10:  GenParam.NOccupiedSC*3/4]; % this is not the correct pilot structure of LTE. We use pilots only to measure and compensate the delay, amplitude and phase in the receiver.
    
[FreqDomainData, avg_pow] = GenOFDMData(GenParam); % Generate frequency domain data
FreqDomainData(Pilot_Pos,:) = max(max(FreqDomainData)); % use highest constellation point
%FreqDomainData=ones(size(FreqDomainData));
%FreqDomainData = [(0:1200-1)' (1:1201-1)'];    
Pilots = FreqDomainData(Pilot_Pos,:);


    % 3GPP signal
ofdm_sig = GenOFDMSig(FreqDomainData,GenParam);
ofdm_sig = ofdm_sig/sqrt(avg_pow);
end
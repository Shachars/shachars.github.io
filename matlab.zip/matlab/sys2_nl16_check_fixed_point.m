function  [REF,UL,clean_UL,Fs,Fc] = sys2_nl16_check_fixed_point(filename)
% version 7 t.v.
% in this case feedback from ADC + LO
% now after filter in UL band
% ver 14  - ls estimation of wf + not using wf^-1
% ver 15 - WF filter as a matrix
% ver 16 - dcd2 regularized, leakage Ul -ref in simulation
precomputed = 0;


% set these variables
center_freq=670; %700; %670; %670; %450; %450-0;
dec_factor = 20;
%delay = round(350*0.7*1.4);
L1 = 24; % filter length
WF_len = 15;
WF_en = 1; % 0 = disable 1 = enable
WF_type = 3; % 0 = ref unfiltered , 1 = ref filtered or 2 = DCD modified with filtered signal calculating R
% WF_type applies only to RLS_DCD. LS works always with WF_type=1.
WF_reduction = 0.1;%0.1; % adding noise to wf calculation

sigma2_h_dB = -20; % variance of the leakage filter in dB
sigma2_wf_dB = -20; % variance of the whitening filter in dB
wf_dl = 0.0001;
lambda = 1-2.5e-5;

delay = L1/2*dec_factor;

ff = 50/12e9; % [100 10000]/12e9;  % modulating frequency
ftdd = 0; %1500/12e9; % TDD
flag = 0;
% close all
load_sig = 1 ;
dec_len = 512; % decimation filter length
by_channel=1;
plotf = 0;

L2 = 900;
D = 2; % ???

if precomputed==0,
    if load_sig
        [P, C] = read_parameters('sim_data_sys_HB2.xlsx');
    else
        [P, C] = read_parameters('sim_data_sys_HB1 - shachar.xlsx');
    end
    tdd = ones(P.N,1);
    
    fs_sim=P.fs_sim*1e9;
    fs_DAC=P.Sampling_Rate*1e9;
    fs_ADC=fs_DAC;
    if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
        error('fs_sim must be a multiple of fs_ADC');
    end
    
    
    
    if load_sig
        %R=csvread('27_9_2016/multi carriers25dBm_with-50dBmCW_at_1880MHz.csv');
        R=load(filename);
        rx_adc2 = R(:,1)/2048;
        rx_adc = [zeros(delay,1); R(:,2)/2048];
        rx_adc = rx_adc(1:length(rx_adc2));
        N1 = floor(length(rx_adc)/dec_factor)*dec_factor;
        % N1 = (2500+2*L1-1)*dec_factor; % 4000 is period. 4000/16=250
        rx_adc = rx_adc(1:N1);
        rx_adc2 = rx_adc2(1:N1);
    else
        noise_en=1;
        N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC
        
        
        x_tx=signal_gen(P,C,N1,'DL',fs_DAC);
        % checking signal against clipping
        DAC_full_scale = 10^(P.DAC_FS_power/20);
        %fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
        fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
        clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
        fprintf('clipping probability %f \n',clip_prob);
        
        
        
        x_rx=signal_gen(P,C,P.N,'UL',fs_sim);
        if P.LO
            x_rx = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x_rx);
        end
        
        
        % adding quantization noise
        DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);
        PA_noise_rms = 10^((-174+P.PA_NF)/20)*sqrt(fs_sim/2);
        
        n_DAC = randn(N1,1)*DAC_noise_rms*noise_en;
        n_PA = randn(P.N,1)*PA_noise_rms*noise_en;
        
        x_tx1=x_tx+n_DAC;
        
        % analog domain
        DAC_out = DAC_analog(P,x_tx1,N1);
        
        % mix up
        if P.LO
            DAC_out_up = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*DAC_out);
            tx_sig = DAC_out_up * 10^(P.PA_gain/20) +n_PA;
        else
            tx_sig = DAC_out * 10^(P.PA_gain/20) + n_PA;
        end
        
        % PA
        %     [B, A]=butter(2,[1600 2900]*1e6/fs_sim*2);
        %     tx_sig = filter(B,A,tx_sig);
        %  tx_sig = HM(tx_sig,[1 0.001 0.0007],[1]);
        tx_sig = HM(tx_sig,[1 0.001 0.00017],[1]);
        %  tx_sig = HM(tx_sig,[1 0.001 0.00007],[1]); % this one was used in the report Evaluation and Selection of algorithms for UL.docx
        
        %plot_spect(tx_sig,fs_sim);
        if ftdd
            tdd = ( sin((1:P.N)*2*pi*ftdd)' >0 );
            
            tx_sig =tx_sig.*tdd;
            plot(tdd(1:dec_factor*4:end)/1000)
        else
            tdd = ones(P.N,1);
        end
        
        
        
        h_leak = [1 0 0 0 0  0 0 0 0 0 0];
        h13G = readprn('h_leak13g.prn');
        %h = [zeros(250,1); h13G] .* hamming(250+length(h13G));
        %         h_leak = resample( h13G(1:97),P.fs_sim,13)/10;
        
        h_leak_tv = resample([zeros(97,1); h13G(98:160)],P.fs_sim,13)/10;
        
        tx1 = filter(h_leak,1,tx_sig);
        %        tx2 = filter(h_leak_tv,1,tx_sig);
        
        %        Tx_leakage = (tx1 + 0.1*(tx1.*[zeros(512e3,1); ones(length(tx1)-512e3,1)]))* 10^(-P.Antenna_separation/20);
        Tx_leakage = (tx1 + 0.1*(sin((1:length(tx1))*2*pi*ff)'.*tx1.*[zeros(512e3,1); ones(length(tx1)-512e3,1)]))* 10^(-P.Antenna_separation/20);
        
        
        Thermal_noise_rms = 10^((-174+P.LNA_NF)/20)*sqrt(fs_sim/2);
        n_thermal =  randn(P.N,1)*Thermal_noise_rms*noise_en;
        rx_sig = Tx_leakage + n_thermal + x_rx;
        %rx nonlinearity rx_sig = HM(rx_sig,[1 0.1 0.7],[1]);
        
        
        
        % LNA
        
        x = rx_sig * 10^(P.LNA_gain/20);
        
        if P.LO
            x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
        end
        
        y = ADC_analog(P,x);
        
        ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
        
        n_ADC = randn(N1,1)*ADC_noise_rms*noise_en;
        
        rx_adc=y+n_ADC;
        rx_adc = [zeros(delay,1); rx_adc];
        rx_adc = rx_adc(1:N1);
        legend('Tx_leakage','Tx','UL signal');
        
        % estimating rx using additional ADC
        % todo - insert here the leakage from ul to dl
        x = tx_sig * 10^(-P.PA_Coupler/20) + x_rx * 10^(P.UL_Leak_REF/20);
        if P.LO
            x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
        end
        %ref nonlinearity x = HM(x,[1 0.1 0.7],[1]);
        
        y2 = ADC_analog(P,x);
        
        ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
        
        n_ADC2 = randn(N1,1)*ADC_noise_rms*noise_en;
        
        rx_adc2=y2+n_ADC2;
    end
end
if ~exist('P')
    error('No data in memory! use precomputed = 0');
end
ADC_full_scale = 10^(P.ADC_FS_power/20);
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC2 %.2f dbFS\n',10*log10(var(rx_adc2)))
clip_prob=sum(abs(rx_adc2)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)


if by_channel
    
    x = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc;
    x2 = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc2;
    
    if 1 %
        if 0 % raised cosine
            [Bf, Af]=firrcos(dec_factor*round(dec_len/dec_factor),1/2,0.4,dec_factor,'rolloff','sqrt');
        else
            % from sptool
            Fs = dec_factor;  % Sampling Frequency
            
            N     = dec_len;  % Order
            Fpass = 0.4;  % Passband Frequency
            Fstop = 0.6;  % Stopband Frequency
            Wpass = 1;    % Passband Weight
            Wstop = 1;    % Stopband Weight
            
            % Calculate the coefficients using the FIRLS function.
            Bf  = firls(N, [0 Fpass Fstop Fs/2]/(Fs/2), [1 1 0 0], [Wpass Wstop]);
        end
        
        rx_adc2_dec = upfirdn(x2,Bf,1,dec_factor);
        rx_adc2_dec = rx_adc2_dec(1:N1/dec_factor);
        rx_adc_dec = upfirdn(x,Bf,1,dec_factor);
        rx_adc_dec = rx_adc_dec(1:N1/dec_factor);
    else
        rx_adc2_dec = decimate(x2,dec_factor,dec_len,'fir');
        rx_adc_dec = decimate(x,dec_factor,dec_len,'fir');
    end
    
    
    
    L=L1; % filter length
    Remove_Edges_LS=L*2; % remove edges
    
    
    sigma2 = 0.5e-7;%
    
    addpath ../rls
    
    add_noise = 0;
    p = 1;
    
    delta = sigma2*(dec_factor)^2/(1-lambda);
    lambda1 = 0.9999; % for WF
    
    Nu =1  ;
    D = 5+2*(Nu-1)+2; % delay, = 1+ multiple of DCD_dec
    Nbit = 0;
    DCD_dec = 1;
    alfa_reduce_factor=1;
    
    disp('dcdrls')
    
    
    Mb = 32;
    H = 1; % approx the larger value of h
    
    reset=round(find(diff(tdd))/(dec_factor*fs_sim/fs_DAC));
    quant.R = 0*2^-Nbit;
    quant.h = 0*2^-Nbit;
    quant.r = 0*2^-(Nbit+8);
    quant.x = 0*2^-Nbit; %2^-Nbit; now
    
    
    %%%%%%%%%%%%%%%%%%% this point is the entry to the fixed point c model
    
    
    % increasing signal by dec_factor to reach reasonable signal power
    % with FS = 1
    disp('calculating WF using rls_dcd');
    
    
    delta1 = wf_dl/(1-lambda1); % divide by the gain of the block
    
    [e_dcdrls] = run_standalone_full_model_C(dec_factor*rx_adc2_dec,dec_factor*rx_adc_dec,WF_len,delta1,lambda1,L,delta,lambda,reset);
%     
%     [e_wf_dcd, ww] = run_standalone_C(dec_factor*rx_adc_dec(2:end),dec_factor*rx_adc_dec(1:end-1),WF_len-1,delta1,lambda1,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
%     [e_dcdrls, h8] = run_standalone_C(dec_factor*rx_adc2_dec_w(1:end-L),dec_factor*rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
scaling = 7.1;
    coeff = dec_factor/scaling;
    REF = coeff*rx_adc2_dec(end/2:end) * 10^(-P.LNA_gain/20);
    UL = coeff*rx_adc_dec(end/2:end) * 10^(-P.LNA_gain/20);
    clean_UL = e_dcdrls(end/2:end) * 10^(-P.LNA_gain/20);
    Fs = fs_ADC/dec_factor;
    Fc = center_freq;
    
    
end



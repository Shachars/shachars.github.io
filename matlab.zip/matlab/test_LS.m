clear
close all

L1 = 24;
dec_factor = 1;
N1 = 10000;
WF_len = 5;

if 1    
     x = randn(N1,1)+1j*randn(N1,1);
     interference = 100*exp(0.1j*(1:length(x))');
     y = x + interference;

end


    
if 1
   
    wf = lpc(y+1/10*sqrt(var(y))*(randn(size(x))+1j*randn(size(x))),WF_len-1);
  
    
   
   % remove zeros from wf
    a = fft(wf,1000);
    k = max(abs(a));
    b = a+0.01*k;
    wf = ifft(b);
    wf = wf(1:WF_len);
    wf = wf/wf(1);
    freqz(wf,1);
    
   % wf = [1 0 0 0 0];
    
    
    y_w = filter(wf,1,y);
  
     

    
    
end
    L=L1; % filter length
    Remove_Edges_LS=L*2; % remove edges
    K=1; % max harmonics
    A=zeros(N1/dec_factor-L+1-L-Remove_Edges_LS*2,L*K);
    for  k=1:K
        
        for i=0:L-1
            A(:,i+1+L*(k-1))=[x(L-i+Remove_Edges_LS:end-i-L-Remove_Edges_LS).^k];
        end
    end
    
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    sigma =  1e-5;
    h5=(A'*A+sigma*eye(size(A,2)))^-1*A'*y_w(L+Remove_Edges_LS:end-L-Remove_Edges_LS);
    figure(4)
    plot(real(h5))
        r3 = A*h5;
        e_w = y_w(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r3;
    
   e = filter(1,wf,e_w); 
   t = filter(1,wf,r3);
    
   figure(7)
   title('from LS');
   fs_ADC = 1e9; 
   center_freq = 0;
   plot_spect(y,fs_ADC/dec_factor,center_freq); 
    hold all
   plot_spect(y_w,fs_ADC/dec_factor,center_freq); 
   plot_spect(e_w,fs_ADC/dec_factor,center_freq); 
   plot_spect(e,fs_ADC/dec_factor,center_freq); 
   plot_spect(t(5*WF_len+1:end),fs_ADC/dec_factor,center_freq); 
   plot_spect(e(5*WF_len+1:end) - interference(5*WF_len+L+Remove_Edges_LS:end-L-Remove_Edges_LS),fs_ADC/dec_factor,center_freq); %filter(1,wf,r3)
   legend('original UL','after WF','after cancellation','inverse WF','noise added directly','noise added')
    
  
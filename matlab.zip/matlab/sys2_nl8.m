% version 7 t.v.
% in this case feedback from ADC + LO
% now after filter in UL band
precomputed =0;
if precomputed==0,
    clear
    precomputed = 0;
end

% set these variables
center_freq=770; %450; %450-0;
dec_factor = 32;
delay = round(350*0.7*1.4);
filename = '29_9/multi_carriere_CW_PS_AWS_WCS_173Car_25dBm_UL_1910MHz_-60dBm.csv';
L1 = 24; % filter length


ff =50/12e9; % [100 10000]/12e9;  % modulating frequency
ftdd = 0; %500/12e9; % TDD
flag = 0;
close all
load_sig = 0 ;
dec_len = 512; % decimation filter length
by_channel=1;



L2 = 900;
D = 2;


if precomputed==0,
    if load_sig
        [P, C] = read_parameters('sim_data_sys_HB2.xlsx');
    else
        [P, C] = read_parameters('sim_data_sys_HB1.xlsx');
    end
    tdd = ones(P.N,1);
    
    fs_sim=P.fs_sim*1e9;
    fs_DAC=P.Sampling_Rate*1e9;
    fs_ADC=fs_DAC;
    if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
        error('fs_sim must be a multiple of fs_ADC');
    end
    
    
    
    if load_sig
        %R=csvread('27_9_2016/multi carriers25dBm_with-50dBmCW_at_1880MHz.csv');
        R=load(filename);
        rx_adc2 = R(:,1)/2048;
        rx_adc = [zeros(delay,1); R(:,2)/2048];
        rx_adc = rx_adc(1:length(rx_adc2));
        N1 = length(rx_adc);
        % N1 = (2500+2*L1-1)*dec_factor; % 4000 is period. 4000/16=250
        rx_adc = rx_adc(1:N1);
        rx_adc2 = rx_adc2(1:N1);
    else
        noise_en=1;
        N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC
        
        
        x_tx=signal_gen(P,C,N1,'DL',fs_DAC);
        % checking signal against clipping
        DAC_full_scale = 10^(P.DAC_FS_power/20);
        %fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
        fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
        clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
        fprintf('clipping probability %f \n',clip_prob);
        
        
        
        x_rx=signal_gen(P,C,P.N,'UL',fs_sim);
        if P.LO
            x_rx = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x_rx);
        end
        
        
        % adding quantization noise
        DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);
        PA_noise_rms = 10^((-174+P.PA_NF)/20)*sqrt(fs_sim/2);
        
        n_DAC = randn(N1,1)*DAC_noise_rms*noise_en;
        n_PA = randn(P.N,1)*PA_noise_rms*noise_en;
        
        x_tx1=x_tx+n_DAC;
        
        % analog domain
        DAC_out = DAC_analog(P,x_tx1,N1);
        
        % mix up
        if P.LO
            DAC_out_up = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*DAC_out);
            tx_sig = DAC_out_up * 10^(P.PA_gain/20) +n_PA;
        else
            tx_sig = DAC_out * 10^(P.PA_gain/20) + n_PA;
        end
        
        % PA
        %     [B, A]=butter(2,[1600 2900]*1e6/fs_sim*2);
        %     tx_sig = filter(B,A,tx_sig);
        tx_sig = HM(tx_sig,[1 0.001 0.00017],[1]);
        %tx_sig = HM_tv(tx_sig,[1 0.001 0.0001],1,[0 0.1 0],fs_sim);
        
        %plot_spect(tx_sig,fs_sim);
        if ftdd
            tdd = ( sin((1:P.N)*2*pi*ftdd)' >0 );
            
            tx_sig =tx_sig.*tdd;
            plot(tdd(1:dec_factor*4:end)/1000)
        else
            tdd = ones(P.N,1);
        end
        
        
        
        h_leak = [1 0 0 0 0  0 0 0 0 0 0]*0.3;
        h13G = readprn('h_leak13g.prn');
        %h = [zeros(250,1); h13G] .* hamming(250+length(h13G));
        h_leak = resample( h13G(1:97),P.fs_sim,13)/10;
        
        h_leak_tv = resample([zeros(97,1); h13G(98:160)],P.fs_sim,13)/10;
        
        tx1 = filter(h_leak,1,tx_sig);
        %        tx2 = filter(h_leak_tv,1,tx_sig);
        
        %        Tx_leakage = (tx1 + 0.1*(tx1.*[zeros(512e3,1); ones(length(tx1)-512e3,1)]))* 10^(-P.Antenna_separation/20);
        Tx_leakage = (tx1 + 0.1*(sin((1:length(tx1))*2*pi*ff)'.*tx1.*[zeros(512e3,1); ones(length(tx1)-512e3,1)]))* 10^(-P.Antenna_separation/20);
        
        
        Thermal_noise_rms = 10^((-174+P.LNA_NF)/20)*sqrt(fs_sim/2);
        n_thermal =  randn(P.N,1)*Thermal_noise_rms*noise_en;
        rx_sig = Tx_leakage + n_thermal + x_rx;
        %rx nonlinearity rx_sig = HM(rx_sig,[1 0.1 0.7],[1]);
        
        figure(1)
        plot_spect(Tx_leakage,fs_sim);
        hold all
        plot_spect(tx_sig,fs_sim);
        
        plot_spect(n_thermal+x_rx,fs_sim);
        plot_spect(rx_sig,fs_sim);
        rcolor
        
        % LNA
        
        x = rx_sig * 10^(P.LNA_gain/20);
        
        if P.LO
            x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
        end
        
        y = ADC_analog(P,x);
        
        ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
        
        n_ADC = randn(N1,1)*ADC_noise_rms*noise_en;
        
        rx_adc=y+n_ADC;
        rx_adc = [zeros(delay,1); rx_adc];
        rx_adc = rx_adc(1:N1);
        figure(1)
        legend('Tx_leakage','Tx','UL signal');
        
        % estimating rx using additional ADC
        x = tx_sig * 10^(-P.PA_Coupler/20);
        if P.LO
            x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
        end
        %ref nonlinearity x = HM(x,[1 0.1 0.7],[1]);
        
        y2 = ADC_analog(P,x);
        
        ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
        
        n_ADC2 = randn(N1,1)*ADC_noise_rms*noise_en;
        
        rx_adc2=y2+n_ADC2;
    end
end
if ~exist('P')
    error('No data in memory! use precomputed = 0');
end
ADC_full_scale = 10^(P.ADC_FS_power/20);
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC2 %.2f dbFS\n',10*log10(var(rx_adc2)))
clip_prob=sum(abs(rx_adc2)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)

figure(5)
plot_spect(rx_adc* 10^(-P.LNA_gain/20),fs_ADC);
hold all
plot_spect(rx_adc2* 10^(-P.LNA_gain/20),fs_ADC);
rcolor
legend('rx sampled','ref sampled');

if by_channel
    
    x = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc;
    x2 = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc2;
    
    if 1 %
        if 0 % raised cosine
            [Bf, Af]=firrcos(dec_factor*round(dec_len/dec_factor),1/2,0.4,dec_factor,'rolloff','sqrt');
        else
            % from sptool
            Fs = dec_factor;  % Sampling Frequency
            
            N     = dec_len;  % Order
            Fpass = 0.4;  % Passband Frequency
            Fstop = 0.6;  % Stopband Frequency
            Wpass = 1;    % Passband Weight
            Wstop = 1;    % Stopband Weight
            
            % Calculate the coefficients using the FIRLS function.
            Bf  = firls(N, [0 Fpass Fstop Fs/2]/(Fs/2), [1 1 0 0], [Wpass Wstop]);
        end
        
        
        
        rx_adc2_dec = upfirdn(x2,Bf,1,dec_factor);
        rx_adc2_dec = rx_adc2_dec(1:N1/dec_factor);
        rx_adc_dec = upfirdn(x,Bf,1,dec_factor);
        rx_adc_dec = rx_adc_dec(1:N1/dec_factor);
    else
        rx_adc2_dec = decimate(x2,dec_factor,dec_len,'fir');
        rx_adc_dec = decimate(x,dec_factor,dec_len,'fir');
    end
    
    
    
    
    z1 = rx_adc_dec * 10^(-P.LNA_gain/20); % normalize back to input
    figure(2)
    plot_spect(z1,fs_ADC/dec_factor,center_freq);
    hold all
    rcolor
    
    L=L1; % filter length
    Remove_Edges_LS=L*2; % remove edges
    K=1; % max harmonics
    A=zeros(N1/dec_factor-L+1-L-Remove_Edges_LS*2,L*K);
    for  k=1:K
        
        for i=0:L-1
            A(:,i+1+L*(k-1))=[rx_adc2_dec(L-i+Remove_Edges_LS:end-i-L-Remove_Edges_LS).^k];
        end
    end
    figure(3)
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    sigma =  1e-3;
    h5=(A'*A+sigma*eye(size(A,2)))^-1*A'*rx_adc_dec(L+Remove_Edges_LS:end-L-Remove_Edges_LS);
    
    
    
    
    
    
    
    lambda = 1-2.5e-5;
    e_lms_FD=[NaN NaN];
    clear name
    name{1}='after ADC norm to input';
    name{2}='reference';
    name{3}='LS';
    p=4;
    if 0
        disp('lms FD')
        name{p}='lms FD'; p=p+1;
        
        mu  = 0.01;
        LL = 512;
        len1 = floor(length(rx_adc2_dec)/LL)*LL;
        ha = dsp.FrequencyDomainAdaptiveFilter('LeakageFactor',0.99999,'Method','constrained FDAF','Length',L,'StepSize',mu,'BlockLength',LL,'AveragingFactor',0.1,'Offset',0.01);
        [yh,e_lms_FD] = step(ha,rx_adc2_dec(1:len1),rx_adc_dec(1:len1));
        
    end
    e_lms=[NaN NaN];
    if 0
        disp('lms')
        name{p}='lms'; p=p+1;
        mu=0.001;
        [e_lms,h6]=my_lms(rx_adc2_dec(1:end-L),rx_adc_dec(1:end-L),L,mu,h5(end:-1:1)*0,1);
    end
    %     hold on
    e_affine=[NaN NaN];
    if 0
        disp('affine')
        name{p}='affine Ord=8'; p=p+1;
        
        mu = 0.05;                    % Step size
        po = 8;                      % Projection order
        offset = 0.005;               % Offset for covariance matrix
        h = dsp.AffineProjectionFilter('Length', L, ...
            'StepSize', mu, 'ProjectionOrder', po, ...
            'InitialOffsetCovariance',offset);
        [yh,e_affine] = step(h,rx_adc2_dec,rx_adc_dec);
        e_affine = e_affine(1:end-L);
    end
    e_rls = [NaN NaN];
    if 0
        disp('RLS')
        name{p}='RLS'; p=p+1;
        
        
        % SlidingWindowBlockLength=1024;%'Householder sliding-window RLS'
        h = dsp.RLSFilter(L,'Method','Conventional RLS', 'ForgettingFactor', lambda); % 'SlidingWindowBlockLength', SlidingWindowBlockLength
        
        [yh,e_rls] = step(h,rx_adc2_dec(L:end-1),rx_adc_dec(L:end-1));
        
        
        %         for p = 0:3
        %         [yh,e_rls1] = step(h,rx_adc2_dec(L+p:4:end-1),rx_adc_dec(L+p:4:end-1));
        %         e_rls(1+p:4:length(e_rls1)*4) = e_rls1;
        %         end
        e_rls = e_rls(1:end-L*5);
    end
    e_lat=[NaN NaN];
    if 0
        disp('Lattice')
        name{p}='Lattice'; p=p+1;
        
        miu = 0.05; % only for gradient
        
        del = 1; % 'Least-squares Lattice' |'QR-decomposition Least-squares Lattice' |'Gradient Adaptive Lattice'
        h = dsp.AdaptiveLatticeFilter('Method','Gradient Adaptive Lattice'  ,'Length', L, ...
            'ForgettingFactor', lambda, 'InitialPredictionErrorPower', del, 'StepSize' , miu, 'AveragingFactor', 0.9);
        [yh,e_lat] = step(h,rx_adc2_dec,rx_adc_dec);
    end
    e_ftf=[NaN NaN];
    if 0
        disp('ftf')
        name{p}='ftf'; p=p+1;
        
        h = dsp.FastTransversalFilter('Length',L,'ForgettingFactor',lambda);
        [yh,e_ftf] = step(h,rx_adc2_dec,rx_adc_dec);
    end
    e_myrls = [NaN NaN];
    addpath ../rls
    if 0
        disp('myRLS')
        name{p}='myRLS'; p=p+1;
        
        
        delta = 1000;
        
        [e_myrls, h7] = my_rls(rx_adc2_dec(1:end-L+1),rx_adc_dec(L:end),L,delta,lambda);
        
    end
    e_dcdrls = [NaN NaN];
    addpath ../rls
    for Nbit = 0; %12:2:16
        D = 5; % delay
        Nu = 1;
        
        if 1
            disp('dcdrls')
            name{p}=['dcd rls Nu = ' num2str(Nu) '  Nbit = ' num2str(Nbit) ]; p=p+1;
            
            
            delta = 1000/(dec_factor^2);
            Mb = 32;
            H = 1; % approx the larger value of h
            reset=round(find(diff(tdd))/(dec_factor*fs_sim/fs_DAC));
            quant.R = 0*2^-Nbit;
            quant.h = 0*2^-Nbit;
            quant.r = 0*2^-(Nbit+8);
            quant.x = 0*2^-Nbit; %2^-Nbit; now
            %       compared with
            %       max(max(abs(r))) =   0.0154
            %       max(max(abs(x))) =   0.23
            %       max(max(abs(h)))=    0.7071
            %       max(max(abs(R)))=    5.3
            
            
            % increasing signal by dec_factor to reach reasonable signal power
            % with FS = 1
            if 1
            [e_dcdrls, h8] = rls_dcd(dec_factor*rx_adc2_dec(1:end-L),dec_factor*rx_adc_dec(L:end-1),L,delta,lambda,Nu,Mb,H,1,D,reset,quant);
            e_dcdrls = e_dcdrls/dec_factor;
            else
            [e_dcdrls, h8] = rls_dcd(rx_adc2_dec(1:end-L),rx_adc_dec(L:end-1),L,delta,lambda,Nu,Mb,H,1,D,reset,quant);
            end
            %[e1, h1] = rls_dcd(x,d,M,delta,lambda,Nu,Mb);
            
        end
        
        
        
        
        figure(4)
        plot(real(h8(:,end-L1)))
        rcolor
        
        
        r3 = A*h5;
        rx_adc1_dec = rx_adc_dec(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r3;
        %     figure(102)
        %     plot2(e_rls,rx_adc1_dec)
        %
        %     figure
        %     plota(rx_adc1_dec)
        z1 = rx_adc1_dec(1:end-1) * 10^(-P.LNA_gain/20); % normalize back to input
        %figure
        figure(2)
        if flag==0
            flag =1;
            plot_spect(rx_adc2_dec * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(z1(end/2:end-L),fs_ADC/dec_factor,center_freq);
            
            
            plot_spect(e_lms_FD(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_lms(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_affine(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_rls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_lat(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_ftf(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_myrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            %plot_spect(e_dcdrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
        end
        plot_spect(e_dcdrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
        
        %legend('after ADC norm to input','reference','after digital cancellation','after digital cancellation (LMS)');
        legend(name)
    end
else
    L=L2;
    K=1; % max harmonics
    A=zeros(N1-L+1,L*K);
    for  m=1:K
        
        for i=0:L-1
            A(:,i+1+L*(m-1))=[rx_adc2(L-i:end-i-L).^m];
        end
    end
    figure(5)
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    
    h5=(A'*A+1e-5*eye(size(A,2)))^-1*A'*rx_adc(L:end-L);
    hold on
    plot(abs(h5))
    rcolor
    
    
    r3 = A*h5;
    rx_adc1 = rx_adc(L:end-L) - r3;
    
    z1 = rx_adc1 * 10^(-P.LNA_gain/20); % normalize back to input
    %figure
    figure(1)
    plot_spect(z1,fs_ADC);
    rcolor
    legend('after ADC norm to input','reference','after digital cancellation');
    
    
end


%     figure(4)
%     plot_spect_mc(z1,fs_ADC/dec_factor,center_freq);
%     title('high res')
%ss(:,pppp)=e_dcdrls;pppp=pppp+1;
figure
plot((0:length(e_dcdrls)-1)/(fs_ADC/dec_factor)*1e3,real(e_dcdrls))
% hold all
% plot((0:length(rx_adc1_dec)-1)/(fs_ADC/dec_factor)*1e3,real(rx_adc1_dec))

xlabel('ms')
title('output signal (real part)');
% show tdd signal
%hold all
%plot((0:P.N/(dec_factor*4)-1)/(fs_ADC/dec_factor)*1e3,tdd(1:dec_factor*4:end)/100)
disp('output variable is clean_UL');
clean_UL=e_dcdrls;


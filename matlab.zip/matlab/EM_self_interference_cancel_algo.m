function [h,g,g_s,g_e,out] = EM_self_interference_cancel_algo(x,d,lambda_rls,lambda_reset,delta,delta_h,delta_ni,reset,WF_len,h_leak,flag_diagonal_loading)

M_g = WF_len;
M_h = h_leak;
N = length(x);
u = zeros(M_h,N-M_h);
Mb = 16;

for i=1:N-M_h
    u(:,i)=x(i:1:i+M_h-1);
end

P = 1; % clock to sample ratio
r = zeros(M_h,1);
beta0 = zeros(M_h,1);
Rd = delta_h*eye(M_h,M_h);
t = [delta_h; zeros(M_h-1,1)];

%%%
m=0;
alfa=1;

P_rls = eye(M_h)*delta;
P_t_t = zeros(M_g + 1);
mu = zeros(M_g + 1,1);
h = zeros(M_h,1);
g = zeros(M_g,1); % can't set to zero or the algo won't converge
g_s = 1e-8;
g_e = 1e-8;
eta = 1-2e-8;
out = zeros(N,1);
x_t_t = mu;
Q = eye(M_g + 1)*delta;
ni = delta_ni;
for n=M_h:N-M_h
    if mod(n,10000)==0, fprintf('%d  ',n);end
    if (reset(n) == 1)
        disp('reset enabled ...');
        lambda = lambda_reset;
    else
        lambda = lambda_rls;
    end
    
    z = d(n) - h'*u(:,n- M_h + 1); % todo - correct the 0.05
    Phi = [-g.',0;eye(M_g),zeros(M_g,1)];
    e1 = [1;zeros(M_g,1)];
    % propogate
    x_t_t_1 = Phi*x_t_t;
    P_t_t_1 = Phi*P_t_t*Phi.'+g_s*e1*e1.';
    k = P_t_t_1*e1/(e1.'*P_t_t_1*e1+g_e);
    % update
    x_t_t = x_t_t_1 + k*(z-e1.'*x_t_t_1);
    P_t_t = (eye(M_g+1)-k*e1.')*P_t_t_1;
    
    Q = lambda*Q + P_t_t + x_t_t*x_t_t.' + (1-lambda)*delta*eye(size(Q));
    
    g = -inv(Q(2:end,2:end))*Q(2:end,1); % todo - output the condition number here and also show the g as the number of samples grows when the estimation is bad..and why is delta_g so important here?
    ni = eta*ni + (z^2-2*z*x_t_t(1)+P_t_t(1,1)+x_t_t(1)*x_t_t(1)) + (1-eta)*delta_ni;
    g_e = ((1-eta)/(1-eta^(n-M_h+1)))*ni;
    g_s = ((1-lambda)/(1-lambda^(n-M_h+1)))*(Q(1,1)+Q(1,2:end)*g);
    
    %% RLS
    if(~flag_diagonal_loading)
        y = d(n) - x_t_t(1);
        e = y - h'*u(:,n- M_h + 1);
        p = P_rls*u(:,n- M_h + 1);
        c = lambda + u(:,n- M_h + 1)'*p;
        k = p/c;
        P_rls = (lambda^-1)*P_rls-(lambda^-1)*k*u(:,n- M_h + 1)'*P_rls;
        h = h + k*conj(e);
    else
        %%%%%%%%
        if mod(n,10000)==0, fprintf('%d  ',n);end
        % u shift reg
        x_shreg = u(:,n- M_h + 1);
        
        t = lambda*t + conj(x_shreg(1))*x_shreg(1:M_h) + (1-lambda)*delta_h*[1;zeros(M_h-1,1)];
        i = mod((n-1),M_h)+1;
        Rd(:,i) =  [conj(t(i:-1:1)); t(2:end-i+1)];
        
        y = zeros(M_h/P,1);
        for i=0:P-1
            for j=0:M_h/P-1
                y(j+1)=y(j+1)+conj(h(i+j*P+1))*x_shreg(i+j*P+1);
            end
        end
        
        e=d(n)-x_t_t(1)- sum(y);
        
        %
        for i=0:P-1
            for j=0:M_h/P-1
                beta0(i+j*P+1) = lambda*r(i+j*P+1)+conj(e)*x_shreg(i+j*P+1)-(1-lambda)*delta_h*(h(i+j*P+1));
            end
        end
        
        deltah = zeros(M_h,1);
        
        Rcomp=Rd(M_h,M_h)/2*alfa;
        
        rr = [real(beta0); imag(beta0)];
        arr = abs(rr);
        
        p1=find(arr>Rcomp*2,1,'first');
        p2=find(arr>Rcomp,1,'first');
        p3=find(arr>Rcomp/2,1,'first');
        
        zero_alfa = 0;
        
        if ~isempty(p1)
            if m>0
                m = m - 1;
                alfa = alfa * 2;
            end
            p = p1;
        elseif ~isempty(p2)
            alfa = alfa;
            p = p2;
        elseif ~isempty(p3)
            if m<Mb
                alfa = alfa / 2;
                p = p3;
                m = m + 1;
            else
                p = p3;
                zero_alfa = 1;
            end
        else
            % no p
            zero_alfa = 1;
            p = 1;
            if m<Mb
                m = m + 2;
                alfa = alfa / 4;
            end
        end
        
        alfas = alfa * sign(rr(p));
        if             zero_alfa
            alfas = 0;
        end
        
        if p>M_h
            jflag = 1;
            pm = p-M_h;
        else
            jflag = 0;
            pm = p;
        end
        
        
        if ~jflag
            deltah(pm) = alfas;
        else
            deltah(pm) = 1j*alfas;
        end
        
        r = beta0 - alfas*Rd(:,pm)*1j^jflag;
        
        h=h+deltah;
        
        
    end
    out(n) = x_t_t(1);% estimation of the UL signal
    
end




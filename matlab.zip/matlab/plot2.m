function plot2(x,y,s1,s2)
figure
if norm(imag(x))+norm(imag(y))~=0
    x = abs(x);
    y = abs(y);
end
plot(x);
hold all
plot(y);
if nargin<4
legend('1','2')
else
    legend(s1,s2);
end
end
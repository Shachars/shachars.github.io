clear 
close all
[P, C] = read_parameters('sim_data_DL_HB.xlsx');
fs_sim=P.fs_sim*1e9;
fs_DAC=P.Sampling_Rate*1e9;
if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
    error('fs_sim must be a multiple of fs_ADC');
end
N_welch=50000;
N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC
N = N1*(fs_sim/fs_DAC);
% ideal channel generation
No_channels = length(C);
beta=0.2;
x_all_in_freq=zeros(N1,1);
total_power=0;
for ch = 1:No_channels,
  fftbin=fs_DAC/N1;
    L_ch=C(ch).BW*1e6/fftbin/2;
    if L_ch<10
        error('BW too low or simulation too short');
    end
    if C(ch).Freq*1e6+C(ch).BW*1e6/2*(1+beta)>=fs_DAC/2
        error('Signal pass Nyquist frequency');
    end
% 
%     
    w = raised_cosine((-round(L_ch*(1+beta)):round(L_ch*(1+beta))-1)/L_ch,beta);
    x=xrandn(length(w),1);
    x=x.*w;
    freq_range=round(C(ch).Freq*1e6/fftbin)-round(L_ch*(1+beta)):round(C(ch).Freq*1e6/fftbin)+round(L_ch*(1+beta)-1);
    x_all_in_freq(freq_range)=x_all_in_freq(freq_range)+x*10^(C(ch).Amp/20)/(sqrt(L_ch));
    total_power = total_power+10^(C(ch).Amp/10);
%
    
end

x1=real(ifft(x_all_in_freq,N1)*N1);
 




% adding quantization noise
DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);

n_ADC = randn(N1,1)*DAC_noise_rms;

x1=x1+n_ADC;


x2=repmat(x1,1,fs_sim/fs_DAC)';
x2=x2(:);

hold all
pwelch(x2,kaiser(N_welch,20),N_welch/2,N_welch,fs_sim);

    
%x2 = interp(x1,fs_sim/fs_DAC); % temporarily interpolate for using jitter.

% add jitter
if P.Jitter_simulation_enable,
    N0=4*10^(P.Jitter_at_Corner/10)*pi^2*(P.Jitter_Corner*1e3)^2;
    sigmateta=sqrt(N0/fs_sim);
    n1=randn(N,1)*sigmateta/(2*pi*fs_sim);
    J_wiener=filter(1,[1 -1],n1); % integrator
    J_flat=randn(N,1)*P.Flat_jitter*1e-12;
    J=(J_wiener+J_flat)/(1/fs_sim);
    J=J-min(J); % make it positive only and little constant time shift doesn't matter.

    % implementing jitter using linear interpolation approximation
    x3=x2(1:end-1).*(1-J(1:end-1))+x2(2:end).*J(1:end-1);
else
    x3=x2;
end

hold all
pwelch(x3,kaiser(N_welch,20),N_welch/2,N_welch,fs_sim);
rcolor

[Bdac_lp, Adac_lp]=butter(P.DAC_filter_order,P.DAC_filter_cutoff*1e9/fs_sim*2);
%figure(2);
 
%plot the filter
figure(2);
[h,f] = freqz(Bdac_lp,Adac_lp,N_welch,fs_sim);
plot(f/1e9,20*log10(abs(h)));
axis([0 fs_sim/2e9 -100 0]);
grid on
xlabel('Frequency (GHz)');
ylabel('dB');
title('DAC Filter Response');



figure(1);

x4=filter(Bdac_lp,Adac_lp,x3);
pwelch(x4,kaiser(N_welch,20),N_welch/2,N_welch,fs_sim);
rcolor


legend('DAC output','after jitter','after filter')
% checking signal against clipping
DAC_full_scale = 10^(P.DAC_FS_power/20);
fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale))
fprintf('Total signal %.2f dbm\n',10*log10(total_power))
clip_prob=sum(abs(x1)>DAC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)
  



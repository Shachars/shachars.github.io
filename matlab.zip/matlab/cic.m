function out = cic(in,N)
% this function simulates the cascade integrate comb filter ( 3 modules)
% assumes in - N X 1 (12bits sign extended)

% the CIC gain is (N+1)^3, and the input is 11 bits. Without shifting, 
% the output full range is 32 bits (the MSBs are taken as output), therefore a gain of 2^21 / (N+1)^3 is required.

% all adds are 32 bits
% out is 16 bits MSBs
len_in = length(in);

x_D2 = 0;
x_D1 = 0;
x = 0;

k = 1;
y = 0;
y_out = 0;
y_D1 = 0;
y_D2 = 0;

for i=1:len_in   
    x_out = x;
    x = x_D1 + x;
    x_D1 = x_D2 + x_D1;
    x_D2 = in(i) + x_D2;

    if(mod(i,N) == 0) % decimate by N
        y_out(k) = -y + (-y_D1 + (-y_D2 + x_out));
        y = -y_D1 + (-y_D2 + x_out); 
        y_D1 = -y_D2 + x_out;
        y_D2 = x_out;
        k = k + 1;
    end
end

out = y_out/((1/(N+1)^3));


% normalize
% ShR = floor(21 � 3 log2(N+1))




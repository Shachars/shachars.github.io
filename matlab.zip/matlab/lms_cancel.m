N=100000;
close all
my_lms=1;
x=randn(N,1);
L=100;
lp=firls(L,[0 0.1 0.2 .5]*2,[1 1 0 0],[1 1])';
lp1=firls(L,[0 0.05 0.1 .5]*2,[1 1 0 0],[1 1])';
%x=filter(lp,1,x)+x/10;

h=[ 0 1 0 0 1];
K=length(h);

snr=500;
n=randn(N,1)*10^(-snr/20);
snr1=90;
rx=randn(N,1)*10^(-snr1/20);
rx=filter(lp1,1,rx);
n=n+rx;

y=filter(h,1,x)+n;
varying=(sin(2*pi*(1:N)/1000000)'*0.2+1)/2;
varying=varying/mean(varying);

%y=y.*varying;

if my_lms
%     X=fft(x);
% C=abs(X)/sqrt(N);
% X=X./C;
% x=ifft(X);
% Y=fft(y);
% ;
% Y=Y./C;
% y=ifft(Y);
% 
    
    
    
    
thm=zeros(N,K);
sl=thm;
mu=0.01;
mu1=0.00001;
e=zeros(N,1);

for i=K:N
    e(i)=y(i)-x(i-K+1:i).'*thm(i-1,:).';
    sl(i,:) = sl(i-1,:) + mu1*e(i)*x(i-K+1:i).';
    thm(i,:) = thm(i-1,:) + mu*e(i)*x(i-K+1:i).'+sl(i-1,:);
end
close all
else
%[thm, yh] = rarmax([y x],[0 5 0 1],'kf',eye(5)*0.001);
[thm, yh] = rarmax([y x],[0 5 0 1],'ff',0.999);
%[thm yh] = rarmax([y x],[0 5 0 1],'ug',0.01);
% if 0
% thm=zeros(N,K);
% 
% [lpthm, ~]=firrcos(12000,0.001,0.3,1,'rolloff'); plota(lpthm)
% 
% 
% for i=1:K
% %     tt=decimate(thm1(:,i),10);
% %     pp=tt;
% %     pp=filtfilt(lpthm,1,tt);
% %     thm(:,i)=interp(pp,10);
%     thm(:,i)=filtfilt(lpthm,1,thm1(:,i));
% end
% end
%thm=thm1;
% 
if 1
    y1=zeros(N,1);
    for j=-3
        for i=K:N
            y1(i)=x(i-K+1:i-1).'*thm(i+j,1:end-1).';
        end
        figure
        a(j+5)=var(yh(10:100)-y1(10:100));
    end
end
e=-y1+y;

end
figure
plot(thm(:,1))
hold on
plot(varying,'r')

figure


plot(diff(thm(5:end,1)))
20*log10([sqrt(var(diff(thm(end/2:end,1)-varying(end/2:end)))) sqrt(var((thm(end/2:end,1)-varying(end/2:end)))) sqrt(var((e(end/2:end,1))))])


plot2(e(end-100:end),n(end-100:end),'est','real')



function  [REF,UL,clean_UL,UL_orig,Thermal_noise,Fs,Fc] = PostADCCancellation(rx_adc,rx_adc2,ul_adc,noise_sig_adc,N1,Cfg)
% This function gets a Cfg struct with channel and algorithm parameters and
% with a filename for the measured UL and REF.
% Output is the REF, UL signal and the Ul signal after the cancellation
% algorithm
format long;

%% Load parameters from the Cfg struct
center_freq = Cfg.center_freq;
L = Cfg.h_leak;
Nu = Cfg.Nu;
D = 5+2*(Nu-1)+2; % delay, = 1+ multiple of DCD_dec
DCD_dec = Cfg.DCD_dec;
Mb = Cfg.Mb;
WF_len = Cfg.WF_len;
WF_en = Cfg.WF_en; % 0 = disable 1 = enable
lambda_h_leak = Cfg.lambda;
plotf = Cfg.debug_plot;
lambda_wf = Cfg.lambda; % for WF
RlsDcdCfg.P = Cfg.clock_mul;
RlsDcdCfg.approx_beta0 = Cfg.approx_beta0;
RlsDcdCfg.approxR = Cfg.use_approx_R;
dec_factor = Cfg.dec_factor;
fs_ADC = Cfg.ADC.Fs*1e9;
fs_DAC = Cfg.DAC.Fs*1e9;

%% DDC
[rx_adc_dec,rx_adc2_dec,ul_adc_dec,noise_adc_dec,reset] = DigitalDownConversion(Cfg,rx_adc,rx_adc2,ul_adc,noise_sig_adc,N1);


%% Run RLS-DCD
if(Cfg.use_matlab == 0) % run the matlab implementation
    if(Cfg.algo == 0)
        if WF_en
            % increasing signal by dec_factor to reach reasonable signal power
            % with FS = 1
            
            if(Cfg.save_logs)
                log_t = real(dec_factor*rx_adc_dec(2:end));
                save ref_r.txt log_t -ascii -double;
                log_t = imag(dec_factor*rx_adc_dec(2:end));
                save ref_q.txt log_t -ascii -double;
                log_t = real(dec_factor*rx_adc_dec(1:end-1));
                save ul_r.txt log_t -ascii -double;
                log_t = imag(dec_factor*rx_adc_dec(1:end-1));
                save ul_q.txt log_t -ascii -double;
            end
            
            disp('Calculating Whitening filter using rls_dcd ... ');
            [~, ww] = rls_dcd_algo(dec_factor*rx_adc_dec(2:end),dec_factor*rx_adc_dec(1:end-1),WF_len-1,Cfg.delta_wf,lambda_wf,Nu,Mb,DCD_dec,D,reset,plotf,RlsDcdCfg);
            wf_dcd = [ones(size(ww,2),1) -ww(end:-1:1,:).'];
            
            conv_h = (abs(sum(wf_dcd(2:end,:)-wf_dcd(1:end-1,:),2)));
            if(Cfg.debug_plot)
                % Show the convergence of the WF
                figure(444);plot(1e3*[1:1:length(conv_h)]*1/(fs_ADC/dec_factor),20*log10(conv_h));
                grid on;
                title('Convergence of the WF filter using RLS-DCD with regularization, Rd approx and Q_R');
                ylabel('Consecutive difference [dB]');
                xlabel('Time [ms]');
                
                % Show the final WF filter (magnitude and phase)
                figure(453);
                hold all;
                freq_vec = (Cfg.center_freq*1e6 + (fs_DAC/Cfg.dec_factor/2)*[-1:2/512:1-2/512])/1e6;
                plot(freq_vec,fftshift(20*log10(abs(fft(wf_dcd(end-WF_len-1,:),512)))));grid on;legend_add(num2str(WF_len));
                xlabel('Frequency [MHz]');
                ylabel('Magnitude [dB]');
                title('Whitening Filter Response')
                figure(454);
                hold all;
                plot(freq_vec,fftshift(unwrap(angle(fft(wf_dcd(end-WF_len-1,:),512)))));grid on;legend_add(num2str(WF_len));
                xlabel('Frequency [MHz]');
                ylabel('Phase [rad]');
                title('Whitening Filter Response')
                
                figure(888)
                hold all
                freqz(wf_dcd(end-WF_len-1,:),1);
                title('Whitening Filter');
                
            end
        else
            wf_dcd = zeros(length(rx_adc_dec),WF_len);
            wf_dcd(:,1) = ones(length(rx_adc_dec),1);
        end
        
        %% Filtering the REF and RX signals using the WF filters as they conerge in the RLS DCD reg
        disp('Whitening the REF and RX signals ... ')
        rx_adc_dec(1:WF_len-1) = 0;
        rx_adc2_dec(1:WF_len-1) = 0;
        rx_adc_dec_w = zeros(length(rx_adc_dec)-WF_len,1);
        for i=1:length(rx_adc_dec)-WF_len
            t=rx_adc_dec(i+WF_len-1:-1:i);
            rx_adc_dec_w(i) = wf_dcd(i,:)*t;
        end
        rx_adc2_dec_w = zeros(length(rx_adc2_dec)-WF_len,1);
        for i=1:length(rx_adc2_dec)-WF_len
            t=rx_adc2_dec(i+WF_len-1:-1:i);
            rx_adc2_dec_w(i) = wf_dcd(i,:)*t;
        end
        
        disp('Calculating Leakage filter using rls_dcd ... ');
        
        if(Cfg.save_logs)
            log_t = real(dec_factor*rx_adc2_dec_w(1:end-L));
            save('ref_w_r.txt','log_t','-double','-ascii');
            log_t = imag(dec_factor*rx_adc2_dec_w(1:end-L));
            save('ref_w_q.txt','log_t','-double','-ascii');
            log_t = real(dec_factor*rx_adc_dec_w(1:end-1));
            save('ul_w_r.txt','log_t','-double','-ascii');
            log_t = imag(dec_factor*rx_adc_dec_w(1:end-1));
            save('ul_w_q.txt','log_t','-double','-ascii');
        end
        
        if(Cfg.algo_HLS == 0)
            disp('Running RLS ...');
            [out_e, h_leak] = rls_dcd_algo([0;dec_factor*rx_adc2_dec_w(2:end-L)],[0;0;dec_factor*rx_adc_dec_w(2:end-L-1)],L,Cfg.delta_h_leak,lambda_h_leak,Nu,Mb,DCD_dec,D,reset,plotf,RlsDcdCfg);
            %         [out_e, h_leak] = joint_rls([0;dec_factor*rx_adc2_dec_w(2:end-L)],[0;0;dec_factor*rx_adc_dec_w(2:end-L-1)],Cfg.WF_len,Cfg.h_leak,Cfg.delta_wf,Cfg.lambda,Cfg.delta_h_leak,Cfg.lambda)
        else
            disp('Running HLS Implementation RLS ...');
            [out_e, h_leak] = rls_dcd_algo_HLS_implmnt([0;dec_factor*rx_adc2_dec_w(2:end-L)],[0;0;dec_factor*rx_adc_dec_w(2:end-L-1)],L,Cfg.delta_h_leak,lambda_h_leak,Nu,Mb,DCD_dec,D,reset,plotf,RlsDcdCfg);
        end
        
        if(Cfg.debug_plot)
            % Show the final leakage filter (magnitude and phase)
            figure(455);
            hold all;
            freq_vec = (Cfg.center_freq*1e6 + (fs_DAC/Cfg.dec_factor/2)*[-1:2/512:1-2/512])/1e6;
            plot(freq_vec,fftshift(20*log10(abs(fft(h_leak(:,end-L-1,:),512)))));grid on;legend_add(num2str(L)); % todo - 512 needs to be aparameter
            xlabel('Frequency [MHz]');
            ylabel('Magnitude [dB]');
            title('Leakage Filter Response')
            figure(456);
            hold all;
            plot(freq_vec,fftshift(unwrap(angle(fft(h_leak(:,end-L-1,:),512)))));grid on;legend_add(num2str(L));
            xlabel('Frequency [MHz]');
            ylabel('Phase [rad]');
            title('Leakage Filter Response')
        end
        
        %% Pass the signal thru the adaptive filters
        disp('Cancelling the DL ... ');
        if(Cfg.algo_HLS == 0)
            ref_to_cancel = zeros(length(rx_adc2_dec),1);
            rx_adc2_dec(1:L-1) = 0;
            for i=1:length(rx_adc2_dec)-L-WF_len-1
                t=rx_adc2_dec(i+(L)-1:-1:i);
                ref_to_cancel(i) = conj(h_leak(:,i)).'*t;
            end
            e_dcdrls = rx_adc_dec(L:end) - ref_to_cancel(1:end-L+1); % cancel the DL from the UL signal
            if(Cfg.debug_plot)
                log_t = real(e_dcdrls*Cfg.dec_factor);
                save('e_dcd_r.txt','log_t','-double','-ascii');
                log_t = imag(e_dcdrls*Cfg.dec_factor);
                save('e_dcd_q.txt','log_t','-double','-ascii');
                
                log_t = real(ref_to_cancel*Cfg.dec_factor);
                save('ref_to_cancel_r.txt','log_t','-double','-ascii');
                log_t = imag(ref_to_cancel*Cfg.dec_factor);
                save('ref_to_cancel_i.txt','log_t','-double','-ascii');
                
                log_t = real(rx_adc_dec*Cfg.dec_factor);
                save('rx_adc_dec_r.txt','log_t','-double','-ascii');
                log_t = imag(rx_adc_dec*Cfg.dec_factor);
                save('rx_adc_dec_i.txt','log_t','-double','-ascii');
            end
            
        else
            e_dcdrls = out_e/dec_factor;
        end
    elseif(Cfg.algo == 1) % EM based algorithm
        delta_h_leak = Cfg.EM.delta_h_leak; % todo - we need different diagonal loading for g and h
        delta_g = Cfg.EM.delta_g; % todo - we need different diagonal loading for g and h
        %         delta_ni = Cfg.EM.delta_ni;
        lambda_rls = Cfg.lambda;
        WF_len = Cfg.WF_len;
        h_leak = Cfg.h_leak;
        lambda_reset = 0.99;
        [h_est,g_est,out] = EM_self_interference_cancel_algo_complex_dcd([0;dec_factor*rx_adc2_dec(2:end-L)],[0;0;dec_factor*rx_adc_dec(2:end-L-1)],lambda_rls,lambda_reset,delta_g,delta_h_leak,reset,WF_len,h_leak);        
        % debug output
        e_dcdrls= out/Cfg.dec_factor; % to normalize comapred to the matlab implementation
        figure(11);freqz([1;-g_est],512,'whole');title('Whitening filter');
        figure(12);freqz([h_est],512,'whole');title('Leakage filter');
    elseif(Cfg.algo == 2) % LS based algorithm
        L=Cfg.h_leak; % filter length
        Remove_Edges_LS=L*2; % remove edges
        A=zeros(length(rx_adc2_dec)-L+1-L-Remove_Edges_LS*2,L);
        for i=0:L-1
            A(:,i+1)=[rx_adc2_dec(L-i+Remove_Edges_LS:end-i-L-Remove_Edges_LS)];
        end
        sigma2 =0;% Cfg.delta_h_leak;%
        
        h5=(A'*A+sigma2*eye(size(A,2)))^-1*A'*rx_adc_dec(L+Remove_Edges_LS:end-L-Remove_Edges_LS);
        figure(4)
        plot(real(h5))
        title('LS filter estimation after wf')
        r3 = A*h5;
        e_dcdrls = rx_adc_dec(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r3;
    elseif(Cfg.algo == 3) % RLS based algorithm
        delta = Cfg.RLS.delta_h_leak; % todo - we need different diagonal loading for g and h
        lambda = Cfg.lambda;
        M_h = Cfg.h_leak;
        x = [0;dec_factor*rx_adc2_dec(2:end-L)];
        d = [0;0;dec_factor*rx_adc_dec(2:end-L-1)];
        N = length(x);
        out = zeros(1,N);
        u = zeros(M_h,N-M_h);
        P_rls = eye(M_h)*delta^-1;
        h = zeros(M_h,1);
        for i=1:N-M_h
            u(:,i)=x(i:1:i+M_h-1);
        end
        
        for n=M_h:N-M_h
            if mod(n,10000)==0, fprintf('%d  ',n);end
            y = d(n);
            e = y - h'*u(:,n- M_h + 1);
            p = P_rls*u(:,n- M_h + 1);
            c = lambda + u(:,n- M_h + 1)'*p;
            k = p/c;
            P_rls = (lambda^-1)*P_rls-(lambda^-1)*k*u(:,n- M_h + 1)'*P_rls;
            h = h + k*conj(e);
            out(n) = e;
        end
        e_dcdrls= out/Cfg.dec_factor; % to normalize comapred to the matlab implementation
    elseif(Cfg.algo == 4) % LMS
        mu=100;
        [e_lms,h6]=my_lms(dec_factor*rx_adc2_dec(1:end-L),dec_factor*rx_adc_dec(1:end-L),L,mu,0,1);
        e_dcdrls = e_lms/Cfg.dec_factor;
    end
else % run the fixed point C model
    [e_dcdrls] = run_standalone_full_model_C(dec_factor*rx_adc2_dec,dec_factor*rx_adc_dec,WF_len,Cfg.delta_wf,lambda_wf,L,Cfg.delta_h_leak,lambda_h_leak,Cfg.lambda_reset,reset,Cfg);
    e_dcdrls= e_dcdrls/Cfg.dec_factor; % to normalize comapred to the matlab implementation
end

%% Output
REF = rx_adc2_dec;
UL = rx_adc_dec;
clean_UL = e_dcdrls;
UL_orig = ul_adc_dec;
Thermal_noise = noise_adc_dec;
Fs = fs_ADC/dec_factor;
Fc = center_freq;




function a = loadcomp(file)
y = load(file);
a = y(:,1)+1j*y(:,2);
end
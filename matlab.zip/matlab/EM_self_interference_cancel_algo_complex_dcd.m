function [h,g,out] = EM_self_interference_cancel_algo_complex_dcd(x,d,lambda_rls,lambda_reset,delta_g,delta_h,reset,WF_len,h_leak)

M_g = WF_len;
M_h = h_leak;
N = length(x);
u_h = zeros(M_h,N-M_h);
u_g = zeros(M_g+1,N-M_g);
x_w = zeros(M_h,1);
Mb = 16;
P = 1; % clock to sample ratio

r_h = zeros(M_h,1);
Rd_h = delta_h*eye(M_h,M_h);
t_h = [delta_h; zeros(M_h-1,1)];
m_h=0;
alfa_h=1;

r_g = zeros(M_g,1);
Rd_g = delta_g*eye(M_g,M_g);
t_g = [delta_g; zeros(M_g-1,1)];
m_g=0;
alfa_g=1;

for i=1:N-M_h
    u_h(:,i)=x(i:1:i+M_h-1);
end

for i=1:N-M_g
    u_g(:,i)=x(i:1:i+M_g);
end

h = zeros(M_h,1);
g = zeros(M_g,1); % can't tset to zero or the algo won't converge
out = zeros(N,1);
sig = zeros(M_g+1,1);
shift_reg_d = zeros(M_g+1,1);

for n=M_h+M_g+1:N-M_h
    if mod(n,10000)==0, fprintf('%d  ',n);end
    if (reset(n) == 1)
        disp('reset enabled ...');
        lambda = lambda_reset;
    else
        lambda = lambda_rls;
    end
    
    z = d(n) - h'*u_h(end:-1:1,n- M_h + 1);
    sig = [z;sig(1:end-1)]; % shift register of the signal
    sig1 = sig(2:end);
    
    [t_g,r_g,g,Rd_g,alfa_g,m_g] = dcd_rls(n,z,sig1,lambda,t_g,delta_g,M_g,Mb,P,r_g,g,Rd_g,alfa_g,m_g);
    
    shift_reg_d = [d(n);shift_reg_d(1:end-1)];
    y = [1;-g]'*shift_reg_d; % todo - maybe conjugate? MAYBE BUG??????*****************
    for i_h=1:M_h
        x_w(i_h) = [1;-g]'*u_g(end:-1:1,n-M_h+1-i_h); % pass thru [1,g]!***************
    end
    
    % x is M_h X 1
    % y is 1 X 1    
    [t_h,r_h,h,Rd_h,alfa_h,m_h] = dcd_rls(n,y,x_w,lambda,t_h,delta_h,M_h,Mb,P,r_h,h,Rd_h,alfa_h,m_h);
    out(n) = z;% estimation of the UL signal
   
end




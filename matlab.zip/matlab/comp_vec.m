function comp_vec(x,y,M,range)
for i=range, 
    a(i) =  max(x(i*M+(1:M))-y(i*M+(1:M))); 
    i 
    [x(i*M+(1:M)) y(i*M+(1:M))]

end; 
figure; 
stem(abs(a));

end

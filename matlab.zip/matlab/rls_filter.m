function [h,e,P_rls] = rls_filter(y,x,h,P_rls,lambda)

e = y - h'*x;
p = P_rls*x;
c = lambda + x'*p;
k = p/c;
P_rls = (lambda^-1)*P_rls-(lambda^-1)*k*x'*P_rls;
h = h + k*conj(e);
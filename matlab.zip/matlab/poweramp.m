function [y A PH]=poweramp(x)
% poweramp model
%[b a]=butter(1,0.4);
a=1; b=[1 0.1];
%x=filter(b,a,x);
% TWT model from Saleh
alfa_a=1; %1.66; % just gain
beta_a=0.055;
alfa_p=0.15;
beta_p=0.34;
%ss=0.1;
%A=sign(x).*alfa_a.*(abs(x)-ss)./(1+beta_a*abs(x).^2).*(abs(x)>ss);
A=alfa_a.*x./(1+beta_a*abs(x).^2);
PH=alfa_p*abs(x).^2./(1+beta_p*abs(x).^2);
y=A.*exp(-1j.*PH); %.*exp(-1j.*PH); % I think that phase should be negative for causal system and it may be error in the Saleh paper
%y=x;
%y=filter(b,a,y);
end

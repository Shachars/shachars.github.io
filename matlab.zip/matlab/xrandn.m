function n=xrandn(N,M)
n=randn(N,M)+1j*randn(N,M);
n=n/sqrt(2);
end
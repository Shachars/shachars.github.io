
%%*********************************************************************************************
%%* Name:           adaptive nonlinear SI cancellation
%%* Description:    examine the performance of LMS adaptive nonlinear algorithm
%%*                 first propuse by Dani Kopri ,Tampere University Finland
%%* Parameters : 
%%* Return value:  
%%* Update Date:    20.3.2018
%%*********************************************************************************************

clear all;
close all;
clc



%% inital parameters

f_s = 100e3; % simulation sampel time
f_b = 4e3; % raw data freq
N = 1000;  % Number raw data Sym
P = 1; % pA nonlinearity order
K = 5; % channel impalse respon num taps

%% Sym - Generate
M = 4; % modulation order
data = randi([0 M-1],N,1); % Generate rand vector
txSig = pskmod(data,M,pi/M); 

%% PA - Hammerstein nonlinearity

NON_lin_vec_coffe = [1,0.07,0.23,0.02];

txSig_PA = zeros(N,1);
for l=0:1:(P-1)
txSig_PA = txSig_PA+NON_lin_vec_coffe(1)*(txSig.^(2*l+1));
end


%% channel impulse response

h_c = [1,-0.2,0.35,-0.13,-0.07];
txSig_PA_chan = filter(h_c,1,txSig_PA);



%% Rx
SNR = 20;
rxSig = awgn(txSig_PA_chan,SNR);
% scatterplot(rxSig)

%% nonlinearity basis functions


fi_bais_func = zeros(P,N); % todo - do we must know in advance the model order????
fi_bais_func(1,:)=txSig;

for l=1:1:P
    fi_bais_func(l,:) = abs(txSig.^(2*(l-1))).*txSig;
end

  
  

basis_corr_mat = zeros(P,P);
basis_corr_mat = (1/N)*(fi_bais_func)*(fi_bais_func');          




%% orthogonalised basis functions
            

V = zeros(P,P);
D = zeros(P,P);
S = zeros(P,P);

[V,D] = eig(basis_corr_mat);  
eign_val = diag(D);
eign_val_INV = eign_val.^(-0.5);
D_inv = diag(eign_val_INV);
S = D_inv*V';


fi_bais_func_ort = zeros(P,N);
for l=1:1:N
    fi_bais_func_ort(:,l) = S*fi_bais_func(:,l);
end




%%  least mean squares filter (LMS)




step_size = 0.1;
h_est = zeros(K*P,1);
error = zeros(N,1);


for l=K:1:N 
    
%     fi_bais_func_ort_n = reshape(fi_bais_func_ort(:,(l:-1:(l-K+1)))',K*P,1);
fi_bais_func_ort_n = fi_bais_func_ort(:,(l:-1:(l-K+1))).';
    error(l) = rxSig(l)-h_est'*fi_bais_func_ort_n;
    h_est = h_est+(step_size*error(l)'*fi_bais_func_ort_n);
end

figure(1)
stem(error)
title('System Identification by LMS Algorithm - self implements')
legend('System Estimation error')

% %% matlab LMS func
% 
% 
% lms = dsp.LMSFilter(K,'StepSize',step_size,'Method',...
%    'Normalized LMS','WeightsOutputPort',true);
% 
% [y,e,w] = lms(txSig,rxSig);
% 
% figure(2)
% stem([h_c' w])
% title('System Identification by Normalized LMS Algorithm')
% legend('Actual Filter Weights','Estimated Filter Weights',...
%        'Location','NorthEast')
% 

% %%  least mean squares filter (LMS)
% 
% step_size = 0.02;
% h_est = zeros(K,1);
% error = zeros(N,1);
% covarage_min = 0.01*K;
% LMS_iter=1;
% 
% while sum(abs(error))>covarage_min && (LMS_iter<1000)
% LMS_iter=LMS_iter+1;
% %     for i=1:1:(N-K)
% %         error(i) = rxSig(i)-sum(sum(h_est.*fi_bais_func(i:(i+K-1),:)));
% %     end
% 
%     error = rxSig(1:K)-sum(sum(h_est.*fi_bais_func(1:K,:)));
%     
%     for i=1:1:P
%         h_est(:,i) = h_est(:,i) + step_size*...
%             conj(error).*fi_bais_func(1:K,i)./(fi_bais_func(1:K,i)'*fi_bais_func(1:K,i));
%     end
%     
% end

function [h,g,out] = EM_self_interference_cancel_algo_complex(x,d,lambda_rls,lambda_reset,delta_g,delta_h,reset,WF_len,h_leak)

M_g = WF_len;
M_h = h_leak;
N = length(x);
u = zeros(M_h,N-M_h);

for i=1:N-M_h
    u(:,i)=x(i:1:i+M_h-1);
end

P_rls = eye(M_h)*delta_h^-1;
P_wf_rls = eye(M_g)*delta_g^-1;
h = zeros(M_h,1);
g = zeros(M_g,1); % can't tset to zero or the algo won't converge
out = zeros(N,1);
x = zeros(M_h,1);
sig = zeros(M_g+1,1);
shift_reg_d = zeros(M_g+1,1);

for n=M_h:N-M_h
    if mod(n,10000)==0, fprintf('%d  ',n);end
    if (reset(n) == 1)
        disp('reset enabled ...');
        lambda = lambda_reset;
    else
        lambda = lambda_rls;
    end
    
    z = d(n) - h'*u(:,n- M_h + 1);
    sig = [z;sig(1:end-1)]; % shift register of the signal
    sig1 = sig(2:end);
    [g,~,P_wf_rls] = rls_filter(z,sig1,g,P_wf_rls,lambda);

    shift_reg_d = [d(n);shift_reg_d(1:end-1)];
    y = [1;-g].'*shift_reg_d; % todo - maybe conjugate?
    x = filter([1;-g].',1,u(:,n- M_h + 1)); % pass thru [1,g]
    
    % x is M_h X 1
    % y is 1 X 1
    [h,~,P_rls] = rls_filter(y,x,h,P_rls,lambda);
    
    out(n) = z;% estimation of the UL signal
   
end




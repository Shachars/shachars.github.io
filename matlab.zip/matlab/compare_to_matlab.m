addpath '..\RLS';
currpath=cd;
cd 'D:\DropBox\Dropbox\corning\RLS_C\files\input_from_matlab';
xr=load('x_r.txt')+1j*load('x_i.txt'); 
dr=load('d_r.txt')+1j*load('d_i.txt'); 
a=load('parameters.txt');
 
N = a(1);
M = a(2);
delta = a(3);
lambda = a(4);
 
cd 'D:\DropBox\Dropbox\corning\RLS_C\files\files_for_matlab';
out=load('out_r.prn')+1j*load('out_i.prn'); 
h=load('h_r.prn')+1j*load('h_i.prn'); 

addpath(currpath)
cdbg.Rd = loadcomp('Rd.prn');
cdbg.t = loadcomp('t.prn');
cdbg.h = loadcomp('h.prn');
cdbg.r = loadcomp('r.prn');
cdbg.beta0 = loadcomp('beta0.prn');
cdbg.p = load('p.prn');
cdbg.m = load('m.prn');
cdbg.e = loadcomp('e.prn');
 
cd(currpath)
Nu = 1;
Mb = 32;
%unused
H = 0;
DCD_dec = 0;
D = 0;
reset = 0;
quant = 0;
alfa_reduce_factor = 1;
plotf = 1;
[e_ref, h_ref, mdbg] = rls_dcd_pipe11_R_quant(xr,dr,M,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);

a=1;

comp_vec(cdbg.h,mdbg.h,M,1:28);
comp_vec(cdbg.e,mdbg.e,1,1:28);


figure 
 stem([cdbg.p(1:200)+1 mdbg.p(1:200).'])
 figure
 plot([cdbg.m mdbg.m.' cdbg.m-mdbg.m.'])
 
 
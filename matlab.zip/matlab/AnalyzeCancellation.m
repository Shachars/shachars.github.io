%This script sweeps over the different captures and different operation
%modes of the rls-dcd and creates a cell array with the resuls for analysis
%later
function AnalyzeCancellation()
% todo - arrange all the configs in one place, imd,dac,adc,nf, scan over all the
% options easy, evm and analysis, debug figures, rls reg, hls, pipe, c code
% , different ddc options

format long;

persistent R_loaded;
persistent loaded_filename;

% Load the configurations
% ModelConfig;
% ModelConfig_single_narrow_best;
% ModelConfig_two_narrow;
ModelConfig_two_narrow_near_far;
% ModelConfig_sample_freq;
addpath ../rls

% go over all the captures folders
if(Cfg.load_sig == 0)
    path = '';
end
Folders = dir(path);
kk = 0;
iFolder = 3;
iCapture = 3;
N_samples = 20000;

while (iFolder<=length(Folders) || (Cfg.load_sig == 0 && kk <=0))
    
    if(Cfg.load_sig ~= 0)
        CapturePath = [path,Folders(iFolder).name];
        Captures = dir(CapturePath);
        
    else
        Captures = [];
    end
    while (iCapture<=length(Captures) || (Cfg.load_sig == 0 && kk <=0))
        kk = kk + 1;
        plot_first = 1;
        
        if (Cfg.load_sig) % Load captured signal
            Cfg.filename = [CapturePath,'\',Captures(iCapture).name];
            disp(['Loading ',Captures(iCapture).name]);
            if(~strcmp(loaded_filename,Cfg.filename))
                R_loaded = load(Cfg.filename);
                loaded_filename = Cfg.filename;
                disp('Loading new captured signal ...');
            else
                disp('Loading pre-loaded captured signal ...');
            end
            Cfg.R = R_loaded;
        else % Generate signal
            disp('Loading simulated signal ...');
        end
        
        
        [rx_adc,rx_adc2,ul_adc,noise_sig_adc,N1] = getSignal(Cfg);
        for WF_en = [1] % 0 = disable 1 = enable
            for algo_HLS = [0]
                for algo = [1,2,3,4];
                    Cfg.algo = algo;
                    % update the sweeping parameters
                    Cfg.WF_en = WF_en;
                    warning(['Changed WF_en = ',num2str(WF_en)]);
                    Cfg.algo_HLS = algo_HLS;
                    warning(['Changed algo_HLS = ',num2str(algo_HLS)])
                    
                    % Get the UL and REF signals
                    % todo - clean this up
                    
                    disp('Start PADCC ...');
                    [REF,UL,clean_UL,UL_orig,Thermal_noise,Fs,Fc] = PostADCCancellation(rx_adc,rx_adc2,ul_adc,noise_sig_adc,N1,Cfg);
                    
                    % todo - if we have the OFDM enabled perform the
                    % detection, maybe we first need to time shift the
                    % signals. then compute the EVM
                    
                    %                 if(Cfg.analysis)
                    % store the signals for EVM and
                    % ACPR analysis
                    %                 end
                    
                    if(Cfg.debug_plot)
                        figure(kk);
                        hold all;
                        
                        [f,ref_f]=plot_spect(REF(end/2:end),Fs,Fc,plot_first);
                        [f,ul_f]=plot_spect(UL(end/2:end),Fs,Fc,plot_first);
                        [f,ref_f]=plot_spect(UL_orig(end/2:end),Fs,Fc,plot_first);
                        [f,ul_f]=plot_spect(Thermal_noise(end/2:end),Fs,Fc,plot_first);
                        if(plot_first == 1)
                            legend_add({'REF','UL','UL Orig','Thermal Noise'});
                            plot_first = 0;
                        end
                        
                        [f,clean_ul_f]=plot_spect(clean_UL(end/2:end),Fs,Fc); % todo - might be an issue wit hthe dbm/hz here
                        %                     figure(1000);hold all;
                        %                   [f,error_power_f]=plot_spect(clean_UL(end-20000:end)-UL_orig(end-N_samples-(Cfg.h_leak + 1):end-(Cfg.h_leak + 1)),Fs,Fc); % todo - might be an issue wit hthe dbm/hz here
                        %                     [f,orig_UL_f]=plot_spect(UL_orig(end-N_samples:end),Fs,Fc); % todo - might be an issue wit hthe dbm/hz here
                        %                     figure(kk);
                        %                     plot(f,(orig_UL_f - error_power_f));
                        %                     plot(f,ul_f-clean_ul_f); % plot the rejection in dB
                        
                        if(Cfg.load_sig)
                            title(Captures(iCapture).name);
                        else
                            title('Simulation');
                        end
                        switch Cfg.algo
                            case 0
                                str1 = ['Double DCD-RLS'];
                            case 1
                                str1 = ['JWRLS-DCD'];
                            case 2
                                str1 = ['LS'];
                            case 3
                                str1 = ['RLS'];
                            case 4
                                str1 = ['LMS'];
                            otherwise
                                error('No algo chosen ...')
                        end
                        
                        %                     str2 = ['SNR after Algorithm [dB]'];
                        %                     str1 = [str1,' WF enable = ',num2str(WF_en)];
                        %                     str2 = [str2,' WF enable = ',num2str(WF_en)];
                        legend_add({str1});
                        
                        %                         figure(19);hold on;[f,reject_f]=plot_spect(UL_orig(length(clean_UL)/2:length(clean_UL))-clean_UL(end/2:end),Fs,Fc);
                        %                         legend_add(str1);
                        %                         xlabel('Frequency [MHz]');
                        %                         grid on;
                        %                         ylabel('[dB]');
                        %                         title('Residual estimation error')
                    end
                    
                end
            end
        end
        iCapture = iCapture + 1;
    end
    iFolder = iFolder + 1;
end

if(isempty(Folders) && Cfg.load_sig)
    error('Capture folder is empty ...');
end




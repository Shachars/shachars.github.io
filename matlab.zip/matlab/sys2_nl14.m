% version 7 t.v.
% in this case feedback from ADC + LO
% now after filter in UL band
% ver 14  - ls estimation of wf + not using wf^-1
precomputed = 0;
if precomputed==0,
    clear
    precomputed = 0;
end

% set these variables
center_freq=660; %700; %670; %670; %450; %450-0;
dec_factor = 20;
%delay = round(350*0.7*1.4);
  filename = '9_10_16/multi_carriers_LTE_34_-14dBFS_CW_at1790MHZ_-20dBm_1785MHz_-20dBm.csv';
% filename = 'data/multi_carier_LTE_34_-13dBFS_UL_LTE1MHz_TM31_0dBm.csv';
%filename = 'data/No_DL_UL_LTE10Hz_37dB_directivity.csv';
L1 = 24; % filter length
WF_len = 15;
WF_en = 1; % 0 = disable 1 = enable
WF_type = 1; % 0 = ref unfiltered , 1 = ref filtered or 2 = DCD modified with filtered signal calculating R
% WF_type applies only to RLS_DCD. LS works always with WF_type=1.
WF_reduction = 0.1;%0.1; % adding noise to wf calculation
wf_dl = 0.0001;
delay = L1/2*dec_factor;
sigma2 = 1e-8;%

ff =50/12e9; % [100 10000]/12e9;  % modulating frequency
ftdd = 0; %1500/12e9; % TDD
flag = 0;
close all
load_sig = 1 ;
dec_len = 512; % decimation filter length
by_channel=1;



L2 = 900;
D = 2; % ???


if precomputed==0,
    if load_sig
        [P, C] = read_parameters('sim_data_sys_HB2.xlsx');
    else
        [P, C] = read_parameters('sim_data_sys_HB1.xlsx');
    end
    tdd = ones(P.N,1);
    
    fs_sim=P.fs_sim*1e9;
    fs_DAC=P.Sampling_Rate*1e9;
    fs_ADC=fs_DAC;
    if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
        error('fs_sim must be a multiple of fs_ADC');
    end
    
    
    
    if load_sig
        %R=csvread('27_9_2016/multi carriers25dBm_with-50dBmCW_at_1880MHz.csv');
        R=load(filename);
        rx_adc2 = R(:,1)/2048;
        rx_adc = [zeros(delay,1); R(:,2)/2048];
        rx_adc = rx_adc(1:length(rx_adc2));
        N1 = length(rx_adc);
        % N1 = (2500+2*L1-1)*dec_factor; % 4000 is period. 4000/16=250
        rx_adc = rx_adc(1:N1);
        rx_adc2 = rx_adc2(1:N1);
    else
        noise_en=1;
        N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC
        
        
        x_tx=signal_gen(P,C,N1,'DL',fs_DAC);
        % checking signal against clipping
        DAC_full_scale = 10^(P.DAC_FS_power/20);
        %fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
        fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
        clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
        fprintf('clipping probability %f \n',clip_prob);
        
        
        
        x_rx=signal_gen(P,C,P.N,'UL',fs_sim);
        if P.LO
            x_rx = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x_rx);
        end
        
        
        % adding quantization noise
        DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);
        PA_noise_rms = 10^((-174+P.PA_NF)/20)*sqrt(fs_sim/2);
        
        n_DAC = randn(N1,1)*DAC_noise_rms*noise_en;
        n_PA = randn(P.N,1)*PA_noise_rms*noise_en;
        
        x_tx1=x_tx+n_DAC;
        
        % analog domain
        DAC_out = DAC_analog(P,x_tx1,N1);
        
        % mix up
        if P.LO
            DAC_out_up = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*DAC_out);
            tx_sig = DAC_out_up * 10^(P.PA_gain/20) +n_PA;
        else
            tx_sig = DAC_out * 10^(P.PA_gain/20) + n_PA;
        end
        
        % PA
        %     [B, A]=butter(2,[1600 2900]*1e6/fs_sim*2);
        %     tx_sig = filter(B,A,tx_sig);
        %  tx_sig = HM(tx_sig,[1 0.001 0.0007],[1]);
        tx_sig = HM(tx_sig,[1 0.001 0.00017],[1]);
        %  tx_sig = HM(tx_sig,[1 0.001 0.00007],[1]); % this one was used in the report Evaluation and Selection of algorithms for UL.docx
        
        %plot_spect(tx_sig,fs_sim);
        if ftdd
            tdd = ( sin((1:P.N)*2*pi*ftdd)' >0 );
            
            tx_sig =tx_sig.*tdd;
            plot(tdd(1:dec_factor*4:end)/1000)
        else
            tdd = ones(P.N,1);
        end
        
        
        
        h_leak = [1 0 0 0 0  0 0 0 0 0 0];
        h13G = readprn('h_leak13g.prn');
        %h = [zeros(250,1); h13G] .* hamming(250+length(h13G));
        %         h_leak = resample( h13G(1:97),P.fs_sim,13)/10;
        
        h_leak_tv = resample([zeros(97,1); h13G(98:160)],P.fs_sim,13)/10;
        
        tx1 = filter(h_leak,1,tx_sig);
        %        tx2 = filter(h_leak_tv,1,tx_sig);
        
        %        Tx_leakage = (tx1 + 0.1*(tx1.*[zeros(512e3,1); ones(length(tx1)-512e3,1)]))* 10^(-P.Antenna_separation/20);
        Tx_leakage = (tx1 + 0.1*(sin((1:length(tx1))*2*pi*ff)'.*tx1.*[zeros(512e3,1); ones(length(tx1)-512e3,1)]))* 10^(-P.Antenna_separation/20);
        
        
        Thermal_noise_rms = 10^((-174+P.LNA_NF)/20)*sqrt(fs_sim/2);
        n_thermal =  randn(P.N,1)*Thermal_noise_rms*noise_en;
        rx_sig = Tx_leakage + n_thermal + x_rx;
        %rx nonlinearity rx_sig = HM(rx_sig,[1 0.1 0.7],[1]);
        
        figure(1)
        plot_spect(Tx_leakage,fs_sim);
        hold all
        plot_spect(tx_sig,fs_sim);
        
        plot_spect(n_thermal+x_rx,fs_sim);
        plot_spect(rx_sig,fs_sim);
        rcolor
        
        % LNA
        
        x = rx_sig * 10^(P.LNA_gain/20);
        
        if P.LO
            x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
        end
        
        y = ADC_analog(P,x);
        
        ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
        
        n_ADC = randn(N1,1)*ADC_noise_rms*noise_en;
        
        rx_adc=y+n_ADC;
        rx_adc = [zeros(delay,1); rx_adc];
        rx_adc = rx_adc(1:N1);
        legend('Tx_leakage','Tx','UL signal');
        
        % estimating rx using additional ADC
        x = tx_sig * 10^(-P.PA_Coupler/20);
        if P.LO
            x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
        end
        %ref nonlinearity x = HM(x,[1 0.1 0.7],[1]);
        
        y2 = ADC_analog(P,x);
        
        ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);
        
        n_ADC2 = randn(N1,1)*ADC_noise_rms*noise_en;
        
        rx_adc2=y2+n_ADC2;
    end
end
if ~exist('P')
    error('No data in memory! use precomputed = 0');
end
ADC_full_scale = 10^(P.ADC_FS_power/20);
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC2 %.2f dbFS\n',10*log10(var(rx_adc2)))
clip_prob=sum(abs(rx_adc2)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)

figure(2)
plot_spect(rx_adc* 10^(-P.LNA_gain/20),fs_ADC);
hold all
plot_spect(rx_adc2* 10^(-P.LNA_gain/20),fs_ADC);
rcolor
legend('rx sampled','ref sampled');

if by_channel
    
    x = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc;
    x2 = exp(-2j*pi*(0:N1-1)'*center_freq*1e6/fs_ADC).*rx_adc2;
    
    if 1 %
        if 0 % raised cosine
            [Bf, Af]=firrcos(dec_factor*round(dec_len/dec_factor),1/2,0.4,dec_factor,'rolloff','sqrt');
        else
            % from sptool
            Fs = dec_factor;  % Sampling Frequency
            
            N     = dec_len;  % Order
            Fpass = 0.4;  % Passband Frequency
            Fstop = 0.6;  % Stopband Frequency
            Wpass = 1;    % Passband Weight
            Wstop = 1;    % Stopband Weight
            
            % Calculate the coefficients using the FIRLS function.
            Bf  = firls(N, [0 Fpass Fstop Fs/2]/(Fs/2), [1 1 0 0], [Wpass Wstop]);
        end
        
        
        
        rx_adc2_dec = upfirdn(x2,Bf,1,dec_factor);
        rx_adc2_dec = rx_adc2_dec(1:N1/dec_factor);
        rx_adc_dec = upfirdn(x,Bf,1,dec_factor);
        rx_adc_dec = rx_adc_dec(1:N1/dec_factor);
    else
        rx_adc2_dec = decimate(x2,dec_factor,dec_len,'fir');
        rx_adc_dec = decimate(x,dec_factor,dec_len,'fir');
    end
    
    
    
    
    if 0
        rx_adc2_dec = randn(size(rx_adc2_dec))+1j*randn(size(rx_adc2_dec));
        rx_adc_dec_w = rx_adc2_dec+1000*exp(0.1j*(1:length(rx_adc_dec))');
        
    end
    
    
    
    if 1
        
        wf1 = lpc(rx_adc_dec*dec_factor+WF_reduction*randn(N1/dec_factor,1),WF_len-1);
        %% LS equivalent to the lpc (solving the yule walker equation)
        v_corr = xcorr(rx_adc_dec*dec_factor)/length(rx_adc_dec);
        N_sig = length(rx_adc_dec);
        i0 = N_sig; % place of the variance
        p=WF_len-1; % filter length
        %     Remove_Edges_LS=L*2; % remove edges
        H = zeros(p);
        b = zeros(p,1);
        for i=1:p
            H(:,i) = v_corr(i0-i+1:i0+p-i);
            b(i) = -v_corr(i0+i);
        end
        wf_ls=((H+wf_dl*eye(size(H,2)))'*(H+wf_dl*eye(size(H,2))))^-1*(H+wf_dl*eye(size(H,2)))'*b;
        wf = [1;wf_ls];
        
        %% RLS equivalent to the LS
        
        % remove zeros from wf
        a = fft(wf,1000);
        k = max(abs(a));
        m = min(abs(a));
        if m<0.001
            error('LPC not stable');
        end
        %     b = a+0.1*k;
        %     wf = ifft(b);
        %     wf = wf(1:WF_len);
        %     wf = wf/wf(1);
        %     freqz(wf,1);
        rx_adc_dec_w = filter(wf,1,rx_adc_dec);
        rx_adc2_dec_w = filter(wf,1,rx_adc2_dec);
        
        
        
        
    end
    L=L1; % filter length
    Remove_Edges_LS=L*2; % remove edges
    K=1; % max harmonics
    A=zeros(N1/dec_factor-L+1-L-Remove_Edges_LS*2,L*K);
    B=zeros(N1/dec_factor-L+1-L-Remove_Edges_LS*2,L*K);
    for  k=1:K
        
        for i=0:L-1
            A(:,i+1+L*(k-1))=[rx_adc2_dec_w(L-i+Remove_Edges_LS:end-i-L-Remove_Edges_LS).^k];
            B(:,i+1+L*(k-1))=[rx_adc2_dec(L-i+Remove_Edges_LS:end-i-L-Remove_Edges_LS).^k];
        end
    end
    
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    
    A = A/sqrt(length(rx_adc2_dec));
    
    h5=(A'*A+sigma2*eye(size(A,2)))^-1*A'*rx_adc_dec_w(L+Remove_Edges_LS:end-L-Remove_Edges_LS);
    figure(4)
    plot(real(h5))
    title('LS filter estimation after wf')
    r3 = A*h5;
    r4 = B*h5;
    rx_adc1_dec_w = rx_adc_dec_w(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r3;
    rx_adc1_dec_w_reg = rx_adc_dec(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r4;
    rx_adc1_dec = filter(1,wf,rx_adc1_dec_w); % using the inverse filter
    figure(888)
    hold all
    freqz(wf,1)
    
    figure(7)
    title('from LS');
    plot_spect(rx_adc_dec,fs_ADC/dec_factor,center_freq);
    hold all
    plot_spect(rx_adc_dec_w,fs_ADC/dec_factor,center_freq);
    plot_spect(rx_adc2_dec_w,fs_ADC/dec_factor,center_freq);
    plot_spect(rx_adc1_dec_w,fs_ADC/dec_factor,center_freq);
    plot_spect(rx_adc1_dec,fs_ADC/dec_factor,center_freq);
    plot_spect(rx_adc1_dec_w_reg,fs_ADC/dec_factor,center_freq);
    legend('original UL','after WF','ref after WF','after cancellation','inverse WF','no WF minus 1')
    
    
    
    lambda = 1-2.5e-5;
    e_lms_FD=[NaN NaN];
    clear name
    name{2}='after ADC norm to input';
    name{1}='reference';
    name{3}='LS';
    p=4;
    if 0
        disp('lms FD')
        name{p}='lms FD'; p=p+1;
        
        mu  = 0.01;
        LL = 512;
        len1 = floor(length(rx_adc2_dec)/LL)*LL;
        ha = dsp.FrequencyDomainAdaptiveFilter('LeakageFactor',0.99999,'Method','constrained FDAF','Length',L,'StepSize',mu,'BlockLength',LL,'AveragingFactor',0.1,'Offset',0.01);
        [yh,e_lms_FD] = step(ha,rx_adc2_dec(1:len1),rx_adc_dec_w(1:len1));
        
    end
    e_lms=[NaN NaN];
    if 0
        disp('lms')
        name{p}='lms'; p=p+1;
        mu=0.001;
        [e_lms,h6]=my_lms(rx_adc2_dec(1:end-L),rx_adc_dec_w(1:end-L),L,mu,h5(end:-1:1)*0,1);
    end
    %     hold on
    e_affine=[NaN NaN];
    if 0
        disp('affine')
        name{p}='affine Ord=8'; p=p+1;
        
        mu = 0.05;                    % Step size
        po = 8;                      % Projection order
        offset = 0.005;               % Offset for covariance matrix
        h = dsp.AffineProjectionFilter('Length', L, ...
            'StepSize', mu, 'ProjectionOrder', po, ...
            'InitialOffsetCovariance',offset);
        [yh,e_affine] = step(h,rx_adc2_dec,rx_adc_dec_w);
        e_affine = e_affine(1:end-L);
    end
    e_rls = [NaN NaN];
    if 0
        disp('RLS')
        name{p}='RLS'; p=p+1;
        
        
        % SlidingWindowBlockLength=1024;%'Householder sliding-window RLS'
        h = dsp.RLSFilter(L,'Method','Conventional RLS', 'ForgettingFactor', lambda); % 'SlidingWindowBlockLength', SlidingWindowBlockLength
        
        [yh,e_rls] = step(h,rx_adc2_dec(L:end-1),rx_adc_dec_w(L:end-1));
        
        
        %         for p = 0:3
        %         [yh,e_rls1] = step(h,rx_adc2_dec(L+p:4:end-1),rx_adc_dec_w(L+p:4:end-1));
        %         e_rls(1+p:4:length(e_rls1)*4) = e_rls1;
        %         end
        e_rls = filter(1,wf,e_rls);
        e_rls = e_rls(1:end-L*5);
    end
    e_lat=[NaN NaN];
    if 0
        disp('Lattice')
        name{p}='Lattice'; p=p+1;
        
        miu = 0.05; % only for gradient
        
        del = 1; % 'Least-squares Lattice' |'QR-decomposition Least-squares Lattice' |'Gradient Adaptive Lattice'
        h = dsp.AdaptiveLatticeFilter('Method','Gradient Adaptive Lattice'  ,'Length', L, ...
            'ForgettingFactor', lambda, 'InitialPredictionErrorPower', del, 'StepSize' , miu, 'AveragingFactor', 0.9);
        [yh,e_lat] = step(h,rx_adc2_dec,rx_adc_dec_w);
    end
    e_ftf=[NaN NaN];
    if 0
        disp('ftf')
        name{p}='ftf'; p=p+1;
        
        h = dsp.FastTransversalFilter('Length',L,'ForgettingFactor',lambda);
        [yh,e_ftf] = step(h,rx_adc2_dec,rx_adc_dec_w);
    end
    e_myrls = [NaN NaN];
    addpath ../rls
    if 1
        disp('myRLS')
        name{p}='myRLS'; p=p+1;
        
        
        %         delta = 10000;
        delta = 1/sigma2;
        
        [e_myrls, h7] = my_rls(rx_adc2_dec_w(1:end-L+1),rx_adc_dec_w(L:end),L,delta,lambda);
        
        
        %         r_rls = B*conj(h7(:,end));
        %
        %     rx_adc1_dec_w_rls = rx_adc_dec(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r_rls;
        %         figure;
        %         hold all;
        %          plot_spect(rx_adc1_dec_w_reg,fs_ADC/dec_factor,center_freq);
        %         plot_spect(rx_adc1_dec_w_rls,fs_ADC/dec_factor,center_freq);
        %         legend('LS','RLS');
        if WF_type==1 || WF_type==0
            e_myrls = filter(1,wf,e_myrls);
        end
        
        
    end
    e_dcdrls = [NaN NaN];
    addpath ../rls
    
    add_noise = 0;
    for regularized=[0 1]
        delta = sigma2*(dec_factor)^2/(1-lambda);
        lambda1 = 0.9999; % for WF
        %delta1 = 1;% for WF
        
        Nu =1  ;
        D = 5+2*(Nu-1)+2; % delay, = 1+ multiple of DCD_dec
        Nbit = 0;
        DCD_dec = 1;
        alfa_reduce_factor=1;
        
        if 1 % enable dcd_rls
            disp('dcdrls')
            name{p}=['dcd rls Nu = ' num2str(Nu) '  regularized = ' num2str(regularized) ]; p=p+1;
            
            
            
            Mb = 32;
            H = 1; % approx the larger value of h
            reset=round(find(diff(tdd))/(dec_factor*fs_sim/fs_DAC));
            quant.R = 0*2^-Nbit;
            quant.h = 0*2^-Nbit;
            quant.r = 0*2^-(Nbit+8);
            quant.x = 0*2^-Nbit; %2^-Nbit; now
            %       compared with
            %       max(max(abs(r))) =   0.0154
            %       max(max(abs(x))) =   0.23
            %       max(max(abs(h)))=    0.7071
            %       max(max(abs(R)))=    5.3
            
            figure(5);
            plot_spect(rx_adc_dec(end/2:end),fs_ADC/dec_factor,center_freq);
            hold all
            
            
            if flag==0
                if WF_en
                    % increasing signal by dec_factor to reach reasonable signal power
                    % with FS = 1
                    disp('calculating WF using rls_dcd');
                    plotf = 1;
                    if 0
                        figure; hold all
                        plotf=0;
                        for lambda1=[0.9999] % 0.99 faster but result not stable
                            [e_wf_dcd, ww] = rls_dcd1(dec_factor*rx_adc_dec(2:end)+WF_reduction*randn(N1/dec_factor-1,1),dec_factor*rx_adc_dec(1:end-1),WF_len-1,delta1,lambda1,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                            e_wf_dcd = e_wf_dcd/dec_factor;
                            wf_dcd = [1 -ww(end:-1:1,end-L).'];
                            plot(imag(ww(4,:))); shg
                        end
                    else
                        delta1 = wf_dl/(1-lambda1);
                        %                [e_wf_dcd, ww] = rls_dcd_pipe9(dec_factor*rx_adc_dec(2:end),dec_factor*rx_adc_dec(1:end-1),WF_len-1,delta1,lambda1,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                        
                        [e_wf_dcd, ww] = rls_dcd1_regularized(dec_factor*rx_adc_dec(2:end),dec_factor*rx_adc_dec(1:end-1),WF_len-1,delta1,lambda1,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                        
                        e_wf_dcd = e_wf_dcd/dec_factor;
                        wf_dcd = [1 -ww(end:-1:1,end-(WF_len-1)).'];
                        
                    end
                    
                    %             if norm(wf-wf_dcd)>0.1
                    %                 warning('wf dcd didnt get right answer');
                    %             end
                    a = fft(wf_dcd,1000);
                    k = max(abs(a));
                    m = min(abs(a));
                    if m<0.0001
                        warning('wf DCD not stable by fft method');
                    end
                    if max(abs(roots(wf_dcd)))>=1
                        warning('wf DCD not stable by zeros method');
                    end
                else
                    wf_dcd = [1 0];
                end
            end
            
            figure(888)
            hold all
            freqz(wf_dcd,1)
            
            rx_adc_dec_w = filter(wf_dcd,1,rx_adc_dec);
            rx_adc2_dec_w = filter(wf_dcd,1,rx_adc2_dec);
            figure(5);
            plot_spect(rx_adc_dec_w(end/2:end),fs_ADC/dec_factor,center_freq);
            disp('cancellation stage using rls_dcd');
            plotf = 1;
            if WF_type==2
                [e_dcdrls, h8] = rls_dcd1_modified(dec_factor*rx_adc2_dec(1:end-L),dec_factor*rx_adc2_dec_w(1:end-L),dec_factor*rx_adc_dec(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                e_dcdrls = e_dcdrls/dec_factor;
            elseif WF_type==0
                
                [e_dcdrls, h8] = rls_dcd1(dec_factor*rx_adc2_dec(1:end-L),dec_factor*rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                e_dcdrls = e_dcdrls/dec_factor;
                %
            elseif  WF_type==1  || WF_type==3
                
                %                 [e_dcdrls, h8] = rls_dcd(rx_adc2_dec(1:end-L),rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,1,D,reset,quant);
                %           [e_dcdrls, h8] = run_standalone_C(dec_factor*rx_adc2_dec_w(1:end-L),dec_factor*rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                if regularized == 0
                    [e_dcdrls, h8] = rls_dcd1(dec_factor*rx_adc2_dec_w(1:end-L)+add_noise*randn(N1/dec_factor-L,1),dec_factor*rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                else
                    [e_dcdrls, h8] = rls_dcd1_regularized(dec_factor*rx_adc2_dec_w(1:end-L)+add_noise*randn(N1/dec_factor-L,1),dec_factor*rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);
                end
                e_dcdrls = e_dcdrls/dec_factor;
            end
            figure(5);
            %[e1, h1] = rls_dcd(x,d,M,delta,lambda,Nu,Mb);
            plot_spect(e_dcdrls(end/2:end),fs_ADC/dec_factor,center_freq);
            if WF_type==1 || WF_type==0
                e_dcdrls = filter(1,wf_dcd,e_dcdrls);
            end
            
            if WF_type==3
                ref_to_cancel = filter(conj(h8(:,end-L1)),1,rx_adc2_dec);
                e_dcdrls = rx_adc_dec - ref_to_cancel;
            end
            plot_spect(e_dcdrls(end/2:end),fs_ADC/dec_factor,center_freq);
            legend('original UL','after WF','after cancellation','inverse WF')
            
        end
        
        
        figure(4)
        plot(real(h5))
        %plot(real(h8(:,end-L1)))
        rcolor
        
        
        %     figure(102)
        %     plot2(e_rls,rx_adc1_dec)
        %
        %     figure
        %     plota(rx_adc1_dec)
        %figure
        figure(3)
        hold all
        if flag==0
            flag =1;
            plot_spect(rx_adc2_dec(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(rx_adc_dec(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            if mod(length(rx_adc1_dec),2)
                plot_spect(rx_adc1_dec((end-1)/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            else
                plot_spect(rx_adc1_dec(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            end
            
            
            
            plot_spect(e_lms_FD(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_lms(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_affine(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_rls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_lat(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_ftf(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            plot_spect(e_myrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
            %plot_spect(e_dcdrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
        end
        plot_spect(e_dcdrls(end/2:end) * 10^(-P.LNA_gain/20),fs_ADC/dec_factor,center_freq);
        
        %legend('after ADC norm to input','reference','after digital cancellation','after digital cancellation (LMS)');
        legend(name)
    end
end


%     figure(4)
%     plot_spect_mc(z1,fs_ADC/dec_factor,center_freq);
%     title('high res')
%ss(:,pppp)=e_dcdrls;pppp=pppp+1;
figure
plot((0:length(e_dcdrls)-1)/(fs_ADC/dec_factor)*1e3,real(e_dcdrls))
% hold all
% plot((0:length(rx_adc1_dec)-1)/(fs_ADC/dec_factor)*1e3,real(rx_adc1_dec))

xlabel('ms')
title('output signal (real part)');
% show tdd signal
%hold all
%plot((0:P.N/(dec_factor*4)-1)/(fs_ADC/dec_factor)*1e3,tdd(1:dec_factor*4:end)/100)
disp('output variable is clean_UL');
clean_UL=e_dcdrls;


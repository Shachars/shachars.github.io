% analysis script for all the figures
% analysis doc,fixed point doc,git c and matlab, presentation on c

% open all the figs and add the legend to them, 

% compute the rejection for
% all the fdx and the rejection definition, vs pin and versus freq

% compute the evm for the related ones
close all;

% 
% path = 'D:\DropBox\Dropbox\corning\Reports\figures\';
% figures = dir(path);
% for fig_ind=3:length(figures)
%     openfig([path,figures(fig_ind).name]);
%     legend('Feedback','UL','RLS-DCD output','Rejection [dB]')
% end
% 
% html_from_open_figs

% rejection = [];
% p_in = [];
% f1 = 523;
% f2 = 524;
% f3 = 525.9;
% f4 = 527.2;
% path = 'D:\DropBox\Dropbox\corning\Reports\figures\fdx cw\';
% figures = dir(path);
% for fig_ind=3:length(figures)
%     openfig([path,figures(fig_ind).name]);
%     h = gcf;
%     axesObj = get(h,'Children');
%     dataObj = get(axesObj,'Children');
%     x = get(dataObj,'XData');
%     y = get(dataObj,'YData');
%     idx1 = findClosest(x{1},f1);
%     idx2 = findClosest(x{1},f2);
%     idx3 = findClosest(x{1},f3);
%     idx4 = findClosest(x{1},f4);
%     t = y{1};
%     rejection = [rejection,mean([t(idx1:idx2),t(idx3:idx4)])];
%     aa = strtok(figures(fig_ind).name,'.');
%     p_in = [p_in,str2num(aa(end-1:end))];
% end
% 
% figure;plot(p_in([2,3,5:end-2]),rejection([2,3,5:end-2]))
% grid on;
% ylabel('Mean Rejection [dB]')
% title('Mean rejection power at RLS-DCD output')
% xlabel('CW Power in [dBm]');


rejection = [];
p_in = [];
f1 = 523;
f2 = 524;
f3 = 525.9;
f4 = 527.2;
path = 'D:\DropBox\Dropbox\corning\Reports\figures\fdx cw\';
figures = dir(path);
for fig_ind=3:length(figures)
    openfig([path,figures(fig_ind).name]);
    h = gcf;
    axesObj = get(h,'Children');
    dataObj = get(axesObj,'Children');
    x = get(dataObj,'XData');
    y = get(dataObj,'YData');
    idx1 = findClosest(x{1},f1);
    idx2 = findClosest(x{1},f2);
    idx3 = findClosest(x{1},f3);
    idx4 = findClosest(x{1},f4);
    t = y{1};
    rejection = [rejection,mean([t(idx1:idx2),t(idx3:idx4)])];
    aa = strtok(figures(fig_ind).name,'.');
    p_in = [p_in,str2num(aa(end-1:end))];
end

figure;plot(p_in([2,3,5:end-2]),rejection([2,3,5:end-2]))
grid on;
ylabel('Mean Rejection [dB]')
title('Mean rejection power at RLS-DCD output')
xlabel('CW Power in [dBm]');


clear 
close all
N = 1000;
x = randn(N,1);
h = [1 0.52j];
y = filter(h,1,x);
L=5;

a = lpc(y,L);

lambda =0.99999;
h = dsp.RLSFilter(L,'Method','Conventional RLS', 'ForgettingFactor', lambda); % 'SlidingWindowBlockLength', SlidingWindowBlockLength
        
 [yh,e_rls] = step(h,y(1:end-1),y(2:end));
 plot(e_rls); shg
 [var(y) var(e_rls)] 
 
 
            delta = 1000;
            Mb = 32;
            H = 1; % approx the larger value of h
            reset=[];
            Nbit=0;
            Nu = 1;
            D = 1;
            quant.R = 0*2^-Nbit;
            quant.h = 0*2^-Nbit;
            quant.r = 0*2^-(Nbit+8);
            quant.x = 0*2^-Nbit; %2^-Nbit; now
            alfa_reduce_factor=1;
 plotf = 0;
[e_dcdrls, h8] = rls_dcd(y(2:end),y(1:end-1),L,delta,lambda,Nu,Mb,H,1,D,reset,quant,alfa_reduce_factor,plotf);
hold all
 plot(e_dcdrls); shg
 a
[1 -h8(end:-1:1,end-L).']
function [rx_adc,rx_adc2,ul_adc,noise_sig_adc,N1] = getSignal(Cfg)

dec_factor = Cfg.dec_factor;
h_leak = Cfg.h_leak; % filter length
delay = floor(h_leak/2*dec_factor);

if Cfg.load_sig
    rx_adc2 = Cfg.R(:,1)/2048;
    rx_adc = [zeros(delay,1); Cfg.R(:,2)/2048];
    rx_adc = rx_adc(1:length(rx_adc2));
    N1 = floor(length(rx_adc)/dec_factor)*dec_factor;
    rx_adc = rx_adc(1:N1);
    rx_adc2 = rx_adc2(1:N1);
    ul_adc = zeros(size(rx_adc2(1:N1)));
    noise_sig_adc = zeros(size(rx_adc2(1:N1)));
else
    % load the sampling rates
    Fs_ADC = Cfg.ADC.Fs;
    Fs_sim = Cfg.fs_sim*1e9; % sampling rate mimicing the analog
    Fs_DAC = Cfg.DAC.Fs*1e9;
    N1 = round(Cfg.N/(Fs_sim/Fs_DAC)); % number of samples of DAC
    Cfg.N = min(N1*(Fs_sim/Fs_DAC),Cfg.N);
    if ((Fs_sim/Fs_DAC)-floor(Fs_sim/Fs_DAC))~=0
        error('fs_sim must be a multiple of fs_ADC');
    end
    
    
    x_tx=signal_gen(Cfg,Cfg.C,N1,'DL',Fs_DAC); % generate DL signal
    
    % checking signal against clipping
    DAC_full_scale = 10^(Cfg.DAC.DAC_FS_power/20);
    %fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
    fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
    clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
    fprintf('clipping probability %f \n',clip_prob);
    
    if(Cfg.simulation_signal == 0)
        x_rx=signal_gen(Cfg,Cfg.C,Cfg.N,'UL',Fs_sim); % generate UL signal
    elseif(Cfg.simulation_signal == 1)
        % todo - put all this in a function
        for ch=1:length(C.Ch_enable)
        [FreqDomainData, avg_pow] = GenOFDMData(Cfg.GenParam); % Generate frequency domain data
        FreqDomainData(Cfg.Pilot_Pos,:) = max(max((FreqDomainData))); % use highest constellation point
        Cfg.Pilots = FreqDomainData(Cfg.Pilot_Pos,:);
        % 3GPP signal
        ul_BB = GenOFDMSig(FreqDomainData,Cfg.GenParam);
        ul_BB = ul_BB/sqrt(avg_pow);
        
        % interpolate to reach Fs_sim
        ul_BB_intrp = upfirdn(ul_BB,h,Cfg.Fs/Fs_DAC,1)
        % up conversion to channel
            L_ch=C.BW(ch)*1e6
            x_rx = x_rx + real(ul_BB.*exp(j*2*pi*C.LO*nTs))
        end
        
        % is the simulation expecting a certain bumber of samples?
    end
    
    if Cfg.LO
        x_rx = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/Fs_sim).*x_rx);
    end
    
    % adding quantization noise
    DAC_noise_rms = 10^((Cfg.DAC.DAC_FS_power-Cfg.DAC.DAC_SNR)/20);
    PA_noise_rms = 10^((-174+Cfg.PA.PA_NF)/20)*sqrt(Fs_sim/2); % todo - why this scaling?
    
    n_DAC = randn(N1,1)*DAC_noise_rms*Cfg.noise_en;
    n_PA = randn(Cfg.N,1)*PA_noise_rms*Cfg.noise_en;
    
    x_tx1=x_tx+n_DAC;
    
    % analog domain
    DAC_out = DAC_analog(Cfg,x_tx1,N1);
    
    % mix up
    if Cfg.LO
        DAC_out_up = real(exp(2j*pi*(0:Cfg.N-1)'*Cfg.LO*1e6/Fs_sim).*DAC_out);
        tx_sig = (DAC_out_up + n_PA)* 10^(Cfg.PA.PA_gain/20);
    else
        tx_sig = (DAC_out + n_PA) * 10^(Cfg.PA.PA_gain/20);
    end
    
    % PA
    tx_sig = HM(tx_sig,Cfg.PA.HM.exponent_vec,Cfg.PA.HM.FIR);
    
    % Channel
    if(isfield(Cfg.Channel,'measured_channel_enable') && Cfg.Channel.measured_channel_enable == 1)
        h13G = readprn(Cfg.Channel.measured_channel.name);
        h_leak = resample([zeros(97,1); h13G(98:300)],13,floor(Fs_sim/1e9)); % todo - cutting the signal and Fs in config
        b = h_leak;
        a = 1;
    else
        b = Cfg.Channel.h_leak_num;
        a = Cfg.Channel.h_leak_denum;
    end
    tx1 = filter(b,a,tx_sig);
    
    Tx_leakage = tx1* 10^(-Cfg.Antenna_separation/20);
    
    % RX
    Thermal_noise_rms = 10^((-174+Cfg.LNA.LNA_NF)/20)*sqrt(Fs_sim/2);
    n_thermal =  randn(Cfg.N,1)*Thermal_noise_rms*Cfg.noise_en;
    rx_sig = Tx_leakage + n_thermal + x_rx;
    
    % LNA
    x = rx_sig * 10^(Cfg.LNA.LNA_gain/20);
    x_ul = (n_thermal + x_rx) * 10^(Cfg.LNA.LNA_gain/20);
    noise_sig = n_thermal * 10^(Cfg.LNA.LNA_gain/20);
    
    if Cfg.LO
        x = exp(-2j*pi*(0:Cfg.N-1)'*Cfg.LO*1e6/Fs_sim).*x*2;
    end
    
    y = ADC_analog(Cfg,x);
    y_ul = ADC_analog(Cfg,x_ul);
    noise_sig = ADC_analog(Cfg,noise_sig);
    
    ADC_noise_rms =  10^((Cfg.ADC.ADC_FS_power-Cfg.ADC.ADC_SNR)/20);
    
    n_ADC = randn(N1,1)*ADC_noise_rms*Cfg.noise_en;
    
    rx_adc=y+n_ADC;
    rx_adc = [zeros(delay,1); rx_adc];
    rx_adc = rx_adc(1:N1);
    
    ul_adc=y_ul+n_ADC;
    ul_adc = [zeros(delay,1); ul_adc];
    ul_adc = ul_adc(1:N1);
    
    noise_sig_adc=noise_sig+n_ADC;
    noise_sig_adc = [zeros(delay,1); noise_sig_adc];
    noise_sig_adc = noise_sig_adc(1:N1);
    
    % Reference ADC
    x = tx_sig * 10^(-Cfg.PA.PA_Coupler/20) + x_rx * 10^(Cfg.PA.UL_Leak_REF/20); % leakage from UL to REF
    if Cfg.LO
        x = exp(-2j*pi*(0:Cfg.N-1)'*Cfg.LO*1e6/Fs_sim).*x*2;
    end
    
    y2 = ADC_analog(Cfg,x);
    
    ADC_noise_rms =  10^((Cfg.ADC.ADC_FS_power-Cfg.ADC.ADC_SNR)/20);
    
    n_ADC2 = randn(N1,1)*ADC_noise_rms*Cfg.noise_en;
    
    rx_adc2=y2+n_ADC2;
    
    %% Check clipping
    ADC_full_scale = 10^(Cfg.ADC.ADC_FS_power/20);
    fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
    clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
    fprintf('clipping probability %f \n',clip_prob)
    fprintf('Total signal in ADC2 %.2f dbFS\n',10*log10(var(rx_adc2)))
    clip_prob=sum(abs(rx_adc2)>ADC_full_scale)/N1;
    fprintf('clipping probability %f \n',clip_prob)
    
end


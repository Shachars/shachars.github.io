function plota(x)
figure(100);
hold off;
plot(abs(x))
end
%% Config file
% This script holds all the configuration parameters for the system level
% simulation

%% General SLS
% path_main = 'D:\Captures Corning\Captures 26122016\';
path_main = 'D:\Corning - matlab\Captures regression data base\';
path = [path_main,'\test\'];
Cfg.main_path = 'D:\SW\HLS\FixedPointModel_HLS\Debug\';
Cfg.file_path = 'D:\SW\HLS\';
Cfg.command = [Cfg.main_path,'FixedPointModel_DCDRLS_full_algo.exe'];
Cfg.load_sig = 0; % 1 - load capture, 0 - load simulation
Cfg.debug_plot = 1;
Cfg.shorten_signals = 100000; % reduce the number of samples to this, -1: means no reduction
Cfg.algo_HLS = 0; % 0 - don't use the matlab HLS implementation, 1 - use it
Cfg.use_matlab = 0; % 0 - matlab, 1 - C
Cfg.AGC = 33;% 7.1 % normalizatio nfor the C implementation
Cfg.use_pipeline = 0; % use the pipeline model of the algorithm - this will mainly be used for comparing the captures database to the original algorithm
Cfg.algo = 3; % 0 - two rls algo (can be one toos) , 1 - EM algorithm, 2 - LS batch algorithm, 3 - RLS

%% Mixed Signal Simulation
Cfg.C.Freq = [770,680,490,774,770,780]; % [MHz] Center freq for each channel (DL or UL)
Cfg.C.BW = [40,90,70,2,20,2]; %[MHz] BW for each channel
Cfg.C.Ch_enable = [1,0,1,0,1,0]; % enable channel
Cfg.C.Power = [-45,-25,-35,-80,-45,-35]; % [dBm] power of each channel (total power acros BW)
Cfg.Max_number_of_channels = 20;
Cfg.C.UL_DL = {'DL','DL','DL','UL','UL','UL'}; % designation of each channel
Cfg.noise_en = 1; % 0 - don't add noise to the system, 1 - add noise
Cfg.tdd_flag = 0; % 0 - no tdd effects
Cfg.ADC.Fs = 2.4576; % [GHz] Sampling rate of the ADC
Cfg.ADC.ADC_FS_power = 0;
Cfg.ADC.ADC_SNR = 62;
Cfg.DAC.DAC_FS_power = 0; % [dBm]
Cfg.DAC.Fs = Cfg.ADC.Fs; % [GHz] Sampling rate of the ADC todo - this needs to be the same as the ADC, except when we have the digital in the dac working in higher than the adc
Cfg.DAC.Backoff = 12;
Cfg.DAC.DAC_SNR = 90;
Cfg.DAC.DAC_filter_order = 4;
Cfg.DAC.DAC_filter_cutoff = 1.3;
Cfg.DAC.DAC_filter_ripple = 0.1;
Cfg.PA.PA_NF = 10;
Cfg.PA.PA_gain = 25;
Cfg.PA.UL_Leak_REF = -90;
Cfg.PA.HM.exponent_vec = [1 0.001 0.00017];
Cfg.PA.HM.FIR = [1];
Cfg.PA.PA_Coupler = 45;
Cfg.Channel.h_leak_denum = [1.000 0 0 0 0];
Cfg.Channel.h_leak_num = [1];
Cfg.Antenna_separation = 60;%53;
Cfg.LNA.LNA_gain = 4;
Cfg.LNA.LNA_NF = 5;
Cfg.Freq_Difference = 2.5;
Cfg.Sig_SNR_for_this_test = 10;
Cfg.Sig_BW_for_this_test = 1;
Cfg.Fin = 2.5;
Cfg.N = 10240000;
Cfg.fs_sim = 3*Cfg.ADC.Fs;
Cfg.LO = 0;
% todo - add jitter

%% Digital Down Conversion
Cfg.dec_len = 512; % decimation filter length, this is for the fft? todo
Cfg.center_freq = 770;%880;%490;%880;%490;% % [MHz] center frequency of the digital down conversion
Cfg.dec_factor = 20;
Cfg.IF = 40;
%% from sptool
Fs = Cfg.dec_factor;  % Sampling Frequency
Fpass = 0.4;  % Passband Frequency
Fstop = 0.6;  % Stopband Frequency
Wpass = 1;    % Passband Weight
Wstop = 1;    % Stopband Weight
%% Calculate the coefficients using the FIRLS function.
Cfg.Bf  = firls(Cfg.dec_len, [0 Fpass Fstop Fs/2]/(Fs/2), [1 1 0 0], [Wpass Wstop]);

%% General RLS Parameters
wf_dl = 0.001;% diagonal loading for whiteing filter
delta_h_leak = 1e-5;% diagonal loading for leakage filter
lambda = 1-2.5e-9;%1-2.5e-5; % RLS forgetting factor with reset off
lambda_reset = 0.99; % RLS forgetting factor with reset on
Cfg.lambda = 1-2^(round(log2(1-lambda))); % this is to be a shifter
Cfg.lambda_reset = 1-2^(round(log2(1-lambda_reset))); % this is to be a shifter
Cfg.delta_wf = (wf_dl/(1-Cfg.lambda))/Cfg.AGC^2;
Cfg.delta_wf = 2^round(log2((1-Cfg.lambda)*Cfg.delta_wf))/(1-Cfg.lambda); % divide by the gain of the block - todo - this should be done in the upper layer
Cfg.delta_h_leak = (delta_h_leak*(Cfg.dec_factor)^2/(1-Cfg.lambda)/Cfg.AGC^2);
Cfg.delta_h_leak = 0;%2^round(log2((1-Cfg.lambda)*Cfg.delta_h_leak))/(1-Cfg.lambda);
Cfg.h_leak = 24; % self intereference filter length
Cfg.WF_len = 24; % length of the whitening filter
Cfg.WF_type = 3; % 0 = ref unfiltered , 1 = ref filtered or 2 = DCD modified with filtered signal calculating R
Cfg.WF_en = 1; % 0 - don't use the whitening filter, 1 - use it
Cfg.sigma2_s = 1e-3;
Cfg.sigma2_e = 1e-3;

Cfg.RLS.delta_h_leak = 1e-3;%Cfg.delta_h_leak; % todo - we need different diagonal loading for g and h

%% EM Parameters
Cfg.EM.delta_h_leak = 1e-3;%Cfg.delta_h_leak; % todo - we need different diagonal loading for g and h
Cfg.EM.delta_g = 1e-2;%Cfg.delta_wf;%1e1 % todo - we need different diagonal loading for g and h
Cfg.EM.delta_ni = 1e-5;%1e-4;
Cfg.EM.flag_diagonal_loading = 1;

%% DCD-RLS Parameters
Cfg.Mb = 16;
Cfg.Nu = 1; % number of iteration in DCD-RLS
Cfg.DCD_dec = 1;
Cfg.clock_mul = 1; % re-use factor for the FPGA
Cfg.use_approx_R = 1; % 0 - complete R, 1 - approx col
Cfg.approx_beta0 = 1; %0 - don't use approx, 1- use approx

%% Debug
Cfg.save_logs = 0; % 0 - don't save logs 

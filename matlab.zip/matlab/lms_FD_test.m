N=122880;
close all
my_lms=1;
x=randn(N,1)+1j*randn(N,1);
L=100;
lp=firls(L,[0 0.1 0.2 .5]*2,[1 1 0 0],[1 1])';
lp1=firls(L,[0 0.05 0.1 .5]*2,[1 1 0 0],[1 1])';
%x=filter(lp,1,x)+x/10;

h1=[ 0 0 0 0 1]*1j;
load res
h = h5;
x = filter(h,1,x);
K=length(h);

snr=80;
n=randn(N,1)*10^(-snr/20);
snr1=90;
rx=randn(N,1)*10^(-snr1/20);
%rx=filter(lp1,1,rx);
n=n+rx;

y=filter(h1,1,x)+n;
% y = x+n;
IT=1;
 x = repmat(rx_adc2_dec(1:122880),IT,1);
 %x = x+randn(122880*IT,1)*0.001;
 y = repmat(rx_adc_dec(1:122880),IT,1);
 n = repmat(rx_adc1_dec(1:122880),IT,1);
%y=filter(h1,1,x)+n;

if 1
mu  = 1;
L = K;
LL = 2048;
ha = dsp.FrequencyDomainAdaptiveFilter('LeakageFactor',0.99999,'Method','Unconstrained FDAF','Length',L,'StepSize',mu,'BlockLength',LL,'AveragingFactor',0.9,'Offset',0.001);
[yh,e] = step(ha,x,y);
h_start = h;
%e1=my_lms(x,y,L,0.0001,h_start,1);  

%plot2(e(end-100:end),n(end-100:end),'est','real')
end

if 0
miu = 0.001; % only for gradient
lam = 0.995; % only for LS or QR
del = 1; % 'Least-squares Lattice' |'QR-decomposition Least-squares Lattice' |'Gradient Adaptive Lattice'
h = dsp.AdaptiveLatticeFilter('Method','QR-decomposition Least-squares Lattice' ,'Length', 64, ...
    'ForgettingFactor', lam, 'InitialPredictionErrorPower', del, 'StepSize' , miu, 'AveragingFactor', 0.9);
[yh,e] = step(h,x,y);
end

if 1
h = dsp.RLSFilter(32, 'ForgettingFactor', 0.98);
[yh,e] = step(h,x,y);
end

if 0
     mu = 0.05;                    % Step size
       po = 10;                      % Projection order
       offset = 0.005;               % Offset for covariance matrix
       h = dsp.AffineProjectionFilter('Length', 32, ...
           'StepSize', mu, 'ProjectionOrder', po, ...
           'InitialOffsetCovariance',offset);
[yh,e] = step(h,x,y);
end


plot2(20*log10(abs(e)+1e-5),20*log10(abs(n)+1e-5),'est','real')

function  [out, h] = run_standalone_C(x,d,M,delta,lambda,Nu,Mb,H,Dec,Delay,reset,quant,alfa_reduce_factor,plotf)
main_path = 'D:\Dropbox\Dropbox\';
% main_path = 'C:\Users\Shachar\Dropbox\';
scaling = 7.1;
x = x/scaling; % temporary!!! reacing max <1 for a signal that is -12dBFs at ADC
d = d/scaling;
delta = delta/scaling^2;
% many parameters are unused, just to keep compatibility with other
% functions
disp('running C');
currpath=cd;
cd([main_path,'corning\RLS_C\files\input_from_matlab']);
x(1:M)=0;
xi=imag(x);
xr=real(x);
di=imag(d);
dr=real(d);
save x_i.txt xi -ascii -double
save x_r.txt xr -ascii -double
save d_i.txt di -ascii -double
save d_r.txt dr -ascii -double
save reset.txt reset -ascii 

N=length(x);
temp =   [N M delta lambda];
save parameters.txt temp -ascii -double

cd(currpath)
!D:\Dropbox\Dropbox\corning\RLS_C\x64\Debug\run_rls_dcd.exe
% !C:\Users\Shachar\Dropbox\corning\RLS_C\x64\Debug\run_rls_dcd.exe

currpath=cd;
cd([main_path,'\corning\RLS_C\files\files_for_matlab']);
out=load('out_r.prn')+1j*load('out_i.prn');
h=load('h_r.prn')+1j*load('h_i.prn');

cd(currpath)
plota(h)


a=1; %place for breakpoint




% Order=15; PassBand=0.3;
% HBF=firpm(Order-1,[0 PassBand 1-PassBand 1],[1 1 0 0]);
% display(HBF');
% NQ=12; HBF=round(HBF*2^NQ)/2^NQ; %Quantize coefficients
% display(round(HBF*2^NQ)');

% close all;

% N = 1000;
% % hn = ones(1,N);
% hn = [1,zeros(1,N-1)];
% hn = adf(hn,0.125);
% hF = fft(hn,1024);
% figure;plot([-512:511]/1024, 20*log10(abs(fftshift(hF))));
% xlabel('Normalized frequency')
% ylabel('Amplitude')
% 
% 
% N = 1000;
% hn = ones(1,N);
% % hn = [1,zeros(1,N-1)];
% hn = cic(hn,30);
% hF = fft(hn,1024);
% figure;plot([-512:511]/1024, 20*log10(abs(fftshift(hF))));
% xlabel('Normalized frequency')
% ylabel('Amplitude')
% 
% 
% N = 1000;
% % hn = ones(1,N);
% hn = [1,zeros(1,N-1)];
% hn = hbf(hn);
% hF = fft(hn,1024);
% figure;plot([-512:511]/1024, 20*log10(abs(fftshift(hF))));
% xlabel('Normalized frequency')
% ylabel('Amplitude')


N = 1000;
hn = ones(1,N);
hF = fft(hn,1024);
figure;plot([-512:511]/1024, 20*log10(abs(fftshift(hF))));
xlabel('Normalized frequency')
ylabel('Amplitude')

hn = [1,zeros(1,N-1)];
hn = cic(hn,10);
hn = adf(hn,0.15);
hn = hbf(hn);
hF = fft(hn);
figure;plot( 20*log10(abs(fftshift(hF))));
xlabel('Normalized frequency');
ylabel('Amplitude');






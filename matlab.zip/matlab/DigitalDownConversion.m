function [rx_adc_dec,rx_adc2_dec,ul_adc_dec,noise_adc_dec,reset] = DigitalDownConversion(Cfg,rx_adc,rx_adc2,ul_adc,noise_sig_adc,N1)

%% Load parameters for simulator
fs_ADC = Cfg.ADC.Fs*1e9;

x = exp(-2j*pi*(0:N1-1)'*Cfg.center_freq*1e6/fs_ADC).*rx_adc;
x2 = exp(-2j*pi*(0:N1-1)'*Cfg.center_freq*1e6/fs_ADC).*rx_adc2;
x3 = exp(-2j*pi*(0:N1-1)'*Cfg.center_freq*1e6/fs_ADC).*ul_adc;
x4 = exp(-2j*pi*(0:N1-1)'*Cfg.center_freq*1e6/fs_ADC).*noise_sig_adc;

rx_adc2_dec = upfirdn(x2,Cfg.Bf,1,Cfg.dec_factor);
rx_adc2_dec = rx_adc2_dec(1:N1/Cfg.dec_factor);
rx_adc_dec = upfirdn(x,Cfg.Bf,1,Cfg.dec_factor);
rx_adc_dec = rx_adc_dec(1:N1/Cfg.dec_factor);
ul_adc_dec = upfirdn(x3,Cfg.Bf,1,Cfg.dec_factor);
ul_adc_dec = ul_adc_dec(1:N1/Cfg.dec_factor);
noise_adc_dec = upfirdn(x4,Cfg.Bf,1,Cfg.dec_factor);
noise_adc_dec = noise_adc_dec(1:N1/Cfg.dec_factor);

if(Cfg.shorten_signals > 0)
    rx_adc2_dec = rx_adc2_dec(1:min(Cfg.shorten_signals,length(rx_adc2_dec)));
    rx_adc_dec = rx_adc_dec(1:min(Cfg.shorten_signals,length(rx_adc_dec)));
    ul_adc_dec = ul_adc_dec(1:min(Cfg.shorten_signals,length(ul_adc_dec)));
    noise_adc_dec = noise_adc_dec(1:min(Cfg.shorten_signals,length(noise_adc_dec)));
end

%% create the reset signal
reset = zeros(1,length(rx_adc_dec));

%% AGC (scale the signals and parameters so to fit the fixed point)
rx_adc_dec = rx_adc_dec/Cfg.AGC; % temporary!!! reacing max <1 for a signal that is -12dBFs at ADC
rx_adc2_dec = rx_adc2_dec/Cfg.AGC;
ul_adc_dec = ul_adc_dec/Cfg.AGC;
noise_adc_dec = noise_adc_dec/Cfg.AGC;
function [t,r,h,Rd,alfa,m] = dcd_rls(n,d,x_shreg,lambda,t,delta_h,M_h,Mb,P,r,h,Rd,alfa,m)

beta0 = zeros(M_h,1);
t = lambda*t + conj(x_shreg(1))*x_shreg(1:M_h) + (1-lambda)*delta_h*[1;zeros(M_h-1,1)];
i = mod((n-1),M_h)+1;
Rd(:,i) =  [conj(t(i:-1:1)); t(2:end-i+1)];

y = zeros(M_h/P,1);
for i=0:P-1
    for j=0:M_h/P-1
        y(j+1)=y(j+1)+conj(h(i+j*P+1))*x_shreg(i+j*P+1);
    end
end

e= d - sum(y);

%
for i=0:P-1
    for j=0:M_h/P-1
        beta0(i+j*P+1) = lambda*r(i+j*P+1)+conj(e)*x_shreg(i+j*P+1)-(1-lambda)*delta_h*(h(i+j*P+1));
    end
end

deltah = zeros(M_h,1);

Rcomp=Rd(M_h,M_h)/2*alfa;

rr = [real(beta0); imag(beta0)];
arr = abs(rr);

p1=find(arr>Rcomp*2,1,'first');
p2=find(arr>Rcomp,1,'first');
p3=find(arr>Rcomp/2,1,'first');

zero_alfa = 0;

if ~isempty(p1)
    if m>0
        m = m - 1;
        alfa = alfa * 2;
    end
    p = p1;
elseif ~isempty(p2)
    alfa = alfa;
    p = p2;
elseif ~isempty(p3)
    if m<Mb
        alfa = alfa / 2;
        p = p3;
        m = m + 1;
    else
        p = p3;
        zero_alfa = 1;
    end
else
    % no p
    zero_alfa = 1;
    p = 1;
    if m<Mb
        m = m + 2;
        alfa = alfa / 4;
    end
end

alfas = alfa * sign(rr(p));
if             zero_alfa
    alfas = 0;
end

if p>M_h
    jflag = 1;
    pm = p-M_h;
else
    jflag = 0;
    pm = p;
end


if ~jflag
    deltah(pm) = alfas;
else
    deltah(pm) = 1j*alfas;
end

r = beta0 - alfas*Rd(:,pm)*1j^jflag;

h=h+deltah;
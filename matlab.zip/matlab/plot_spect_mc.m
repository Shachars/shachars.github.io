function plot_spect_mc(sig,fs,fc)
if nargin<3
    fc = 0;
end
N_welch=2500; %2^round(log2(length(sig)/10));
[pxx,f]= pwelch(sig,ones(N_welch,1),N_welch/2,N_welch,fs);
pxx = 10*log10(pxx);
 
if isreal(sig) 
    plot(f*1e-6,pxx);
else
    plot((f+fc*1e6-fs/2)*1e-6,fftshift(pxx));
end
grid on;
RBW =  fs/N_welch*2.33; % not accurate
title(sprintf('Signals fs=%0.2f GHz, RBW = %0.2f MHz',fs/1e9,RBW/1e6));
xlabel('MHz');
ylabel('dBm/Hz');

end
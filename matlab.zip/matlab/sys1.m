clear 
close all
[P, C] = read_parameters('sim_data_sys_HB.xlsx');
fs_sim=P.fs_sim*1e9;
fs_DAC=P.Sampling_Rate*1e9;
fs_ADC=fs_DAC;
if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
    error('fs_sim must be a multiple of fs_ADC');
end
N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC

x_tx=signal_gen(P,C,N1,'DL',fs_DAC);
% checking signal against clipping
DAC_full_scale = 10^(P.DAC_FS_power/20);
%fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob);



x_rx=signal_gen(P,C,P.N,'UL',fs_sim);


% adding quantization noise
DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);
PA_noise_rms = 10^((-174+P.PA_NF)/20)*sqrt(fs_sim/2);

n_DAC = randn(N1,1)*DAC_noise_rms;
n_PA = randn(P.N,1)*PA_noise_rms;

x_tx=x_tx+n_DAC;

% analog domain
DAC_analog = DAC_analog(P,x_tx,N1);

% PA
Tx_sig = DAC_analog * 10^(P.PA_gain/20)+n_PA;
figure
plot_spect(Tx_sig,fs_sim);
hold all
Tx_sig = HM(Tx_sig,[1 0 0.0001],[1]);
plot_spect(Tx_sig,fs_sim);
rcolor
Tx_leakage = Tx_sig * 10^(-P.Antenna_separation/20);


Thermal_noise_rms = 10^((-174+P.LNA_NF)/20)*sqrt(fs_sim/2);
n_thermal =  randn(P.N,1)*Thermal_noise_rms;
Rx_sig = Tx_leakage + n_thermal + x_rx;

figure
plot_spect(Tx_leakage,fs_sim);
hold all
plot_spect(n_thermal+x_rx,fs_sim);

rcolor

% LNA

x = Rx_sig * 10^(P.LNA_gain/20); 

y = ADC_analog(P,x);

ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);

n_ADC = randn(N1,1)*ADC_noise_rms;

z=y+n_ADC;
z1 = z * 10^(-P.LNA_gain/20); % normalize back to input
plot_spect(z1,fs_ADC);
rcolor
legend('Tx_leakage','rx','after ADC norm to input');

%legend('before ADC','after jitter','after ADC+TH')
% checking signal against clipping
ADC_full_scale = 10^(P.ADC_FS_power/20);
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(z)))
clip_prob=sum(abs(z)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)




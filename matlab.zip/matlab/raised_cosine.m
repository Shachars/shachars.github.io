function y=raised_cosine(x,beta);
% raised cosine function in frequency
for i=1:length(x)
  a=abs(x(i));
  if a<1-beta
    y(i)=1;
  elseif a>1+beta
    y(i)=0;
  else
    y(i)=(1+cos((a-1+beta)/beta*pi/2))/2;
  end
end
y=y';

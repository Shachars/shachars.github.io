% in this case feedback from ADC + LO
% now after filter in UL band
clear
close all
fs_sim=P.fs_sim*1e9;
fs_DAC=P.Sampling_Rate*1e9;
fs_ADC=fs_DAC;
if ((fs_sim/fs_DAC)-floor(fs_sim/fs_DAC))~=0
  error('fs_sim must be a multiple of fs_ADC');
end
[P, C] = read_parameters('sim_data_sys_HB2.xlsx');
if load_sig
    R=csvread('Multitone_64car_1MHz_FB_0dBm.csv');
    rx_adc2 = R(:,1);
    rx_adc = R(:,2);
    N1 = length(rx_adc);
else
noise_en=1;
N1 = round(P.N/(fs_sim/fs_DAC)); % number of samples of DAC


x_tx=signal_gen(P,C,N1,'DL',fs_DAC);
% checking signal against clipping
DAC_full_scale = 10^(P.DAC_FS_power/20);
%fprintf('DAC_full_scale is %.2f dbm\n',20*log10(DAC_full_scale));
fprintf('Total signal in DAC %.2f dbFS\n',10*log10(var(x_tx)));
clip_prob=sum(abs(x_tx)>DAC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob);



x_rx=signal_gen(P,C,P.N,'UL',fs_sim);
if P.LO
    x_rx = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x_rx);
end


% adding quantization noise
DAC_noise_rms = 10^((P.DAC_FS_power-P.DAC_SNR)/20);
PA_noise_rms = 10^((-174+P.PA_NF)/20)*sqrt(fs_sim/2);

n_DAC = randn(N1,1)*DAC_noise_rms*noise_en;
n_PA = randn(P.N,1)*PA_noise_rms*noise_en;

x_tx1=x_tx+n_DAC;

% analog domain
DAC_out = DAC_analog(P,x_tx1,N1);

% mix up
if P.LO
    DAC_out_up = real(exp(2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*DAC_out);
end

% PA
tx_sig = DAC_out_up * 10^(P.PA_gain/20) +n_PA;
[B, A]=butter(2,[1600 2900]*1e6/fs_sim*2);
tx_sig = filter(B,A,tx_sig);
tx_sig = HM(tx_sig,[1 0.001 0.0001],[1]);
%tx_sig = HM_tv(tx_sig,[1 0.001 0.0001],1,[0 0.1 0],fs_sim);

%plot_spect(tx_sig,fs_sim);
dec_factor = 20;


h_leak = [0 0 0 0 0  0 0 0 0 0 1];
h13G = readprn('h_leak13g.prn');
%h = [zeros(250,1); h13G] .* hamming(250+length(h13G));
h_leak = resample( h13G(1:97),P.fs_sim,13)/10;
h_leak = [ zeros(5*fs_sim/fs_ADC*dec_factor,1); h_leak];


Tx_leakage = filter(h_leak,1,tx_sig)* 10^(-P.Antenna_separation/20);
 


Thermal_noise_rms = 10^((-174+P.LNA_NF)/20)*sqrt(fs_sim/2);
n_thermal =  randn(P.N,1)*Thermal_noise_rms*noise_en;
rx_sig = Tx_leakage + n_thermal + x_rx;

figure(3)
plot_spect(Tx_leakage,fs_sim);
hold all
plot_spect(tx_sig,fs_sim);

plot_spect(n_thermal+x_rx,fs_sim);
%plot_spect(rx_sig,fs_sim);
rcolor

% LNA

x = rx_sig * 10^(P.LNA_gain/20);

if P.LO
    x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
end

y = ADC_analog(P,x);

ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);

n_ADC = randn(N1,1)*ADC_noise_rms*noise_en;

rx_adc=y+n_ADC;
figure(3)
legend('Tx_leakage','rx','after ADC norm to input');

%legend('before ADC','after jitter','after ADC+TH')
% checking signal against clipping
ADC_full_scale = 10^(P.ADC_FS_power/20);
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)

if 0, % estimating tx from rx
  % r1 = DAC_analog(P,x_tx,N1);
  % r2 = ADC_analog(P,r1);
  %  a=mean(rx_adc.*r2)/mean(r2.^2);
  L=30;
  K=1; % max harmonics
  A=zeros(N1,L*K);
  for  j=1:K
    
    for i=0:L-1
      A(:,i+1+L*(j-1))=[zeros(i,1); x_tx(1:end-i).^j];
    end
  end
  h=A\rx_adc;
  figure(4)
  plot(abs(h))
  figure(3)
  r1 = A*h;
  rx_adc1 = rx_adc - r1;
  
  z1 = rx_adc1 * 10^(-P.LNA_gain/20); % normalize back to input
  %figure
  plot_spect(z1,fs_ADC);
end

% estimating rx using additional ADC
x = tx_sig * 10^(-P.PA_Coupler/20);
if P.LO
    x = exp(-2j*pi*(0:P.N-1)'*P.LO*1e6/fs_sim).*x*2;
end

y2 = ADC_analog(P,x);

ADC_noise_rms =  10^((P.ADC_FS_power-P.ADC_SNR)/20);

n_ADC2 = randn(N1,1)*ADC_noise_rms*noise_en;

rx_adc2=y2+n_ADC2;
end
ADC_full_scale = 10^(P.ADC_FS_power/20);
%fprintf('ADC_full_scale is %.2f dbm\n',20*log10(ADC_full_scale))
fprintf('Total signal in ADC %.2f dbFS\n',10*log10(var(rx_adc)))
clip_prob=sum(abs(rx_adc)>ADC_full_scale)/N1;
fprintf('clipping probability %f \n',clip_prob)

fprintf('Total signal in ADC2 %.2f dbFS\n',10*log10(var(rx_adc2)))


% find first signal
No_channels = length(C);
for ch = 1:No_channels,
    if C(ch).Ch_enable && strcmp('UL',C(ch).UL_DL);
    
    freq=C(ch).Freq;
    break
    end
end


x = exp(-2j*pi*(0:N1-1)'*freq*1e6/fs_ADC).*rx_adc;
rx_adc_dec = decimate(x,dec_factor,100,'fir');
x = exp(-2j*pi*(0:N1-1)'*freq*1e6/fs_ADC).*rx_adc2;

rx_adc2_dec = decimate(x,dec_factor,100,'fir');
%plot_spect(x,fs_ADC/100);
z1 = rx_adc_dec * 10^(-P.LNA_gain/20); % normalize back to input
figure(4)
plot_spect(z1,fs_ADC/dec_factor);
hold all
rcolor
 
L=10;
K=1; % max harmonics
A=zeros(N1/dec_factor,L*K);
for  k=1:K
  
  for i=0:L-1
    A(:,i+1+L*(k-1))=[zeros(i,1); rx_adc2_dec(1:end-i).^k];
  end
end
figure(5)
%A1=A(1:end/2,:);
%h=A1\rx_adc(1:end/2);
%plot(h)

h5=(A'*A+1e-3*eye(size(A,2)))^-1*A'*rx_adc_dec;
hold on 
plot(abs(h5))
rcolor


r3 = A*h5;
rx_adc1_dec = rx_adc_dec - r3;

z1 = rx_adc1_dec * 10^(-P.LNA_gain/20); % normalize back to input
%figure
figure(4)
plot_spect(z1,fs_ADC/dec_factor);
rcolor
legend('after ADC norm to input','after digital cancellation');

figure(3)
legend('Tx leakage','Tx Signal','rx+NF');

figure(6)
z1 = rx_adc * 10^(-P.LNA_gain/20); % normalize back to input

plot_spect(z1,fs_ADC);


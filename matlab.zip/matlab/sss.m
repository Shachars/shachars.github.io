
%save state rx_adc2_dec_w dec_factor rx_adc_dec_w L delta lambda Nu Mb H DCD_dec D reset quant alfa_reduce_factor plotf
load state
delta = 1e+5;
[e_dcdrls, h8] = rls_dcd_pipe7(dec_factor*rx_adc2_dec_w(1:end-L),dec_factor*rx_adc_dec_w(L:end-1),L,delta,lambda,Nu,Mb,H,DCD_dec,D,reset,quant,alfa_reduce_factor,plotf);

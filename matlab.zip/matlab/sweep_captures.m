%

%% Parameters
debug_plot = 1;
path = 'D:\DropBox\Dropbox\corning\corning captures\test\';
% path = 'D:\Captures 26122016\DL 70MHZ with UL 10mhz lte conducted\';

DB_Captures = {};

% go over all the captures folders
Folders = dir(path);
kk = 1;
rejection_vec = [];
for iFolder=3:length(Folders)
    CapturePath = [path,Folders(iFolder).name];
    Captures = dir(CapturePath);
    DB_Captures{iFolder-2}.name = Folders(iFolder).name;
    Results = {};
    for iCapture=3:length(Captures)
        filename = [CapturePath,'\',Captures(iCapture).name];
        disp(['Loading ',Captures(iCapture).name]);
        [REF,UL,clean_UL,Fs,Fc] = sys2_nl16_check_fixed_point(filename);
        Results{iCapture-2}.name = Captures(iCapture).name;
        Results{iCapture-2}.REF = REF;
        Results{iCapture-2}.UL = UL;
        Results{iCapture-2}.clean_UL = clean_UL;
        Results{iCapture-2}.Fs = Fs;
        Results{iCapture-2}.Fc = Fc;
        
        if(debug_plot)
            figure(1);
            hold all;
            [f,ref_f]=plot_spect(REF,Fs,Fc);
            [f,ul_f]=plot_spect(UL,Fs,Fc);
            [f,clean_ul_f]=plot_spect(clean_UL,Fs,Fc);
            Results{iCapture-2}.rejection = ul_f-clean_ul_f;
            plot(f,Results{iCapture-2}.rejection);
            rejection_vec = [rejection_vec,mean(Results{iCapture-2}.rejection)];
            title(Results{iCapture-2}.name);
%             kk = kk + 1;
        end
        
    end
    DB_Captures{iFolder-2}.DCD_Results = Results;
    save('sweep_captures','DB_Captures','rejection_vec');
end

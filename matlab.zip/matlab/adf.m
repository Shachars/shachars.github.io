function out = adf(in,alpha)
% this function simulates the anti droop filter
% assumes in - 1XN

in_pad = [zeros(1,2),in,zeros(1,2)];

for i=2:length(in)+1
    out(i-1) =  -alpha*in_pad(i-1) + (1+2*alpha)*in_pad(i) -alpha*in_pad(i+1); 
end

% all the muls and adds are for 11bits?

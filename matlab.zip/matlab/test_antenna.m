% test antenna
clear all;
close all;

Cfg.antennaS21 = 'D:\Corning-develop_shachar (2)\Corning-develop_shachar\matlab\Antenna S params\TX TO LB.S2P';

if(isfield(Cfg,'antennaS21'))
    [Freq_Ant_Hz,~,~,S21_Ant_Mag_dB,S21_Ant_Phase_deg,~,~,~,~] = importS2P(Cfg.antennaS21);
end

fs_sim = 9.830400000000000e+09;

load('tx.mat');

figure;plot(linspace(-fs_sim/2,fs_sim/2,length(tx1)),fftshift(20*log10(abs(fft(tx1)))));

% put the antenna s21 on the grid
df_ant = Freq_Ant_Hz(2) - Freq_Ant_Hz(1);
max_f = fs_sim/2;
N = ceil(max_f/df_ant); % it's a little annoying that it's not integer but let's stil ldo this
ant_s21 = zeros(1,2*N);
ant_freq_hz = linspace(-max_f,max_f,2*N);
idx_pos = find(abs(ant_freq_hz - Freq_Ant_Hz(1))<df_ant);
idx_neg = find(abs(ant_freq_hz + Freq_Ant_Hz(1))<df_ant);
start_f_pos = idx_pos(1);
start_f_neg = idx_neg(1);
ant_s21(start_f_pos:start_f_pos-1+length(Freq_Ant_Hz)) = 10.^(S21_Ant_Mag_dB/20).*exp(1i*S21_Ant_Phase_deg);
ant_s21(start_f_neg:-1:start_f_neg+1-length(Freq_Ant_Hz)) = 10.^(S21_Ant_Mag_dB/20).*exp(-1i*S21_Ant_Phase_deg); % conjugate
figure;plot(ant_freq_hz,(20*log10(abs(ant_s21))));

ant_s21_t = fft(fftshift(ant_s21));
ant_s21_t = [ant_s21_t,zeros(1,length(tx1)-length(ant_s21_t))];
ant_s21_f_intrp = ifft(ant_s21_t);
figure;plot(linspace(-max_f,max_f,length(tx1)),fftshift(70+20*log10(abs(ant_s21_f_intrp))));
g = fft(tx1);
K = 1e6;
N=ceil(length(tx1)/K);
% for i=1:N
%     h((i-1)*K+1:i*K) = ant_s21_f_intrp((i-1)*K+1:i*K).*(g((i-1)*K+1:i*K).');
% end
h = ant_s21_f_intrp.*(g.');
figure;plot(linspace(-max_f,max_f,length(tx1)),fftshift(70+20*log10(abs(h))));
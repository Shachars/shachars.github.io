function out = hbf(in)
% this function implements the half band filter

Order=15; PassBand=0.1;
HBF=firpm(Order-1,[0 PassBand 1-PassBand 1],[1 1 0 0]);
display(HBF');
NQ=12; HBF=round(HBF*2^NQ)/2^NQ; %Quantize coefficients
display(round(HBF*2^NQ)');


h1 = 1229;%-1261/4096; % 7
h3 = -253;%-320/4096; % 5
h5 = 53;%106/4096; %3
h7 = -6;%-26/4096; %1
h0 = 2047;%2048/4096; % 9

in_pad = [zeros(1,7),in,zeros(1,7)];
out = zeros(1,ceil(length(in)/2));
for i=8:length(out)+7
    out(i-7) = h1*in_pad(i-1)+h3*in_pad(i-3)+h5*in_pad(i-5)+h7*in_pad(i-7) + h0*in_pad(i) + h1*in_pad(i+1)+h3*in_pad(i+3)+h5*in_pad(i+5)+h7*in_pad(i+7);
end
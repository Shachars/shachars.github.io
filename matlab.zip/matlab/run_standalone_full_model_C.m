function  [out] = run_standalone_full_model_C(ref,ul,M_wf,delta_wf,lambda_wf,M_h,delta_h,lambda_h,lambda_reset,reset,Cfg)
disp('running C');
currpath=cd;

cd([Cfg.file_path,'files\input_from_matlab']);
% cd('D:\SW\Corning\RLS_C\files\input_from_matlab');

xi=imag(ref);
xr=real(ref);
di=imag(ul);
dr=real(ul);

N = length(dr);

save ref_i.txt xi -ascii -double
save ref_r.txt xr -ascii -double
save ul_i.txt di -ascii -double
save ul_r.txt dr -ascii -double
save reset.txt reset -ascii -double

temp =   [N M_wf delta_wf lambda_wf M_h delta_h lambda_h lambda_reset];
save parameters_full_algo.txt temp -ascii -double

dos(Cfg.command)

cd([Cfg.file_path,'files\files_for_matlab']);
% cd('D:\SW\Corning\RLS_C\files\files_for_matlab');
out=load('e_dcdrls_r.prn')+1j*load('e_dcdrls_i.prn');

cd(currpath)






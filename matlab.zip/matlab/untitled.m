WF_len = 3;

    
if 1
   
    wf = lpc(rx_adc_dec+0/10*sqrt(var(rx_adc_dec))*(randn(size(rx_adc2_dec))+1j*randn(size(rx_adc2_dec))),WF_len-1);
    rx_adc_dec_w = filter(wf,1,rx_adc_dec);
     


    
end
    L=L1; % filter length
    Remove_Edges_LS=L*2; % remove edges
    K=1; % max harmonics
    A=zeros(N1/dec_factor-L+1-L-Remove_Edges_LS*2,L*K);
    for  k=1:K
        
        for i=0:L-1
            A(:,i+1+L*(k-1))=[rx_adc2_dec(L-i+Remove_Edges_LS:end-i-L-Remove_Edges_LS).^k];
        end
    end
    
    %A1=A(1:end/2,:);
    %h=A1\rx_adc(1:end/2);
    %plot(h)
    sigma =  1e-5;
    h5=(A'*A+sigma*eye(size(A,2)))^-1*A'*rx_adc_dec_w(L+Remove_Edges_LS:end-L-Remove_Edges_LS);
    figure
    plot(real(h5))
        r3 = A*h5;
        rx_adc1_dec_w = rx_adc_dec_w(L+Remove_Edges_LS:end-L-Remove_Edges_LS) - r3;
    
   rx_adc1_dec = filter(1,wf,rx_adc1_dec_w); 
    
   figure
   plot_spect(rx_adc_dec,fs_ADC/dec_factor,center_freq); 
    hold all
   plot_spect(rx_adc_dec_w,fs_ADC/dec_factor,center_freq); 
   plot_spect(rx_adc1_dec_w,fs_ADC/dec_factor,center_freq); 
   plot_spect(rx_adc1_dec,fs_ADC/dec_factor,center_freq); 
   legend('original UL','after WF','after cancellation','inverse WF')

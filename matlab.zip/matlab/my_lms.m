function [e, h] = my_lms(x,y,K,mu,h_start,iter)
N=length(y);   
    
    
thm=zeros(N,K);
sl=thm;
e=zeros(N,1);
mu1=mu^2; % better tracking of time varying channel
thm(K-1,:)=h_start;
for j=1:iter
for i=K:N
    e(i)=y(i)-x(i-K+1:i).'*thm(i-1,:).';
%     sl(i,:) = sl(i-1,:) + mu1*e(i)*x(i-K+1:i).';
    thm(i,:) = thm(i-1,:) + mu*e(i)*x(i-K+1:i)';%+sl(i-1,:);
end
thm(K-1,:)=thm(end,:);

%   hold all
%   plot(abs(e))
end
h=thm(end,:);

function x = readprn(fname)
% READPRN  Subset of MathCad READPRN function.
%          A = READPRN(FILENAME)
%          Reads real/complex vectors/matrices into the Matlab environment
%          Complex types (such as index, multidim. matrices etc. are not
%          supported by the moment
%

% 10-10-02 Dani+Greg Debugging + Approvement (complex matrices)
% by Gregory, 11-02-02

error(nargchk(1,1,nargin));
if ~isstr(fname)
    error('FILENAME must be a string');
end

if length(fname)<4
    fname = [fname,'.prn'];
end

if ~strcmp(lower(fname(end-3:end)),'.prn')
    fname = [fname,'.prn'];
end

[fin, str] = fopen(fname,'rt');
if fin==-1
   error(str)
end

str=fgets(fin);
if (str(1:2)~='//')   % Real matrix/vector
   fclose(fin);
   x = load(fname);
else                  % Complex matrix
   while(isempty(sscanf(str,'.MATRIX %d %d %d %d\n')))
      str=fgets(fin);
   end
   
   sz = sscanf(str,'.MATRIX %d %d %d %d\n'); 
   idx=sz(1); cplx=sz(2); sz=sz(3:4);
   if cplx
      x = [1,1j]*reshape(fscanf(fin,'%f,%f'),2,prod(sz));
   else
      x = fscanf(fin,'%f');
   end;
   x = (reshape(x,sz(2),sz(1)).');
   
   fclose(fin);
end


function y=ADC_analog(Cfg,x1)
fs_sim=Cfg.fs_sim*1e9;
fs_ADC=Cfg.ADC.Fs*1e9;

% ZOH x2=repmat(x1,1,fs_sim/fs_DAC)';
% x2=x2(:);
[Bdac_lp, Adac_lp]=cheby1(Cfg.DAC.DAC_filter_order,Cfg.DAC.DAC_filter_ripple,Cfg.DAC.DAC_filter_cutoff*1e9/fs_sim*2*(0.95+rand*0.1));

%[Bdac_lp, Adac_lp]=firrcos(fs_sim/fs_dac*20,fs_dac/2,0.4,fs_sim,'rolloff','sqrt');
x2=filter(Bdac_lp,Adac_lp,x1);

% %% TMP add shachar - in order to work with signals at the second nyquist zone
% d = designfilt('bandpassiir','FilterOrder',20, ...
%     'PassbandFrequency1',1500e6,'PassbandFrequency2',2500e6, ...
%     'PassbandRipple',3,'SampleRate',fs_sim);
% 
% x2=filter(d,x1);
y=x2;
% decimation for real ADC
y=y(1:fs_sim/fs_ADC:end); %*sqrt(fs_sim/fs_ADC);
 
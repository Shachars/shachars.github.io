"""
Cross-layer Wi-Fi → vLLM inference simulator.

Self-contained simulation framework for studying how heavy-tailed Wi-Fi
inter-arrival times affect vLLM V1 continuous-batching inference, and
evaluating stall-aware admission policies.

Components:
- Three arrival generators (Poisson, i.i.d. from empirical histogram, Gilbert-Elliott)
- GE state predictor (Bayesian posterior over current MAC state)
- Continuous-batching simulator with chunked prefill + roofline cost model
- Three scheduling policies (none, reactive, predictive)
- Optional V1 recompute preemption
- Empirical ns-3 IAT histogram embedded as Python literal

Usage:
    from simulator import (run_sim, make_requests, CBConfig, GEStatePredictor,
                           sample_iats_iid, generate_poisson_arrivals,
                           generate_ge_arrivals, hist)

    N = 1500
    iats = sample_iats_iid(hist, N, seed=1)
    arrivals = np.cumsum(iats)
    cfg = CBConfig(B_sat=16, policy="reactive", signal_aware_burst_cap=8)
    reqs = make_requests(arrivals, seed=100)
    res = run_sim(reqs, cfg, seed=10)
"""

import numpy as np
from dataclasses import dataclass, field
from collections import deque


# =============================================================================
# THE EMPIRICAL ns-3 IAT HISTOGRAM
# =============================================================================
# Per-station uplink-gap distribution from the ns-3 simulation (`ul_gap_sta_4`).
# 1 ms bins from 0 to 3424 ms. 4006 total IAT samples. Mean IAT ≈74 ms,
# implied mean rate ≈13.5 req/s.
#
# Body (52% of samples below 30 ms): A-MPDU aggregation, post-channel-access bursts.
# Tail (2.3% above 500 ms): contention-induced stalls.

hist = {
    0: 677, 1: 55, 2: 26, 3: 31, 4: 44, 5: 341, 6: 108, 7: 31, 8: 35,
    9: 26, 10: 20, 11: 193, 12: 40, 13: 24, 14: 26, 15: 8, 16: 64, 17: 47,
    18: 25, 19: 24, 20: 20, 21: 19, 22: 40, 23: 27, 24: 15, 25: 20, 26: 17,
    27: 16, 28: 33, 29: 20, 30: 18, 31: 16, 32: 26, 33: 26, 34: 24, 35: 23,
    36: 21, 37: 19, 38: 20, 39: 24, 40: 21, 41: 9, 42: 14, 43: 12, 44: 20,
    45: 14, 46: 21, 47: 19, 48: 17, 49: 15, 50: 20, 51: 28, 52: 14, 53: 17,
    54: 21, 55: 16, 56: 17, 57: 14, 58: 7, 59: 15, 60: 18, 61: 16, 62: 15,
    63: 10, 64: 14, 65: 11, 66: 17, 67: 18, 68: 18, 69: 21, 70: 10, 71: 11,
    72: 15, 73: 19, 74: 15, 75: 15, 76: 11, 77: 12, 78: 15, 79: 20, 80: 14,
    81: 4, 82: 12, 83: 19, 84: 22, 85: 9, 86: 10, 87: 17, 88: 11, 89: 12,
    90: 14, 91: 18, 92: 15, 93: 11, 94: 16, 95: 10, 96: 13, 97: 13, 98: 8,
    99: 8, 100: 13, 101: 12, 102: 12, 103: 10, 104: 8, 105: 9, 106: 8,
    107: 8, 108: 7, 109: 10, 110: 6, 111: 8, 112: 10, 113: 10, 114: 9,
    115: 6, 116: 10, 117: 10, 118: 11, 119: 7, 120: 15, 121: 5, 122: 7,
    123: 5, 124: 14, 125: 10, 126: 2, 127: 2, 128: 11, 129: 10, 130: 13,
    131: 13, 132: 4, 133: 4, 134: 7, 135: 4, 136: 9, 137: 7, 138: 9, 139: 11,
    140: 1, 141: 11, 142: 11, 143: 8, 144: 5, 145: 6, 146: 5, 147: 8, 148: 6,
    149: 6, 150: 1, 151: 5, 152: 10, 153: 3, 154: 3, 155: 5, 156: 3, 157: 11,
    158: 6, 159: 7, 160: 3, 161: 1, 162: 6, 163: 10, 164: 4, 165: 1, 166: 2,
    167: 2, 168: 2, 169: 5, 170: 3, 171: 4, 172: 2, 173: 1, 174: 3, 175: 5,
    176: 4, 177: 2, 178: 1, 179: 5, 180: 6, 181: 6, 182: 1, 183: 1, 184: 1,
    185: 2, 186: 3, 187: 3, 188: 1, 189: 2, 190: 3, 192: 3, 193: 4, 195: 3,
    196: 2, 199: 1, 200: 2, 201: 2, 202: 3, 203: 1, 205: 2, 206: 3, 207: 2,
    208: 2, 211: 5, 212: 1, 214: 2, 215: 3, 216: 3, 217: 3, 218: 4, 219: 1,
    220: 1, 221: 1, 222: 1, 224: 1, 226: 2, 229: 1, 230: 2, 232: 2, 233: 2,
    235: 1, 236: 2, 241: 2, 243: 1, 244: 1, 247: 2, 248: 1, 249: 1, 251: 3,
    252: 1, 254: 2, 256: 2, 257: 1, 259: 4, 260: 3, 261: 1, 262: 3, 268: 2,
    270: 1, 271: 3, 272: 1, 275: 2, 276: 2, 278: 1, 279: 1, 281: 1, 283: 1,
    285: 1, 288: 2, 290: 1, 291: 1, 292: 1, 293: 1, 295: 1, 296: 1, 298: 1,
    299: 1, 301: 2, 305: 1, 310: 1, 312: 1, 318: 1, 322: 3, 329: 1, 334: 1,
    336: 1, 340: 1, 341: 1, 347: 1, 349: 2, 353: 1, 354: 1, 363: 1, 365: 1,
    368: 1, 370: 1, 378: 1, 382: 1, 388: 1, 389: 1, 390: 1, 391: 1, 393: 1,
    396: 1, 397: 1, 398: 1, 399: 1, 405: 1, 412: 1, 413: 1, 418: 1, 427: 1,
    433: 1, 434: 1, 441: 1, 450: 1, 454: 1, 456: 1, 460: 1, 461: 1, 479: 1,
    485: 1, 486: 1, 493: 1, 495: 1, 498: 1, 501: 1, 504: 2, 507: 1, 514: 1,
    517: 1, 522: 1, 523: 2, 524: 1, 529: 1, 542: 1, 545: 1, 563: 1, 573: 1,
    576: 1, 579: 1, 580: 1, 583: 1, 587: 1, 588: 1, 589: 1, 595: 2, 596: 1,
    598: 1, 599: 1, 611: 1, 613: 1, 634: 1, 647: 1, 650: 1, 652: 1, 669: 1,
    682: 1, 692: 1, 693: 1, 700: 1, 705: 1, 718: 1, 723: 1, 737: 1, 740: 1,
    744: 1, 751: 1, 767: 1, 771: 1, 795: 1, 796: 1, 804: 1, 814: 1, 822: 1,
    828: 1, 846: 1, 853: 1, 865: 1, 895: 1, 907: 1, 911: 1, 913: 1, 948: 1,
    951: 1, 974: 1, 985: 1, 994: 1, 1005: 1, 1038: 1, 1108: 1, 1135: 1,
    1195: 1, 1224: 1, 1232: 1, 1290: 1, 1297: 1, 1316: 1, 1364: 1, 1385: 1,
    1442: 2, 1449: 1, 1465: 1, 1494: 1, 1569: 1, 1604: 1, 1731: 1, 1808: 1,
    1868: 1, 1953: 1, 2312: 1, 2596: 1, 2855: 1, 3424: 1,
}


# =============================================================================
# ARRIVAL GENERATORS
# =============================================================================

def sample_iats_iid(h, n, seed=0):
    """i.i.d. sample inter-arrival times from the empirical histogram.

    Preserves the marginal IAT distribution exactly but destroys temporal
    correlation. Use as a marginal-only baseline against the GE generator.

    Returns IATs in seconds.
    """
    rng = np.random.default_rng(seed)
    bins = np.array(sorted(h))
    counts = np.array([h[b] for b in bins], dtype=float)
    probs = counts / counts.sum()
    chosen = rng.choice(bins, size=n, p=probs)
    jitter = rng.random(n)
    return (chosen + jitter) / 1000.0


def generate_poisson_arrivals(rate, duration, seed=0):
    """Exponential inter-arrivals at the given mean rate.

    This is the arrival process built into `vllm bench serve` by default.
    Used as the matched-rate reference for EDCA generators.

    Returns absolute arrival times in seconds.
    """
    rng = np.random.default_rng(seed)
    n_exp = int(rate * duration * 1.5)
    iats = rng.exponential(1.0 / rate, size=n_exp)
    times = np.cumsum(iats)
    return times[times < duration]


def generate_ge_arrivals(h, n, threshold_ms=30, mean_run_G=5, seed=0):
    """Gilbert-Elliott two-state Markov chain calibrated to histogram h.

    State G (burst): IATs sampled from h restricted to bins below threshold_ms.
    State B (stall): IATs sampled from h restricted to bins at or above threshold_ms.
    pi_G, pi_B set to empirical body/tail mass fractions so marginal CCDF matches.
    p_GB = 1/mean_run_G; p_BG = (pi_G/pi_B) * p_GB by detailed balance.

    Returns (iats_seconds, states_array). states_array[i] = 0 (G) or 1 (B).
    """
    rng = np.random.default_rng(seed)
    h_G = {b: c for b, c in h.items() if b < threshold_ms}
    h_B = {b: c for b, c in h.items() if b >= threshold_ms}
    pi_G = sum(h_G.values()) / (sum(h_G.values()) + sum(h_B.values()))
    pi_B = 1.0 - pi_G
    p = 1.0 / mean_run_G               # P(G -> B) per emission
    r = (pi_G / pi_B) * p              # P(B -> G), from detailed balance
    if r > 1.0:
        raise ValueError(f"r={r:.3f} > 1; mean_run_G too small for empirical split")

    bins_G = np.array(sorted(h_G))
    probs_G = np.array([h_G[b] for b in bins_G], dtype=float) / sum(h_G.values())
    bins_B = np.array(sorted(h_B))
    probs_B = np.array([h_B[b] for b in bins_B], dtype=float) / sum(h_B.values())

    state = "G" if rng.random() < pi_G else "B"
    iats_ms = np.zeros(n)
    states = np.zeros(n, dtype=int)
    for i in range(n):
        if state == "G":
            states[i] = 0
            iats_ms[i] = rng.choice(bins_G, p=probs_G) + rng.random()
            if rng.random() < p: state = "B"
        else:
            states[i] = 1
            iats_ms[i] = rng.choice(bins_B, p=probs_B) + rng.random()
            if rng.random() < r: state = "G"
    return iats_ms / 1000.0, states


# =============================================================================
# GE STATE PREDICTOR (for the predictive policy)
# =============================================================================

class GEStatePredictor:
    """Bayesian predictor for the next-emission state of a GE chain.

    Uses survival functions of the per-state IAT distributions plus the
    transition probabilities to compute P(next arrival in state B) given
    the time elapsed since the last arrival and the state of that arrival.

    Constructed with the same parameters as the GE generator that produces
    the arrival stream (perfect-oracle calibration for the experiments).
    """
    def __init__(self, h, threshold_ms=30, mean_run_G=5):
        h_G = [b for b in sorted(h) if b < threshold_ms for _ in range(h[b])]
        h_B = [b for b in sorted(h) if b >= threshold_ms for _ in range(h[b])]
        self.h_G_sorted = np.sort(np.array(h_G) / 1000.0)
        self.h_B_sorted = np.sort(np.array(h_B) / 1000.0)
        pi_G = len(h_G) / (len(h_G) + len(h_B))
        pi_B = 1.0 - pi_G
        self.p_GB = 1.0 / mean_run_G
        self.p_BG = (pi_G / pi_B) * self.p_GB

    def survival_G(self, dt_s):
        if dt_s <= 0: return 1.0
        idx = np.searchsorted(self.h_G_sorted, dt_s, side='right')
        return 1.0 - idx / len(self.h_G_sorted)

    def survival_B(self, dt_s):
        if dt_s <= 0: return 1.0
        idx = np.searchsorted(self.h_B_sorted, dt_s, side='right')
        return 1.0 - idx / len(self.h_B_sorted)

    def p_next_B(self, dt_s, last_state):
        """Posterior P(next arrival in state B | dt elapsed, last_state observed)."""
        if last_state == 0:  # last was G
            prior_G, prior_B = 1 - self.p_GB, self.p_GB
        else:                 # last was B
            prior_G, prior_B = self.p_BG, 1 - self.p_BG
        likelihood_G = self.survival_G(dt_s)
        likelihood_B = self.survival_B(dt_s)
        num = likelihood_B * prior_B
        denom = likelihood_G * prior_G + likelihood_B * prior_B
        return num / denom if denom > 1e-12 else 0.5


# =============================================================================
# SIMULATOR DATA STRUCTURES
# =============================================================================

@dataclass
class Request:
    """A single inference request through the simulator."""
    req_id: int
    arrival_time: float
    prompt_tokens: int
    output_tokens: int
    mac_state: int = -1                   # 0 = G (burst), 1 = B (stall), -1 = unknown
    original_prompt_tokens: int = -1
    admit_time: float = -1.0
    first_token_time: float = -1.0
    last_token_time: float = -1.0
    prefill_tokens_done: int = 0
    decode_tokens_done: int = 0
    token_times: list = field(default_factory=list)
    preemption_count: int = 0

    def __post_init__(self):
        if self.original_prompt_tokens < 0:
            self.original_prompt_tokens = self.prompt_tokens

    @property
    def prefill_done(self): return self.prefill_tokens_done >= self.prompt_tokens
    @property
    def is_complete(self): return self.decode_tokens_done >= self.output_tokens
    @property
    def ttft(self): return self.first_token_time - self.arrival_time
    @property
    def e2e_latency(self): return self.last_token_time - self.arrival_time


@dataclass
class CBConfig:
    """Configuration for the continuous-batching simulator."""
    # Capacity
    max_batch: int = 32
    prefill_chunk_size: int = 128

    # Roofline cost model (flat below B_sat, linear above)
    base_overhead_s: float = 0.002
    B_sat: int = 16
    cost_per_seq_below_knee_s: float = 0.0001
    cost_per_seq_above_knee_s: float = 0.001
    prefill_per_token_s: float = 0.00024

    # V1 recompute preemption (probabilistic trigger)
    preemption_strategy: str = "none"     # "none" or "recompute"
    preemption_prob_per_iter: float = 0.0
    max_preemptions_per_request: int = 5

    # Stall-aware scheduling policy
    policy: str = "none"                  # "none", "reactive", "predictive"
    signal_aware_burst_cap: int = 8       # admission cap during predicted bursts


def iteration_cost_s(decode_count, prefill_tokens, cfg):
    """Piecewise-linear roofline cost.

    Below B_sat: HBM-bandwidth-bound, near-flat latency.
    Above B_sat: compute-bound, linear in batch size.
    """
    n_below = min(decode_count, cfg.B_sat)
    n_above = max(0, decode_count - cfg.B_sat)
    return (cfg.base_overhead_s
            + n_below * cfg.cost_per_seq_below_knee_s
            + n_above * cfg.cost_per_seq_above_knee_s
            + prefill_tokens * cfg.prefill_per_token_s)


def make_requests(arrival_times, mac_states=None,
                   prompt_mean=64, prompt_std=16,
                   prompt_min=16, prompt_max=256,
                   output_tokens=64, seed=0):
    """Construct Request objects from a list of arrival times.

    Prompt lengths are sampled from a truncated normal. Output length is
    homogeneous. Mac states are attached if provided (for GE traces); set
    to -1 (unknown) otherwise.
    """
    rng = np.random.default_rng(seed)
    prompts = rng.normal(prompt_mean, prompt_std, size=len(arrival_times))
    prompts = np.clip(prompts, prompt_min, prompt_max).round().astype(int)
    if mac_states is None:
        mac_states = [-1] * len(arrival_times)
    return [Request(req_id=i, arrival_time=t, prompt_tokens=int(p),
                    output_tokens=output_tokens, mac_state=int(s))
            for i, (t, p, s) in enumerate(zip(arrival_times, prompts, mac_states))]


# =============================================================================
# THE SIMULATOR
# =============================================================================

def run_sim(arrivals, cfg, predictor=None, seed=0):
    """Run the continuous-batching simulator.

    Inputs:
        arrivals: list of Request objects (typically from make_requests).
        cfg: CBConfig.
        predictor: GEStatePredictor instance (required if cfg.policy == "predictive").
        seed: RNG seed for preemption decisions.

    Returns dict with keys:
        completed: list of Request objects, mutated with timing info.
        batch_trace: np.array of shape (n_iters, 2) with (time, active_batch_size).
        cap_trace:   np.array of shape (n_iters, 2) with (time, effective_cap).
    """
    rng = np.random.default_rng(seed)
    arrivals = sorted(arrivals, key=lambda r: r.arrival_time)
    next_idx = 0
    queue = deque()
    in_flight = []
    completed = []
    batch_trace = []
    cap_trace = []
    t = 0.0
    max_time = arrivals[-1].arrival_time + 60.0
    last_arrival_state = 1                 # start assuming stall (conservative)
    last_arrival_time = 0.0

    while True:
        # === Step 1: Advance arrivals; update most-recent state info ===
        while next_idx < len(arrivals) and arrivals[next_idx].arrival_time <= t:
            queue.append(arrivals[next_idx])
            if arrivals[next_idx].mac_state >= 0:
                last_arrival_state = arrivals[next_idx].mac_state
                last_arrival_time = arrivals[next_idx].arrival_time
            next_idx += 1

        # === Step 2: Determine effective admission cap based on policy ===
        if cfg.policy == "reactive":
            cap = (cfg.signal_aware_burst_cap if last_arrival_state == 0
                   else cfg.max_batch)
        elif cfg.policy == "predictive":
            if predictor is None:
                raise ValueError("predictive policy requires a predictor argument")
            dt = t - last_arrival_time
            p_B = predictor.p_next_B(dt, last_arrival_state)
            cap = int(round(cfg.signal_aware_burst_cap
                            + (cfg.max_batch - cfg.signal_aware_burst_cap) * p_B))
            cap = max(1, min(cfg.max_batch, cap))
        else:
            cap = cfg.max_batch
        cap_trace.append((t, cap))

        # === Step 3: Admit waiting → running, FIFO, up to effective cap ===
        while queue and len(in_flight) < cap:
            r = queue.popleft()
            if r.admit_time < 0: r.admit_time = t
            in_flight.append(r)

        # === Idle skip: if nothing to do, jump to next arrival ===
        if not in_flight:
            if next_idx >= len(arrivals): break
            t = arrivals[next_idx].arrival_time
            if t > max_time: break
            continue

        # === Step 4: Preemption check (V1 recompute) ===
        queue_nonempty = (len(queue) > 0 or
                          (next_idx < len(arrivals) and
                           arrivals[next_idx].arrival_time <= t))
        if (cfg.preemption_strategy == "recompute"
                and len(in_flight) >= cfg.max_batch and queue_nonempty
                and rng.random() < cfg.preemption_prob_per_iter):
            victim, best = None, None
            for r in reversed(in_flight):
                if r.preemption_count >= cfg.max_preemptions_per_request:
                    continue
                if best is None or r.decode_tokens_done < best:
                    victim, best = r, r.decode_tokens_done
            if victim is not None:
                in_flight.remove(victim)
                victim.preemption_count += 1
                # Recompute: re-prefill original prompt + accumulated decoded tokens
                victim.prompt_tokens = victim.original_prompt_tokens + victim.decode_tokens_done
                victim.prefill_tokens_done = 0
                queue.appendleft(victim)
                while queue and len(in_flight) < cap:
                    in_flight.append(queue.popleft())

        # === Step 5: Allocate prefill chunks (FIFO over in_flight) ===
        budget = cfg.prefill_chunk_size
        prefill_tokens = 0
        for r in in_flight:
            if r.prefill_done: continue
            if budget <= 0: break
            take = min(r.prompt_tokens - r.prefill_tokens_done, budget)
            r.prefill_tokens_done += take
            budget -= take
            prefill_tokens += take

        # === Step 6: Decode one token for each prefill-complete request ===
        decode_reqs = [r for r in in_flight if r.prefill_done and not r.is_complete]
        decode_count = len(decode_reqs)

        # === Step 7: Compute iteration cost (roofline) ===
        iter_time = iteration_cost_s(decode_count, prefill_tokens, cfg)
        t_end = t + iter_time
        batch_trace.append((t, decode_count + (1 if prefill_tokens > 0 else 0)))

        for r in decode_reqs:
            if r.first_token_time < 0: r.first_token_time = t_end
            r.token_times.append(t_end)
            r.decode_tokens_done += 1
            r.last_token_time = t_end

        # === Step 8: Advance clock + move completed ===
        next_in_flight = []
        for r in in_flight:
            if r.is_complete: completed.append(r)
            else: next_in_flight.append(r)
        in_flight = next_in_flight
        t = t_end

        if t > max_time and not in_flight and next_idx >= len(arrivals): break
        if t > max_time + 60: break

    return {
        "completed": completed,
        "batch_trace": np.array(batch_trace),
        "cap_trace": np.array(cap_trace),
    }


def summarize(name, res):
    """Standard TTFT / batch summary."""
    completed = res["completed"]
    if not completed: return {"name": name, "n": 0}
    ttfts = np.array([r.ttft for r in completed]) * 1000  # ms
    bt = res["batch_trace"]
    pc = np.array([r.preemption_count for r in completed])
    return {
        "name": name, "n": len(completed),
        "p50": float(np.percentile(ttfts, 50)),
        "p95": float(np.percentile(ttfts, 95)),
        "p99": float(np.percentile(ttfts, 99)),
        "mean_batch": float(bt[:, 1].mean()) if len(bt) else 0,
        "frac_above_Bsat": float((bt[:, 1] > 8).mean()) if len(bt) else 0,
        "preempts": int(pc.sum()),
    }


# =============================================================================
# QUICK SANITY DEMO
# =============================================================================

if __name__ == "__main__":
    print("Cross-layer Wi-Fi → vLLM simulator")
    print("=" * 60)

    N = 1500
    SEED = 1

    # Build matched-rate Poisson and GE traces
    iats_iid = sample_iats_iid(hist, N, seed=SEED)
    dur = np.cumsum(iats_iid)[-1]
    rate = N / dur
    print(f"\nTrace: N={N}, duration={dur:.1f}s, rate={rate:.2f} req/s\n")

    arr_poi = generate_poisson_arrivals(rate, dur, seed=SEED)
    iats_ge, states_ge = generate_ge_arrivals(hist, N, mean_run_G=5, seed=SEED)
    iats_ge = iats_ge * (dur / iats_ge.sum())   # match duration
    arr_ge = np.cumsum(iats_ge)

    predictor = GEStatePredictor(hist, threshold_ms=30, mean_run_G=5)

    # Run four configurations
    configs = [
        ("Poisson",          arr_poi, None,                CBConfig(B_sat=16, policy="none")),
        ("GE baseline",      arr_ge,  states_ge.tolist(),  CBConfig(B_sat=16, policy="none")),
        ("GE + reactive",    arr_ge,  states_ge.tolist(),  CBConfig(B_sat=16, policy="reactive", signal_aware_burst_cap=8)),
        ("GE + predictive",  arr_ge,  states_ge.tolist(),  CBConfig(B_sat=16, policy="predictive", signal_aware_burst_cap=8)),
    ]

    print(f"{'Config':<22s} {'p50 (ms)':>10s} {'p95 (ms)':>10s} {'p99 (ms)':>10s} {'mean B':>8s}")
    print("-" * 65)
    for label, arr, states, cfg in configs:
        reqs = make_requests(arr, mac_states=states, seed=100)
        pred = predictor if cfg.policy == "predictive" else None
        res = run_sim(reqs, cfg, predictor=pred, seed=10)
        s = summarize(label, res)
        print(f"{label:<22s} {s['p50']:>10.0f} {s['p95']:>10.0f} {s['p99']:>10.0f} {s['mean_batch']:>8.1f}")

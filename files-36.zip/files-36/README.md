# Cross-Layer Wi-Fi Inference Pathology — Final Artifact Set

Complete experimental record for the study of how heavy-tailed Wi-Fi inter-arrival times affect vLLM-class continuous-batching inference, what stall-aware admission policies can recover, and the standardization path for bidirectional signaling.

## Artifacts

| File | Description |
|---|---|
| `lecture_notes_final.pdf` | Comprehensive technical reference (15 pages). Detailed simulation specification, all experimental results with figures and tables, including the predictive policy negative result and the bidirectional-signaling standardization analysis. Critical self-assessment with walked-back claims. |
| `lecture_notes_final.docx` | Source document |
| `simulator.py` | Standalone, self-contained Python simulator. Contains all three arrival generators (Poisson, i.i.d., Gilbert-Elliott), the GE state predictor, the continuous-batching engine, three scheduling policies, and the empirical ns-3 IAT histogram embedded as a Python literal. Importable as a module or runnable as a script for a quick demo. |
| `colab_final.ipynb` | Runnable Colab notebook reproducing every result, including the predictive policy negative finding. ~5 minutes on Colab CPU runtime. |
| `colab_final_executed.ipynb` | Pre-executed version with all figures embedded. Browse without running. |

## Key results

**Headline (10 seeds, B_sat=16, mean rate ≈13 req/s):**

| Configuration | p95 TTFT (ms) | p95 ratio | Gap recovery |
|---|---|---|---|
| Poisson reference | 41 ± 3 | 1.0× | (target) |
| i.i.d. from histogram | ~163 (4.0 ± 6.0 × ratio) | 4.0× | — |
| GE with mean ON-run=5 (acf 0.39) | 1182 ± 672 | 29.4× | — |
| GE + reactive stall-aware | 779 ± 565 | 19.0× | **35.3%** |
| GE + predictive stall-aware | 1114 ± 647 | 27.2× | 6.0% (worse than reactive) |

**Four claims established:**

1. Heavy-tailed marginal distribution alone is insufficient — i.i.d. shows only modest, noisy effects at conservative B_sat.
2. Burst-stall correlation amplifies the effect 7× over i.i.d. resampling, robust across 10 seeds.
3. The effect persists across B_sat ∈ {8, 12, 16, 24}; collapses only when B_sat ≥ max_batch.
4. Reactive stall-aware admission recovers 35% of the gap. Predictive admission does NOT improve on reactive — the reactive policy's apparent "lag" is doing useful batch-draining work. Further recovery requires either preemption or bidirectional signaling at the MAC.

**The bidirectional signaling proposal (theoretical, not yet implemented):** ETSI MEC RNIS API extension with three new fields (MAC state estimate, time-since-last-success, recent EDCA contention statistics) at 10 Hz update rate. Contained, deployable on commodity APs, no wireless-standard change needed.

## How to use

### Quickest path: run the notebook on Colab
1. Open https://colab.research.google.com
2. File → Upload → `colab_final.ipynb`
3. Runtime → Run all (~5 min, no GPU needed)

### Use the simulator directly
```python
from simulator import *
import numpy as np

iats_iid = sample_iats_iid(hist, 1500, seed=1)
dur = np.cumsum(iats_iid)[-1]
arr_ge, states_ge = generate_ge_arrivals(hist, 1500, mean_run_G=5, seed=1)
arr_ge = np.cumsum(arr_ge * (dur / arr_ge.sum()))

cfg = CBConfig(B_sat=16, policy="reactive", signal_aware_burst_cap=8)
reqs = make_requests(arr_ge, mac_states=states_ge.tolist(), seed=100)
res = run_sim(reqs, cfg, seed=10)
print(summarize("GE+reactive", res))
```

### Read the PDF for the full story
`lecture_notes_final.pdf` is the comprehensive technical reference. Self-contained — anyone reimplementing from the PDF alone should reproduce the numbers.

## What's in the PDF

| Section | Content |
|---|---|
| Preface | Five-stage research arc, honest summary of findings |
| 1. Problem statement | Four questions; mechanistic answers |
| 2. Arrival processes | Poisson / i.i.d. / GE specifications + validation |
| 3. The vLLM simulator | Architecture, cost model, iteration loop, stall-aware policies |
| 4. Calibration | Parameter table with rationales |
| 5. Results | Multi-seed comparison, B_sat sweep, reactive policy, predictive negative result |
| 6. Bidirectional signaling | Mechanism, ETSI MEC RNIS standardization proposal, other venues |
| 7. Critical self-assessment | Walked-back claims, surviving claims, open gaps |
| 8. Next steps | Five recommended experiments in priority order |
| Appendix | Simulator code reference and minimum reproducible example |

## Open questions (Section 8 of PDF)

In priority order:

1. **Closed-loop bidirectional signaling experiment** — implement MAC throttling in response to inference saturation; expected to push recovery toward 50-80%.
2. **ETSI MEC RNIS extension proposal** — convert the standardization analysis into a formal MEC ISG contribution.
3. **Real-vLLM trace replay validation** — empirical grounding for the simulation claims.
4. **Hardware B_sat calibration** — remove the parametric study caveat.
5. **Predictive policy variants** — smoother per-state distributions or PID control, lower priority.

## Dependencies

- numpy
- pandas
- matplotlib

Standard scientific Python. No GPU, no vLLM, no model weights. Pure-Python simulator runs in seconds per experiment on a single CPU.

## What's NOT in this artifact set

The bidirectional signaling experiment (Section 6 of PDF) is the proposed next step — the theory and standardization path are documented, but the closed-loop simulation has not yet been run. The framework supports it; the experiment is open work.
